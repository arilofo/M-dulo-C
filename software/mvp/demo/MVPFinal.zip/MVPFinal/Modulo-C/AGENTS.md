# Instrucciones para Codex

Este repositorio corresponde al prototipo MVP del Módulo C: Cuentas por Pagar del SIGE.

## Stack tecnológico obligatorio

El prototipo debe implementarse usando:

- Lenguaje: Java.
- Tipo de aplicación: aplicación local ejecutada en una PC.
- Backend: Java con JDBC.
- Base de datos: MySQL 8.x.
- Frontend: vistas simples HTML.
- Servidor web: servidor HTTP local embebido en Java.
- Gestor de dependencias: opcional. Se puede usar Maven si facilita la gestión del conector MySQL, pero no es obligatorio.

Codex no debe cambiar el stack tecnológico a Spring Boot, Node.js, Python, React, Angular, Laravel u otro framework salvo autorización explícita del usuario.

La arquitectura esperada es:

HTML simple → Controladores Java locales → Servicios → DAO/JDBC → MySQL

El programa debe ejecutarse localmente y exponer una interfaz web simple en localhost, por ejemplo:

http://localhost:8080

## Reglas obligatorias del proyecto

- La base de datos es MySQL.
- El módulo usa borrado lógico.
- No usar DELETE físico en tablas principales.
- Las consultas normales deben filtrar registros activos con activo = 1.
- El Módulo C no debe implementar completamente los módulos A, B ni D.
- Los scripts de los módulos A, B y D son solo referencia o integración.
- No modificar scripts de otros módulos sin autorización.
- Priorizar el uso de procedimientos almacenados existentes.
- No modificar directamente tablas críticas si existe un procedimiento almacenado para esa operación.
- Mantener la integración modular mediante vistas, procedimientos, interfaces, referencias lógicas o mocks.
- El flujo principal obligatorio es: orden de compra → recepción → factura proveedor → cuenta por pagar → pago.
- La recepción debe generar o simular la actualización del inventario del Módulo B.
- Deben existir reportes de pagos próximos a vencer, órdenes pendientes de recepción, conciliación de saldos y obligaciones pendientes.

## Orden recomendado de lectura

Antes de escribir código, Codex debe revisar:

1. `documentacion-contexto/00_reglas_obligatorias_proyecto.md`
2. `documentacion-contexto/01_resumen_general.md`
3. `documentacion-contexto/02_alcance_mvp.md`
4. `documentacion-contexto/03_requerimientos_modulo_c.md`
5. `documentacion-contexto/04_flujos_principales.md`
6. `documentacion-contexto/05_integracion_modulos.md`
7. `documentacion-contexto/06_diccionario_datos.md`
8. `documentacion-contexto/08_procedimientos_vistas_bd.md`
9. `database/modulo_c/`
10. `database/modulos_externos_readonly/`

## Forma de trabajo

Codex debe trabajar por partes, no generar todo el sistema de una sola vez.

Primero debe proponer estructura del proyecto Java.
Después debe implementar por flujo:

1. Conexión JDBC con MySQL.
2. Pantalla inicial.
3. Proveedores.
4. Órdenes de compra.
5. Recepciones.
6. Facturas de proveedor.
7. Cuentas por pagar.
8. Pagos.
9. Reportes.
10. Demo final.

Después de cada cambio debe explicar:

- qué archivos modificó;
- qué funcionalidad agregó;
- cómo probarlo localmente.
-- Compatibilidad segura para esquema modulo_d usado por Modulo C.
-- Ejecutar conectado a MySQL con permisos sobre el esquema modulo_d.
-- No borra datos, no hace DROP TABLE y no modifica la logica del Modulo C.

USE modulo_d;

-- 1) Diagnostico: verificar columnas reales cargadas.
SHOW COLUMNS FROM tarifas_iva;
SHOW COLUMNS FROM retenciones_iva_config;
SHOW COLUMNS FROM retenciones_renta_config;
SHOW COLUMNS FROM comprobantes_retencion;
SHOW COLUMNS FROM log_xml_comprobantes;

-- 2) Compatibilidad con DataBase/ScriptsMODS_Externos.sql.
-- El script original espera porcentaje_retencion en tablas de retencion.
-- Ejecutar solo si SHOW COLUMNS confirma que falta la columna.
ALTER TABLE retenciones_iva_config
    ADD COLUMN IF NOT EXISTS porcentaje_retencion DECIMAL(5,2) NULL;

ALTER TABLE retenciones_renta_config
    ADD COLUMN IF NOT EXISTS porcentaje_retencion DECIMAL(5,2) NULL;

-- El script original tambien define concepto en retenciones_renta_config.
-- La aplicacion Java actual puede leer descripcion como concepto, por lo que
-- esta columna solo es necesaria si otros modulos externos la siguen exigiendo.
ALTER TABLE retenciones_renta_config
    ADD COLUMN IF NOT EXISTS concepto VARCHAR(150) NULL;

-- 3) Si el esquema viejo usa una columna llamada porcentaje, copiar los valores.
-- Ejecutar estas sentencias solo si SHOW COLUMNS muestra que existe porcentaje.
-- UPDATE retenciones_iva_config
-- SET porcentaje_retencion = porcentaje
-- WHERE porcentaje_retencion IS NULL;
--
-- UPDATE retenciones_renta_config
-- SET porcentaje_retencion = porcentaje
-- WHERE porcentaje_retencion IS NULL;

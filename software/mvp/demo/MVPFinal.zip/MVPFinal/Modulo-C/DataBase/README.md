# Scripts externos extraídos

Archivos generados a partir de `ScriptsMODS.docx`.

- `ScriptsMODS_extraidos.txt`: extracción en texto plano del contenido del documento.
- `ScriptsMODS_extraidos.sql`: versión práctica para guardar en `database/modulos_externos_readonly/`; solo se comentaron los encabezados `MODULO A`, `MODULO B` y `MODULO D` para que no queden como instrucciones SQL inválidas. No se corrigió ni reestructuró la lógica del script.

Uso recomendado en el repo:

```txt
database/
└── modulos_externos_readonly/
    ├── ScriptsMODS_extraidos.sql
    └── ScriptsMODS_extraidos.txt
```

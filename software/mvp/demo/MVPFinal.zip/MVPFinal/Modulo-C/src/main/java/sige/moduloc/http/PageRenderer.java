package sige.moduloc.http;

import sige.moduloc.controller.RoleController;
import sige.moduloc.security.RoleContext;

public final class PageRenderer {
    private PageRenderer() {
    }

    public static String layout(String content) {
        return """
                <!doctype html>
                <html lang="es">
                <head>
                    <meta charset="utf-8">
                    <meta name="viewport" content="width=device-width, initial-scale=1">
                    <title>Modulo C - Cuentas por Pagar</title>
                    <link rel="stylesheet" href="/static/styles.css">
                </head>
                <body>
                    <main class="shell">
                        <header class="topbar">
                            <div class="brand">
                                <h1>Modulo C - Cuentas por Pagar</h1>
                                <p>SIGE MVP local · Rol: %s</p>
                            </div>
                            <nav class="nav">
                                <a href="/">Inicio</a>
                                <a href="/proveedores">Proveedores</a>
                                <a href="/ordenes">Ordenes</a>
                                <a href="/recepciones">Recepciones</a>
                                <a href="/facturas">Facturas</a>
                                <a href="/cuentas">CxP</a>
                                <a href="/pagos">Pagos</a>
                                <a href="/reportes">Reportes</a>
                                <a href="/integraciones">Integraciones</a>
                                <a href="/demo">Demo</a>
                                <a href="/db-test">Conexion BD</a>
                            </nav>
                        </header>
                        %s
                        %s
                    </main>
                </body>
                </html>
                """.formatted(HtmlResponse.escape(RoleContext.current().label()), RoleController.form("/"), content);
    }
}

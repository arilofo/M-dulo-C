package sige.moduloc.http;

import com.sun.net.httpserver.HttpExchange;

import java.io.IOException;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

public final class HtmlResponse {
    private HtmlResponse() {
    }

    public static void ok(HttpExchange exchange, String html) throws IOException {
        send(exchange, 200, html, "text/html; charset=utf-8");
    }

    public static void notFound(HttpExchange exchange) throws IOException {
        send(exchange, 404, "<h1>404</h1><p>Ruta no encontrada.</p>", "text/html; charset=utf-8");
    }

    public static void methodNotAllowed(HttpExchange exchange) throws IOException {
        send(exchange, 405, "<h1>405</h1><p>Metodo no permitido.</p>", "text/html; charset=utf-8");
    }

    public static void serverError(HttpExchange exchange, Exception ex) throws IOException {
        String body = "<h1>Error interno</h1><p>" + escape(ErrorMessageMapper.toUserMessage(ex)) + "</p>";
        send(exchange, 500, body, "text/html; charset=utf-8");
    }

    public static void send(HttpExchange exchange, int status, String body, String contentType) throws IOException {
        byte[] bytes = body.getBytes(StandardCharsets.UTF_8);
        exchange.getResponseHeaders().set("Content-Type", contentType);
        exchange.sendResponseHeaders(status, bytes.length);
        try (OutputStream output = exchange.getResponseBody()) {
            output.write(bytes);
        }
    }

    public static String escape(String value) {
        if (value == null) {
            return "";
        }
        return value
                .replace("&", "&amp;")
                .replace("<", "&lt;")
                .replace(">", "&gt;")
                .replace("\"", "&quot;")
                .replace("'", "&#39;");
    }
}

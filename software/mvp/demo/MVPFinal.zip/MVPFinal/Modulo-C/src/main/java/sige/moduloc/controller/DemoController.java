package sige.moduloc.controller;

import com.sun.net.httpserver.HttpExchange;
import sige.moduloc.http.HtmlResponse;
import sige.moduloc.http.PageRenderer;

import java.io.IOException;

public class DemoController {
    public void index(HttpExchange exchange) throws IOException {
        HtmlResponse.ok(exchange, PageRenderer.layout("""
                <section class="section page-heading">
                    <div>
                        <h2>Demo de sustentacion</h2>
                        <p>Ruta guiada para demostrar el flujo completo del Modulo C.</p>
                    </div>
                </section>
                <section class="section demo-list">
                    <ol>
                        <li><a href="/rol">Seleccion de rol</a><span>Elegir Administrador, Gerente / Jefe de Compras o Tesorero.</span></li>
                        <li><a href="/proveedores">Gestion de proveedores</a><span>Registrar o seleccionar proveedor activo.</span></li>
                        <li><a href="/ordenes/nueva">Crear orden de compra</a><span>Generar OC con productos reales de Modulo B.</span></li>
                        <li><a href="/recepciones/nueva">Registrar recepcion</a><span>Recibir parcial o totalmente la OC.</span></li>
                        <li><a href="/recepciones/pendientes-notificar">Actualizar inventario Modulo B</a><span>Procesar IF-03 en productos, movimientos y kardex reales.</span></li>
                        <li><a href="/facturas/nueva">Ingresar factura proveedor</a><span>Crear factura y generar CxP automaticamente.</span></li>
                        <li><a href="/facturas/nueva">Seleccionar tarifa IVA real</a><span>Usar selector cargado desde modulo_d.tarifas_iva.</span></li>
                        <li><a href="/facturas/pendientes-retencion">Procesar retencion Modulo D</a><span>Registrar comprobante y XML reales, luego respuesta IF-05.</span></li>
                        <li><a href="/cuentas">Ver cuenta por pagar generada</a><span>Confirmar saldo, vencimiento, programacion y estado.</span></li>
                        <li><a href="/cuentas">Programar pago</a><span>Asignar fecha programada con sp_programar_pago.</span></li>
                        <li><a href="/pagos/nuevo">Registrar pago</a><span>Pagar parcial o totalmente con sp_registrar_pago.</span></li>
                        <li><a href="/reportes/pagos-vencer">Pagos proximos a vencer</a><span>Ver estado y EXPLAIN de la consulta optimizada.</span></li>
                        <li><a href="/reportes/obligaciones">Obligaciones pendientes</a><span>Reporte por fechas y criterio.</span></li>
                        <li><a href="/reportes/conciliacion">Conciliacion de saldos</a><span>Verificar monto original, pagos, saldo y diferencia.</span></li>
                        <li><a href="/integraciones/modulo-a-costos">IF-01 Modulo A - Costos</a><span>Consultar costos expuestos por SP reales del Modulo C.</span></li>
                    </ol>
                </section>
                """));
    }
}

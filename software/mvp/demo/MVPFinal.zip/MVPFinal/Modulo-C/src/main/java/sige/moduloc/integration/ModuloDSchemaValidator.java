package sige.moduloc.integration;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Arrays;

public final class ModuloDSchemaValidator {
    private static final String SCHEMA = "modulo_d";

    private ModuloDSchemaValidator() {
    }

    public static void validarTablaExiste(Connection connection, String tabla) throws SQLException {
        validarIdentificador(tabla);
        try (PreparedStatement statement = connection.prepareStatement("""
                SELECT COUNT(*) AS total
                FROM information_schema.tables
                WHERE table_schema = ? AND table_name = ?
                """)) {
            statement.setString(1, SCHEMA);
            statement.setString(2, tabla);
            try (ResultSet resultSet = statement.executeQuery()) {
                resultSet.next();
                if (resultSet.getInt("total") > 0) {
                    return;
                }
            }
        }
        try (ResultSet resultSet = connection.createStatement().executeQuery("SHOW TABLES FROM " + SCHEMA + " LIKE '" + tabla + "'")) {
            if (!resultSet.next()) {
                throw schemaException("No existe modulo_d." + tabla + ". Revise o vuelva a cargar DataBase/ScriptsMODS_Externos.sql.");
            }
        }
    }

    public static void validarColumnaExiste(Connection connection, String tabla, String columna) throws SQLException {
        if (!columnaExiste(connection, tabla, columna)) {
            throw missingColumn(tabla, columna);
        }
    }

    public static boolean columnaExiste(Connection connection, String tabla, String columna) throws SQLException {
        validarIdentificador(tabla);
        validarIdentificador(columna);
        try (PreparedStatement statement = connection.prepareStatement("SHOW COLUMNS FROM " + SCHEMA + "." + tabla + " LIKE ?")) {
            statement.setString(1, columna);
            try (ResultSet resultSet = statement.executeQuery()) {
                return resultSet.next();
            }
        }
    }

    public static String columnaDisponible(Connection connection, String tabla, String... columnas) throws SQLException {
        for (String columna : columnas) {
            if (columnaExiste(connection, tabla, columna)) {
                return columna;
            }
        }
        throw schemaException("Advertencia de integracion con Modulo D: la tabla " + tabla
                + " no contiene ninguna de estas columnas esperadas: " + String.join(", ", Arrays.asList(columnas))
                + ". El flujo de Cuentas por Pagar continuara, pero no se pudo registrar la retencion simulada. "
                + "Revise o vuelva a cargar DataBase/ScriptsMODS_Externos.sql.");
    }

    public static SQLException missingColumn(String tabla, String columna) {
        return schemaException("Advertencia de integracion con Modulo D: la tabla " + tabla
                + " no contiene la columna " + columna
                + ". El flujo de Cuentas por Pagar continuara, pero no se pudo registrar la retencion simulada. "
                + "Revise o vuelva a cargar DataBase/ScriptsMODS_Externos.sql.");
    }

    public static SQLException schemaException(String message) {
        return new SQLException(message, "42S22");
    }

    private static void validarIdentificador(String value) throws SQLException {
        if (value == null || !value.matches("[A-Za-z0-9_]+")) {
            throw schemaException("Identificador invalido para diagnostico de esquema Modulo D: " + value);
        }
    }
}

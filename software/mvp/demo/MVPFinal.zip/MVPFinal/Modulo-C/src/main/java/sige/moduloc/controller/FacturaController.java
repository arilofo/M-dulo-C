package sige.moduloc.controller;

import com.sun.net.httpserver.HttpExchange;
import sige.moduloc.http.FormParser;
import sige.moduloc.http.HtmlResponse;
import sige.moduloc.http.PageRenderer;
import sige.moduloc.http.ViewUtil;
import sige.moduloc.security.AppRole;
import sige.moduloc.service.MvpService;

import java.io.IOException;
import java.util.List;
import java.util.Map;

public class FacturaController extends WebControllerSupport {
    private final MvpService service;

    public FacturaController(MvpService service) {
        this.service = service;
    }

    public void listar(HttpExchange exchange) throws IOException {
        try {
            HtmlResponse.ok(exchange, PageRenderer.layout("""
                    <section class="section page-heading">
                        <div><h2>Facturas de proveedor</h2><p>La cuenta por pagar se genera automaticamente al ingresar la factura.</p></div>
                        <div class="actions">
                            <a class="button" href="/facturas/pendientes-retencion">Pendientes de retencion</a>
                            <a class="button primary" href="/facturas/nueva">Nueva factura</a>
                        </div>
                    </section>
                    %s
                    %s
                    """.formatted(ViewUtil.message(FormParser.parseQuery(exchange)), ViewUtil.table(service.facturas()))));
        } catch (Exception ex) {
            renderError(exchange, "No se pudieron cargar las facturas.", ex, "/");
        }
    }

    public void nueva(HttpExchange exchange) throws IOException {
        try {
            requireRole(AppRole.ADMINISTRADOR, AppRole.JEFE_COMPRAS);
            Map<String, String> query = FormParser.parseQuery(exchange);
            Integer selectedOc = parseOptionalInt(query.get("id_oc"));
            Integer selectedRecepcion = parseOptionalInt(query.get("id_recepcion"));
            List<Map<String, Object>> tarifasIva = service.tarifasIvaModuloD();
            Map<String, Object> referencia = service.referenciaFactura(selectedOc, selectedRecepcion);
            if (!referencia.isEmpty() && selectedRecepcion != null) {
                selectedOc = ((Number) referencia.get("id_oc")).intValue();
            }
            List<Map<String, Object>> detalleRecepcion = selectedRecepcion == null
                    ? List.of()
                    : service.detalleRecepcionFactura(selectedRecepcion);
            String baseSugerida = valueOrBlank(referencia.get("monto_pendiente_base"));
            String baseReferencia = valueOrBlank(referencia.get("base_sugerida"));
            String maxBase = valueOrBlank(referencia.get("monto_pendiente_base"));
            String proveedorField = proveedorField(referencia);
            String ordenField = selectedOc == null
                    ? """
                    <label>Orden compra regular<select name="id_oc"><option value="">Cargue una referencia regular</option>%s</select></label>
                    """.formatted(orderOptions(service.ordenesFacturables(), selectedOc))
                    : "<input type=\"hidden\" name=\"id_oc\" value=\"" + ViewUtil.e(selectedOc) + "\">";
            String recepcionField = selectedRecepcion == null
                    ? """
                    <label>Recepcion regular<select name="id_recepcion"><option value="">Cargue una recepcion regular</option>%s</select></label>
                    """.formatted(recepcionOptions(service.recepcionesActivas(), selectedRecepcion))
                    : "<input type=\"hidden\" name=\"id_recepcion\" value=\"" + ViewUtil.e(selectedRecepcion) + "\">";
            String tarifaStatus = tarifasIva.isEmpty()
                    ? """
                    <div class="status error">
                        <strong>Error de integracion con Modulo D - Impuestos.</strong>
                        <p>No existen tarifas IVA activas en <code>modulo_d.tarifas_iva</code>. Verifique que el esquema modulo_d este cargado y tenga datos activos.</p>
                    </div>
                    """
                    : "";
            HtmlResponse.ok(exchange, PageRenderer.layout("""
                    <section class="section page-heading">
                        <div><h2>Nueva factura proveedor</h2><p>Usa <code>sp_ingresar_factura_proveedor</code>.</p></div>
                        <a class="button" href="/facturas">Volver</a>
                    </section>
                    <div class="status">
                        <strong>Fecha de emision</strong>
                        <p>La fecha de emision se registra automaticamente por el procedimiento almacenado.</p>
                    </div>
                    %s
                    <form class="form-panel" method="get" action="/facturas/nueva">
                        <h3>Referencia real de orden/recepcion</h3>
                        <div class="form-grid">
                            <label>Orden compra regular
                                <select name="id_oc">
                                    <option value="">Seleccione orden...</option>
                                    %s
                                </select>
                            </label>
                            <label>Recepcion regular
                                <select name="id_recepcion">
                                    <option value="">Opcional si solo desea referenciar la orden</option>
                                    %s
                                </select>
                            </label>
                        </div>
                        <div class="form-actions"><button class="button" type="submit">Cargar referencia</button></div>
                    </form>
                    %s
                    <form class="form-panel" method="post" action="/facturas/crear">
                        <input type="hidden" id="base-sugerida" value="%s">
                        <input type="hidden" id="base-referencia" value="%s">
                        <div class="form-grid">
                            %s
                            %s
                            %s
                            <label>Numero factura<input name="numero_factura" maxlength="20" required></label>
                            <label>Serie<input name="numero_serie" maxlength="7" required></label>
                            <label>Codigo sustento<input name="codigo_sustento" maxlength="2" required value="01"></label>
                            <label>Base imponible
                                <input id="base-imponible" name="base_imponible" type="number" step="0.01" min="0.01" max="%s" required value="%s">
                                <span class="hint">Referencia: %s. Pendiente facturable: %s.</span>
                            </label>
                            <label>Valor IVA calculado
                                <input id="valor-iva-calculado" type="number" step="0.01" readonly value="0.00">
                            </label>
                            <label>Tipo bien/servicio<input name="tipo_bien_servicio" maxlength="10" value="bien"></label>
                            <label>Tarifa IVA Modulo D
                                <select id="tarifa-iva" name="ref_mod_d_tarifa_id" required>
                                    <option value="" data-porcentaje="0" data-etiqueta="">Seleccione tarifa...</option>
                                    %s
                                </select>
                            </label>
                            <label>Factura excepcional
                                <select name="factura_excepcional">
                                    <option value="0">No</option>
                                    <option value="1">Si</option>
                                </select>
                            </label>
                            <label>Motivo excepcion<input name="motivo_excepcion" maxlength="300"></label>
                            <label>Usuario autorizador<input name="usuario_autorizador" maxlength="100"></label>
                        </div>
                        <div class="form-actions">
                            <button class="button primary" type="submit">Ingresar factura</button>
                            <a class="button" href="/facturas">Cancelar</a>
                        </div>
                    </form>
                    <section class="section status" id="resumen-factura">
                        <strong>Resumen de factura</strong>
                        <p>Base imponible: <span data-resumen-base>0.00</span></p>
                        <p>Tarifa IVA seleccionada: <span data-resumen-tarifa>Sin seleccionar</span></p>
                        <p>Porcentaje IVA: <span data-resumen-porcentaje>0.00%%</span></p>
                        <p>Valor IVA calculado: <span data-resumen-iva>0.00</span></p>
                        <p>Total factura estimado: <span data-resumen-total>0.00</span></p>
                        <p class="hint" data-resumen-advertencia></p>
                    </section>
                    <script>
                    (function () {
                        var baseInput = document.getElementById('base-imponible');
                        var tarifaSelect = document.getElementById('tarifa-iva');
                        var ivaInput = document.getElementById('valor-iva-calculado');
                        var baseReferencia = Number(document.getElementById('base-referencia').value || 0);
                        function money(value) {
                            return (Math.round((Number(value) + Number.EPSILON) * 100) / 100).toFixed(2);
                        }
                        function recalc() {
                            var base = Number(baseInput.value || 0);
                            var option = tarifaSelect.options[tarifaSelect.selectedIndex];
                            var porcentaje = Number(option ? option.dataset.porcentaje || 0 : 0);
                            var etiqueta = option ? option.dataset.etiqueta || option.textContent : '';
                            var iva = base * porcentaje / 100;
                            var total = base + iva;
                            ivaInput.value = money(iva);
                            document.querySelector('[data-resumen-base]').textContent = money(base);
                            document.querySelector('[data-resumen-tarifa]').textContent = etiqueta || 'Sin seleccionar';
                            document.querySelector('[data-resumen-porcentaje]').textContent = money(porcentaje) + '%%';
                            document.querySelector('[data-resumen-iva]').textContent = money(iva);
                            document.querySelector('[data-resumen-total]').textContent = money(total);
                            var warning = '';
                            if (baseReferencia > 0 && Math.abs(base - baseReferencia) >= 0.01) {
                                warning = 'Advertencia: la base imponible difiere del valor sugerido por la orden/recepcion.';
                            }
                            document.querySelector('[data-resumen-advertencia]').textContent = warning;
                        }
                        if (baseInput && tarifaSelect && ivaInput) {
                            baseInput.addEventListener('input', recalc);
                            tarifaSelect.addEventListener('change', recalc);
                            recalc();
                        }
                    })();
                    </script>
                    """.formatted(
                    tarifaStatus,
                    orderOptions(service.ordenesFacturables(), selectedOc),
                    recepcionOptions(service.recepcionesActivas(), selectedRecepcion),
                    referenciaPanel(referencia, detalleRecepcion, selectedRecepcion),
                    baseSugerida,
                    baseReferencia,
                    proveedorField,
                    ordenField,
                    recepcionField,
                    maxBase.isBlank() ? "999999999" : maxBase,
                    baseSugerida,
                    baseReferencia.isBlank() ? "sin referencia cargada" : baseReferencia,
                    maxBase.isBlank() ? "sin calcular" : maxBase,
                    tarifaOptions(tarifasIva))));
        } catch (Exception ex) {
            renderError(exchange, "No se pudo abrir el formulario de factura.", ex, "/facturas");
        }
    }

    public void crear(HttpExchange exchange) throws IOException {
        try {
            requireRole(AppRole.ADMINISTRADOR, AppRole.JEFE_COMPRAS);
            service.crearFactura(FormParser.parseForm(exchange));
            redirect(exchange, "/facturas", "ok", "Factura ingresada. La cuenta por pagar fue generada automaticamente.");
        } catch (Exception ex) {
            renderError(exchange, "No se pudo ingresar la factura.", ex, "/facturas/nueva");
        }
    }

    public void pendientesRetencion(HttpExchange exchange) throws IOException {
        try {
            HtmlResponse.ok(exchange, PageRenderer.layout("""
                    <section class="section page-heading">
                        <div><h2>Facturas pendientes de retencion</h2><p>Registro real en <code>modulo_d.comprobantes_retencion</code> y respuesta IF-05.</p></div>
                        <a class="button" href="/facturas">Volver</a>
                    </section>
                    %s
                    %s
                    %s
                    """.formatted(ViewUtil.message(FormParser.parseQuery(exchange)), formRetencion(), ViewUtil.table(service.facturasPendientesRetencion()))));
        } catch (Exception ex) {
            renderError(exchange, "No se pudieron cargar las facturas pendientes.", ex, "/facturas");
        }
    }

    public void marcarRetencion(HttpExchange exchange) throws IOException {
        try {
            requireRole(AppRole.ADMINISTRADOR, AppRole.JEFE_COMPRAS);
            service.marcarRetencion(FormParser.parseForm(exchange));
            redirect(exchange, "/facturas/pendientes-retencion", "ok", "Retencion registrada en Modulo D y factura actualizada por IF-05.");
        } catch (Exception ex) {
            renderError(exchange, "No se pudo registrar la retencion.", ex, "/facturas/pendientes-retencion");
        }
    }

    private String formRetencion() throws Exception {
        return """
                <form class="form-panel" method="post" action="/facturas/marcar-retencion">
                    <div class="form-grid">
                        <label>Factura pendiente
                            <select name="id_factura" required>
                                <option value="">Seleccione...</option>
                                %s
                            </select>
                        </label>
                        <label>Retencion renta Modulo D
                            <select name="id_ret_renta" required>
                                <option value="">Seleccione...</option>
                                %s
                            </select>
                        </label>
                        <label>Retencion IVA Modulo D
                            <select name="id_ret_iva" required>
                                <option value="">Seleccione...</option>
                                %s
                            </select>
                        </label>
                        <label>Numero comprobante retencion<input name="numero_comprobante" maxlength="20" required></label>
                        <label>Numero autorizacion<input name="num_autorizacion" maxlength="49" required></label>
                    </div>
                    <div class="form-actions"><button class="button primary" type="submit">Registrar retencion real</button></div>
                </form>
                """.formatted(
                ViewUtil.options(service.facturasPendientesRetencion(), "idFactura", "idFactura", "rucProveedor", "baseImponible"),
                ViewUtil.options(service.retencionesRentaConfig(), "id_ret_renta", "codigo_sri", "concepto", "porcentaje_retencion"),
                ViewUtil.options(service.retencionesIvaConfig(), "id_ret_iva", "codigo_sri", "descripcion", "porcentaje_retencion"));
    }

    private String tarifaOptions(List<Map<String, Object>> tarifas) {
        StringBuilder html = new StringBuilder();
        for (Map<String, Object> tarifa : tarifas) {
            String etiqueta = tarifa.get("codigo") + " - " + tarifa.get("porcentaje") + "% - " + tarifa.get("descripcion");
            html.append("<option value=\"").append(ViewUtil.e(tarifa.get("id_tarifa"))).append("\" data-porcentaje=\"")
                    .append(ViewUtil.e(tarifa.get("porcentaje"))).append("\" data-etiqueta=\"")
                    .append(ViewUtil.e(etiqueta)).append("\">")
                    .append(ViewUtil.e(tarifa.get("id_tarifa"))).append(" - ")
                    .append(ViewUtil.e(tarifa.get("codigo"))).append(" - ")
                    .append(ViewUtil.e(tarifa.get("porcentaje"))).append("% - ")
                    .append(ViewUtil.e(tarifa.get("descripcion"))).append("</option>");
        }
        return html.toString();
    }

    private String proveedorField(Map<String, Object> referencia) throws Exception {
        if (!referencia.isEmpty()) {
            return """
                    <label>Proveedor
                        <input value="%s" readonly>
                        <input type="hidden" name="id_proveedor" value="%s">
                    </label>
                    """.formatted(ViewUtil.e(referencia.get("razon_social")), ViewUtil.e(referencia.get("id_proveedor")));
        }
        return """
                <label>Proveedor<select name="id_proveedor" required><option value="">Seleccione...</option>%s</select></label>
                """.formatted(ViewUtil.options(service.proveedoresActivos(), "id_proveedor", "razon_social", "identificacion"));
    }

    private String referenciaPanel(Map<String, Object> referencia, List<Map<String, Object>> detallesRecepcion, Integer selectedRecepcion) {
        if (referencia.isEmpty()) {
            return """
                    <div class="status">
                        <strong>Referencia pendiente</strong>
                        <p>Cargue una orden y, preferiblemente, una recepcion para sugerir la base imponible con datos reales.</p>
                    </div>
                    """;
        }
        String aviso = selectedRecepcion == null
                ? "<p class=\"hint\">Se recomienda facturar contra una recepcion registrada.</p>"
                : "";
        return """
                <section class="section status">
                    <strong>Referencia cargada</strong>
                    <p>Orden: %s | Proveedor: %s | Total orden: %s | Estado: %s</p>
                    <p>Subtotal recepcion seleccionada: %s | Base ya facturada en referencia: %s | Pendiente base: %s</p>
                    %s
                </section>
                %s
                """.formatted(
                ViewUtil.e(referencia.get("numero_oc")),
                ViewUtil.e(referencia.get("razon_social")),
                ViewUtil.e(referencia.get("total_estimado")),
                ViewUtil.e(referencia.get("estado")),
                ViewUtil.e(referencia.get("subtotal_recepcion")),
                ViewUtil.e(referencia.get("base_facturada_referencia")),
                ViewUtil.e(referencia.get("monto_pendiente_base")),
                aviso,
                detallesRecepcion.isEmpty() ? "" : "<section class=\"section\"><h3>Productos recibidos</h3>" + ViewUtil.table(detallesRecepcion) + "</section>");
    }

    private String orderOptions(List<Map<String, Object>> ordenes, Integer selected) {
        StringBuilder html = new StringBuilder();
        for (Map<String, Object> row : ordenes) {
            String id = String.valueOf(row.get("id_oc"));
            String selectedAttr = selected != null && id.equals(String.valueOf(selected)) ? " selected" : "";
            html.append("<option value=\"").append(ViewUtil.e(id)).append("\"").append(selectedAttr).append(">")
                    .append(ViewUtil.e(row.get("numero_oc"))).append(" - ")
                    .append(ViewUtil.e(row.get("razon_social"))).append(" - ")
                    .append(ViewUtil.e(row.get("estado"))).append(" - total ")
                    .append(ViewUtil.e(row.get("total_estimado"))).append("</option>");
        }
        return html.toString();
    }

    private String recepcionOptions(List<Map<String, Object>> recepciones, Integer selected) {
        StringBuilder html = new StringBuilder();
        for (Map<String, Object> row : recepciones) {
            String id = String.valueOf(row.get("id_recepcion"));
            String selectedAttr = selected != null && id.equals(String.valueOf(selected)) ? " selected" : "";
            html.append("<option value=\"").append(ViewUtil.e(id)).append("\"").append(selectedAttr).append(">")
                    .append(ViewUtil.e(id)).append(" - ")
                    .append(ViewUtil.e(row.get("numero_oc"))).append(" - ")
                    .append(ViewUtil.e(row.get("razon_social"))).append(" - ")
                    .append(ViewUtil.e(row.get("tipo_recepcion"))).append("</option>");
        }
        return html.toString();
    }

    private Integer parseOptionalInt(String value) {
        if (value == null || value.isBlank()) {
            return null;
        }
        return Integer.parseInt(value);
    }

    private String valueOrBlank(Object value) {
        return value == null ? "" : String.valueOf(value);
    }
}

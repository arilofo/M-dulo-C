package sige.moduloc.controller;

import com.sun.net.httpserver.HttpExchange;
import sige.moduloc.http.ErrorMessageMapper;
import sige.moduloc.http.HtmlResponse;
import sige.moduloc.http.PageRenderer;
import sige.moduloc.security.AppRole;
import sige.moduloc.security.RoleGuard;

import java.io.IOException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

abstract class WebControllerSupport {
    protected void requireRole(AppRole... roles) {
        RoleGuard.require(roles);
    }

    protected void redirect(HttpExchange exchange, String path, String key, String message) throws IOException {
        String location = path;
        if (key != null && message != null) {
            location += "?" + key + "=" + URLEncoder.encode(message, StandardCharsets.UTF_8);
        }
        exchange.getResponseHeaders().set("Location", location);
        exchange.sendResponseHeaders(303, -1);
        exchange.close();
    }

    protected void renderError(HttpExchange exchange, String title, Exception ex, String backUrl) throws IOException {
        String detail = ErrorMessageMapper.toUserMessage(ex);
        HtmlResponse.ok(exchange, PageRenderer.layout("""
                <section class="section">
                    <div class="status error">
                        <strong>%s</strong>
                        <p>%s</p>
                        <p><a class="button" href="%s">Volver</a></p>
                    </div>
                </section>
                """.formatted(HtmlResponse.escape(title), HtmlResponse.escape(detail), HtmlResponse.escape(backUrl))));
    }
}

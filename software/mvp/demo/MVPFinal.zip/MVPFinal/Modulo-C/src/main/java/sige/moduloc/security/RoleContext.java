package sige.moduloc.security;

public final class RoleContext {
    private static final ThreadLocal<AppRole> CURRENT = ThreadLocal.withInitial(() -> AppRole.JEFE_COMPRAS);

    private RoleContext() {
    }

    public static AppRole current() {
        return CURRENT.get();
    }

    public static void set(AppRole role) {
        CURRENT.set(role == null ? AppRole.JEFE_COMPRAS : role);
    }

    public static void clear() {
        CURRENT.remove();
    }
}

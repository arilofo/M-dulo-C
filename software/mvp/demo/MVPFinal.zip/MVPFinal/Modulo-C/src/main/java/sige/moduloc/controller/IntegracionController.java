package sige.moduloc.controller;

import com.sun.net.httpserver.HttpExchange;
import sige.moduloc.http.FormParser;
import sige.moduloc.http.HtmlResponse;
import sige.moduloc.http.PageRenderer;
import sige.moduloc.http.ViewUtil;
import sige.moduloc.service.MvpService;

import java.io.IOException;
import java.util.List;
import java.util.Map;

public class IntegracionController extends WebControllerSupport {
    private final MvpService service;

    public IntegracionController(MvpService service) {
        this.service = service;
    }

    public void index(HttpExchange exchange) throws IOException {
        HtmlResponse.ok(exchange, PageRenderer.layout("""
                <section class="section page-heading">
                    <div><h2>Integraciones</h2><p>Pantallas de verificacion con modulos externos usando datos y SP reales.</p></div>
                </section>
                <section class="section">
                    <div class="grid">
                        <article class="module">
                            <h2><a href="/integraciones/modulo-a-costos">IF-01 Modulo A - Costos</a></h2>
                            <p>Consulta costos expuestos por Modulo C mediante procedimientos almacenados reales.</p>
                        </article>
                        <article class="module">
                            <h2><a href="/ordenes/nueva">IF-02 Modulo B - Solicitud</a></h2>
                            <p>Referencia logica manual porque el script externo no define una fuente real de solicitudes de compra.</p>
                        </article>
                        <article class="module">
                            <h2><a href="/recepciones/pendientes-notificar">IF-03 Modulo B - Inventario</a></h2>
                            <p>Actualizacion real de inventario al registrar recepciones.</p>
                        </article>
                        <article class="module">
                            <h2><a href="/facturas/pendientes-retencion">IF-05/IF-06 Modulo D - Impuestos</a></h2>
                            <p>Retenciones reales con tablas de impuestos y respuesta al Modulo C.</p>
                        </article>
                    </div>
                </section>
                """));
    }

    public void moduloACostos(HttpExchange exchange) throws IOException {
        try {
            HtmlResponse.ok(exchange, PageRenderer.layout("""
                    <section class="section page-heading">
                        <div><h2>IF-01 Modulo A - Consulta de costos</h2><p>Usa <code>sp_consultar_precio_costo_producto</code> y <code>sp_consultar_ultimo_costo_adquisicion</code>.</p></div>
                        <a class="button" href="/integraciones">Volver</a>
                    </section>
                    %s
                    %s
                    """.formatted(ViewUtil.message(FormParser.parseQuery(exchange)), form("", "5"))));
        } catch (Exception ex) {
            renderError(exchange, "No se pudo abrir la integracion IF-01.", ex, "/integraciones");
        }
    }

    public void consultarModuloACostos(HttpExchange exchange) throws IOException {
        try {
            Map<String, String> form = FormParser.parseForm(exchange);
            List<Map<String, Object>> precioCosto = service.costoProductoModuloA(form);
            List<Map<String, Object>> ultimosCostos = service.ultimosCostosModuloA(form);
            HtmlResponse.ok(exchange, PageRenderer.layout("""
                    <section class="section page-heading">
                        <div><h2>IF-01 Modulo A - Consulta de costos</h2><p>Resultado real desde procedimientos almacenados del Modulo C.</p></div>
                        <a class="button" href="/integraciones">Volver</a>
                    </section>
                    %s
                    <section class="section">
                        <h3>sp_consultar_precio_costo_producto</h3>
                        %s
                    </section>
                    <section class="section">
                        <h3>sp_consultar_ultimo_costo_adquisicion</h3>
                        %s
                    </section>
                    """.formatted(
                    form(form.getOrDefault("id_producto", ""), form.getOrDefault("limite", "5")),
                    tableOrEmpty(precioCosto),
                    tableOrEmpty(ultimosCostos))));
        } catch (Exception ex) {
            renderError(exchange, "No se pudo consultar costos para Modulo A.", ex, "/integraciones/modulo-a-costos");
        }
    }

    private String form(String productoId, String limite) {
        return """
                <form class="form-panel" method="post" action="/integraciones/modulo-a-costos/consultar">
                    <div class="form-grid">
                        <label>ID producto Modulo B
                            <input name="id_producto" type="number" min="1" required value="%s">
                        </label>
                        <label>Limite ultimos costos
                            <input name="limite" type="number" min="1" max="50" value="%s">
                        </label>
                    </div>
                    <div class="form-actions">
                        <button class="button primary" type="submit">Consultar costos</button>
                    </div>
                </form>
                """.formatted(ViewUtil.e(productoId), ViewUtil.e(limite));
    }

    private String tableOrEmpty(List<Map<String, Object>> rows) {
        if (rows.isEmpty()) {
            return """
                    <div class="status">
                        <strong>Sin informacion.</strong>
                        <p>El procedimiento no devolvio datos para el producto consultado.</p>
                    </div>
                    """;
        }
        return ViewUtil.table(rows);
    }
}

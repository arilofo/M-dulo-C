package sige.moduloc.controller;

import com.sun.net.httpserver.HttpExchange;
import sige.moduloc.http.FormParser;
import sige.moduloc.http.HtmlResponse;
import sige.moduloc.http.PageRenderer;
import sige.moduloc.http.ViewUtil;
import sige.moduloc.security.AppRole;
import sige.moduloc.service.MvpService;

import java.io.IOException;

public class CuentaController extends WebControllerSupport {
    private final MvpService service;

    public CuentaController(MvpService service) {
        this.service = service;
    }

    public void listar(HttpExchange exchange) throws IOException {
        try {
            requireRole(AppRole.ADMINISTRADOR, AppRole.TESORERO);
            HtmlResponse.ok(exchange, PageRenderer.layout("""
                    <section class="section page-heading">
                        <div><h2>Cuentas por pagar</h2><p>Saldos, vencimientos, programacion y estado.</p></div>
                        <div class="actions">
                            <a class="button" href="/cuentas/estado-proveedor">Estado proveedor</a>
                            <a class="button" href="/cuentas/pendientes">Ver pendientes</a>
                        </div>
                    </section>
                    %s
                    %s
                    """.formatted(ViewUtil.message(FormParser.parseQuery(exchange)), cuentasConProgramacion())));
        } catch (Exception ex) {
            renderError(exchange, "No se pudieron cargar las cuentas.", ex, "/");
        }
    }

    public void pendientes(HttpExchange exchange) throws IOException {
        try {
            requireRole(AppRole.ADMINISTRADOR, AppRole.TESORERO);
            HtmlResponse.ok(exchange, PageRenderer.layout("""
                    <section class="section page-heading">
                        <div><h2>Cuentas pendientes</h2><p>Vista <code>vw_cuentas_pendientes</code>.</p></div>
                        <a class="button" href="/cuentas">Volver</a>
                    </section>
                    %s
                    """.formatted(ViewUtil.table(service.cuentasPendientes()))));
        } catch (Exception ex) {
            renderError(exchange, "No se pudieron cargar las cuentas pendientes.", ex, "/cuentas");
        }
    }

    public void estadoProveedor(HttpExchange exchange) throws IOException {
        try {
            requireRole(AppRole.ADMINISTRADOR, AppRole.TESORERO);
            var query = FormParser.parseQuery(exchange);
            HtmlResponse.ok(exchange, PageRenderer.layout("""
                    <section class="section page-heading">
                        <div><h2>Estado de cuenta por proveedor</h2><p>Usa <code>sp_estado_cuenta_proveedor</code>.</p></div>
                        <a class="button" href="/cuentas">Volver</a>
                    </section>
                    <form class="form-panel" method="get" action="/cuentas/estado-proveedor">
                        <div class="form-grid">
                            <label>Proveedor<select name="id_proveedor" required><option value="">Seleccione...</option>%s</select></label>
                            <label>Desde<input type="date" name="desde" value="%s"></label>
                            <label>Hasta<input type="date" name="hasta" value="%s"></label>
                        </div>
                        <div class="form-actions"><button class="button primary" type="submit">Consultar</button></div>
                    </form>
                    %s
                    """.formatted(
                    ViewUtil.options(service.proveedoresActivos(), "id_proveedor", "razon_social", "identificacion"),
                    ViewUtil.e(query.getOrDefault("desde", "")),
                    ViewUtil.e(query.getOrDefault("hasta", "")),
                    ViewUtil.table(service.estadoProveedor(query)))));
        } catch (Exception ex) {
            renderError(exchange, "No se pudo cargar el estado de cuenta.", ex, "/cuentas");
        }
    }

    public void programarPago(HttpExchange exchange) throws IOException {
        try {
            requireRole(AppRole.ADMINISTRADOR, AppRole.TESORERO);
            service.programarPago(FormParser.parseForm(exchange));
            redirect(exchange, "/cuentas", "ok", "Pago programado correctamente.");
        } catch (Exception ex) {
            renderError(exchange, "No se pudo programar el pago.", ex, "/cuentas");
        }
    }

    private String cuentasConProgramacion() throws Exception {
        var rows = service.cuentas();
        if (rows.isEmpty()) {
            return ViewUtil.table(rows);
        }
        StringBuilder html = new StringBuilder("<section class=\"section table-wrap\"><table><thead><tr><th>ID</th><th>Proveedor</th><th>Factura</th><th>Monto</th><th>Saldo</th><th>Vence</th><th>Programada</th><th>Estado</th><th>Acciones</th></tr></thead><tbody>");
        for (var row : rows) {
            Object id = row.get("id_cxp");
            html.append("<tr><td>").append(ViewUtil.e(id)).append("</td><td>").append(ViewUtil.e(row.get("razon_social")))
                    .append("</td><td>").append(ViewUtil.e(row.get("numero_factura_proveedor"))).append("</td><td>").append(ViewUtil.e(row.get("monto_original")))
                    .append("</td><td>").append(ViewUtil.e(row.get("saldo_pendiente"))).append("</td><td>").append(ViewUtil.e(row.get("fecha_vencimiento")))
                    .append("</td><td>").append(ViewUtil.e(row.get("fecha_programada"))).append("</td><td>").append(ViewUtil.e(row.get("estado")))
                    .append("</td><td class=\"actions\"><form method=\"post\" action=\"/cuentas/programar-pago\" class=\"inline-form\"><input type=\"hidden\" name=\"id_cxp\" value=\"")
                    .append(ViewUtil.e(id)).append("\"><input type=\"date\" name=\"fecha_programada\" required><button class=\"button compact\" type=\"submit\">Programar</button></form>")
                    .append("<a class=\"button compact primary\" href=\"/pagos/nuevo?cuentaId=").append(ViewUtil.e(id)).append("\">Pagar</a></td></tr>");
        }
        return html.append("</tbody></table></section>").toString();
    }
}

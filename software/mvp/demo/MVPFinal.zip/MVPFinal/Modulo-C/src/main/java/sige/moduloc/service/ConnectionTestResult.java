package sige.moduloc.service;

public record ConnectionTestResult(boolean ok, String message) {
}

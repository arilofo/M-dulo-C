package sige.moduloc.http;

import java.util.List;
import java.util.Map;

public final class ViewUtil {
    private ViewUtil() {
    }

    public static String table(List<Map<String, Object>> rows) {
        if (rows == null || rows.isEmpty()) {
            return "<section class=\"section status\"><p>No hay datos para mostrar.</p></section>";
        }
        StringBuilder html = new StringBuilder("<section class=\"section table-wrap\"><table><thead><tr>");
        for (String column : rows.get(0).keySet()) {
            html.append("<th>").append(e(column)).append("</th>");
        }
        html.append("</tr></thead><tbody>");
        for (Map<String, Object> row : rows) {
            html.append("<tr>");
            for (Object value : row.values()) {
                html.append("<td>").append(e(value)).append("</td>");
            }
            html.append("</tr>");
        }
        html.append("</tbody></table></section>");
        return html.toString();
    }

    public static String options(List<Map<String, Object>> rows, String valueColumn, String... labelColumns) {
        StringBuilder html = new StringBuilder();
        for (Map<String, Object> row : rows) {
            html.append("<option value=\"").append(e(row.get(valueColumn))).append("\">");
            for (int i = 0; i < labelColumns.length; i++) {
                if (i > 0) {
                    html.append(" - ");
                }
                html.append(e(row.get(labelColumns[i])));
            }
            html.append("</option>");
        }
        return html.toString();
    }

    public static String message(Map<String, String> query) {
        if (query.containsKey("ok")) {
            return "<section class=\"section\"><div class=\"status ok\">" + e(query.get("ok")) + "</div></section>";
        }
        if (query.containsKey("error")) {
            return "<section class=\"section\"><div class=\"status error\">" + e(query.get("error")) + "</div></section>";
        }
        if (query.containsKey("warning")) {
            return "<section class=\"section\"><div class=\"status\">" + e(query.get("warning")) + "</div></section>";
        }
        return "";
    }

    public static String e(Object value) {
        return HtmlResponse.escape(value == null ? "" : value.toString());
    }
}

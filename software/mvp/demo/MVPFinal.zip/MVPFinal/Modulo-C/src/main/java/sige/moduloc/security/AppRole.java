package sige.moduloc.security;

public enum AppRole {
    ADMINISTRADOR("Administrador"),
    JEFE_COMPRAS("Gerente / Jefe de Compras"),
    TESORERO("Tesorero");

    private final String label;

    AppRole(String label) {
        this.label = label;
    }

    public String label() {
        return label;
    }

    public static AppRole fromCookie(String value) {
        if (value == null || value.isBlank()) {
            return JEFE_COMPRAS;
        }
        try {
            return AppRole.valueOf(value);
        } catch (IllegalArgumentException ex) {
            return JEFE_COMPRAS;
        }
    }
}

package sige.moduloc.controller;

import com.sun.net.httpserver.HttpExchange;
import sige.moduloc.http.FormParser;
import sige.moduloc.http.ErrorMessageMapper;
import sige.moduloc.http.HtmlResponse;
import sige.moduloc.http.PageRenderer;
import sige.moduloc.model.Proveedor;
import sige.moduloc.security.AppRole;
import sige.moduloc.security.RoleGuard;
import sige.moduloc.service.ProveedorService;

import java.io.IOException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Map;
import java.util.Optional;

public class ProveedorController {
    private final ProveedorService proveedorService;

    public ProveedorController(ProveedorService proveedorService) {
        this.proveedorService = proveedorService;
    }

    public void listar(HttpExchange exchange) throws IOException {
        try {
            Map<String, String> query = FormParser.parseQuery(exchange);
            List<Proveedor> proveedores = proveedorService.listarActivos();
            StringBuilder rows = new StringBuilder();
            for (Proveedor proveedor : proveedores) {
                rows.append("""
                        <tr>
                            <td>%d</td>
                            <td>%s</td>
                            <td>%s</td>
                            <td>%s</td>
                            <td>%d</td>
                            <td>%s</td>
                            <td class="actions">
                                <a class="button compact" href="/proveedores/editar?id=%d">Editar</a>
                                <form method="post" action="/proveedores/eliminar" class="inline-form">
                                    <input type="hidden" name="id_proveedor" value="%d">
                                    <button class="button danger compact" type="submit">Desactivar</button>
                                </form>
                            </td>
                        </tr>
                        """.formatted(
                        proveedor.idProveedor(),
                        escape(proveedor.tipoProveedor()),
                        escape(proveedor.identificacion()),
                        escape(proveedor.razonSocial()),
                        proveedor.diasCredito(),
                        escape(emptyToDash(proveedor.calificacion())),
                        proveedor.idProveedor(),
                        proveedor.idProveedor()
                ));
            }

            if (rows.isEmpty()) {
                rows.append("""
                        <tr><td colspan="7" class="empty">No hay proveedores activos registrados.</td></tr>
                        """);
            }

            HtmlResponse.ok(exchange, PageRenderer.layout("""
                    <section class="section page-heading">
                        <div>
                            <h2>Proveedores</h2>
                            <p>Listado operativo de proveedores activos. Las bajas usan borrado logico.</p>
                        </div>
                        <a class="button" href="/proveedores/nuevo">Nuevo proveedor</a>
                    </section>
                    %s
                    <section class="section table-wrap">
                        <table>
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Tipo</th>
                                    <th>Identificacion</th>
                                    <th>Razon social</th>
                                    <th>Dias credito</th>
                                    <th>Calificacion</th>
                                    <th>Acciones</th>
                                </tr>
                            </thead>
                            <tbody>%s</tbody>
                        </table>
                    </section>
                    """.formatted(messageBlock(query), rows)));
        } catch (Exception ex) {
            renderError(exchange, "No se pudo listar proveedores.", ex);
        }
    }

    public void nuevo(HttpExchange exchange) throws IOException {
        HtmlResponse.ok(exchange, PageRenderer.layout("""
                <section class="section page-heading">
                    <div>
                        <h2>Nuevo proveedor</h2>
                        <p>El registro se realiza con <code>sp_registrar_proveedor</code>.</p>
                    </div>
                    <a class="button" href="/proveedores">Volver</a>
                </section>
                %s
                """.formatted(formCrear())));
    }

    public void crear(HttpExchange exchange) throws IOException {
        try {
            RoleGuard.require(AppRole.ADMINISTRADOR, AppRole.JEFE_COMPRAS);
            proveedorService.registrar(FormParser.parseForm(exchange));
            redirect(exchange, "/proveedores?ok=Proveedor registrado correctamente.");
        } catch (Exception ex) {
            renderError(exchange, "No se pudo registrar el proveedor.", ex);
        }
    }

    public void editar(HttpExchange exchange) throws IOException {
        try {
            int id = Integer.parseInt(FormParser.parseQuery(exchange).getOrDefault("id", "0"));
            Optional<Proveedor> proveedor = proveedorService.buscarActivoPorId(id);
            if (proveedor.isEmpty()) {
                redirect(exchange, "/proveedores?error=El proveedor no existe o esta inactivo.");
                return;
            }
            HtmlResponse.ok(exchange, PageRenderer.layout("""
                    <section class="section page-heading">
                        <div>
                            <h2>Editar proveedor</h2>
                            <p>La actualizacion se realiza con <code>sp_actualizar_proveedor</code>.</p>
                        </div>
                        <a class="button" href="/proveedores">Volver</a>
                    </section>
                    %s
                    """.formatted(formEditar(proveedor.get()))));
        } catch (Exception ex) {
            renderError(exchange, "No se pudo cargar el proveedor.", ex);
        }
    }

    public void actualizar(HttpExchange exchange) throws IOException {
        try {
            RoleGuard.require(AppRole.ADMINISTRADOR, AppRole.JEFE_COMPRAS);
            proveedorService.actualizar(FormParser.parseForm(exchange));
            redirect(exchange, "/proveedores?ok=Proveedor actualizado correctamente.");
        } catch (Exception ex) {
            renderError(exchange, "No se pudo actualizar el proveedor.", ex);
        }
    }

    public void eliminar(HttpExchange exchange) throws IOException {
        try {
            RoleGuard.require(AppRole.ADMINISTRADOR, AppRole.JEFE_COMPRAS);
            proveedorService.eliminar(FormParser.parseForm(exchange));
            redirect(exchange, "/proveedores?ok=Proveedor desactivado correctamente.");
        } catch (Exception ex) {
            renderError(exchange, "No se pudo desactivar el proveedor.", ex);
        }
    }

    private String formCrear() {
        return """
                <form class="form-panel" method="post" action="/proveedores/crear">
                    <div class="form-grid">
                        <label>Tipo de proveedor
                            <select name="tipo_proveedor" required>
                                <option value="persona_natural">Persona natural</option>
                                <option value="persona_juridica">Persona juridica</option>
                            </select>
                        </label>
                        <label>Identificacion / RUC
                            <input name="identificacion" maxlength="20" required>
                        </label>
                        <label>Razon social
                            <input name="razon_social" maxlength="200" required>
                        </label>
                        <label>Email
                            <input name="email" type="email" maxlength="150">
                        </label>
                        <label>Telefono
                            <input name="telefono" maxlength="20">
                        </label>
                        <label>Dias de credito
                            <input name="dias_credito" type="number" min="0" value="30">
                        </label>
                        <label>Direccion
                            <input name="direccion" maxlength="300">
                        </label>
                        <label>Cuenta bancaria
                            <input name="cuenta_bancaria" maxlength="50">
                        </label>
                        <label>Banco
                            <input name="banco" maxlength="100">
                        </label>
                        <label>Calificacion
                            <select name="calificacion">
                                <option value="">Sin calificacion</option>
                                <option value="A">A</option>
                                <option value="B">B</option>
                                <option value="C">C</option>
                            </select>
                        </label>
                        <label>Cedula persona natural
                            <input name="cedula" maxlength="10">
                            <span class="hint">Obligatoria si el tipo es persona natural.</span>
                        </label>
                        <label>Razon social comercial persona juridica
                            <input name="razon_social_comercial" maxlength="200">
                            <span class="hint">Obligatoria si el tipo es persona juridica.</span>
                        </label>
                        <label>Nombre comercial persona juridica
                            <input name="nombre_comercial" maxlength="200">
                        </label>
                    </div>
                    <div class="form-actions">
                        <button class="button primary" type="submit">Guardar proveedor</button>
                        <a class="button" href="/proveedores">Cancelar</a>
                    </div>
                </form>
                """;
    }

    private String formEditar(Proveedor proveedor) {
        return """
                <form class="form-panel" method="post" action="/proveedores/actualizar">
                    <input type="hidden" name="id_proveedor" value="%d">
                    <div class="status">
                        <strong>%s</strong>
                        <p>Tipo: %s. Identificacion: %s. Los datos de subtipo no se modifican desde este procedimiento.</p>
                    </div>
                    <div class="form-grid">
                        <label>Razon social
                            <input name="razon_social" maxlength="200" required value="%s">
                        </label>
                        <label>Email
                            <input name="email" type="email" maxlength="150" value="%s">
                        </label>
                        <label>Telefono
                            <input name="telefono" maxlength="20" value="%s">
                        </label>
                        <label>Dias de credito
                            <input name="dias_credito" type="number" min="0" value="%d">
                        </label>
                        <label>Direccion
                            <input name="direccion" maxlength="300" value="%s">
                        </label>
                        <label>Cuenta bancaria
                            <input name="cuenta_bancaria" maxlength="50" value="%s">
                        </label>
                        <label>Banco
                            <input name="banco" maxlength="100" value="%s">
                        </label>
                        <label>Calificacion
                            <select name="calificacion">
                                %s
                            </select>
                        </label>
                    </div>
                    <div class="form-actions">
                        <button class="button primary" type="submit">Actualizar proveedor</button>
                        <a class="button" href="/proveedores">Cancelar</a>
                    </div>
                </form>
                """.formatted(
                proveedor.idProveedor(),
                escape(proveedor.razonSocial()),
                escape(proveedor.tipoProveedor()),
                escape(proveedor.identificacion()),
                escape(nullToEmpty(proveedor.razonSocial())),
                escape(nullToEmpty(proveedor.email())),
                escape(nullToEmpty(proveedor.telefono())),
                proveedor.diasCredito(),
                escape(nullToEmpty(proveedor.direccion())),
                escape(nullToEmpty(proveedor.cuentaBancaria())),
                escape(nullToEmpty(proveedor.banco())),
                calificacionOptions(proveedor.calificacion())
        );
    }

    private String calificacionOptions(String selected) {
        return option("", "Sin calificacion", selected)
                + option("A", "A", selected)
                + option("B", "B", selected)
                + option("C", "C", selected);
    }

    private String option(String value, String label, String selected) {
        String selectedAttr = value.equals(nullToEmpty(selected)) ? " selected" : "";
        return "<option value=\"" + escape(value) + "\"" + selectedAttr + ">" + escape(label) + "</option>";
    }

    private String messageBlock(Map<String, String> query) {
        if (query.containsKey("ok")) {
            return "<section class=\"section\"><div class=\"status ok\">" + escape(query.get("ok")) + "</div></section>";
        }
        if (query.containsKey("error")) {
            return "<section class=\"section\"><div class=\"status error\">" + escape(query.get("error")) + "</div></section>";
        }
        return "";
    }

    private void renderError(HttpExchange exchange, String title, Exception ex) throws IOException {
        String detail = ErrorMessageMapper.toUserMessage(ex);
        HtmlResponse.ok(exchange, PageRenderer.layout("""
                <section class="section">
                    <div class="status error">
                        <strong>%s</strong>
                        <p>%s</p>
                        <p><a class="button" href="/proveedores">Volver a proveedores</a></p>
                    </div>
                </section>
                """.formatted(escape(title), escape(detail))));
    }

    private void redirect(HttpExchange exchange, String location) throws IOException {
        String[] parts = location.split("\\?", 2);
        String safeLocation = parts.length == 2 ? parts[0] + "?" + encodeQuery(parts[1]) : location;
        exchange.getResponseHeaders().set("Location", safeLocation);
        exchange.sendResponseHeaders(303, -1);
        exchange.close();
    }

    private String encodeQuery(String query) {
        String[] parts = query.split("=", 2);
        if (parts.length != 2) {
            return query;
        }
        return parts[0] + "=" + URLEncoder.encode(parts[1], StandardCharsets.UTF_8);
    }

    private String escape(String value) {
        return HtmlResponse.escape(value);
    }

    private String nullToEmpty(String value) {
        return value == null ? "" : value;
    }

    private String emptyToDash(String value) {
        return value == null || value.isBlank() ? "-" : value;
    }
}

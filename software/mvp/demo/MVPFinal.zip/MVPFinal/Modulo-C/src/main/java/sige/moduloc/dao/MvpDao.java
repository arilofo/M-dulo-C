package sige.moduloc.dao;

import sige.moduloc.config.Database;
import sige.moduloc.integration.ModuleIntegrationException;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.Statement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Types;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class MvpDao {
    private final Database database;

    public MvpDao(Database database) {
        this.database = database;
    }

    public List<Map<String, Object>> query(String sql, Object... params) throws SQLException {
        try (Connection connection = database.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            bind(statement, params);
            try (ResultSet resultSet = statement.executeQuery()) {
                return rows(resultSet);
            }
        }
    }

    public List<Map<String, Object>> callQuery(String callSql, Object... params) throws SQLException {
        try (Connection connection = database.getConnection();
             CallableStatement statement = connection.prepareCall(callSql)) {
            bind(statement, params);
            boolean hasResult = statement.execute();
            if (!hasResult) {
                return List.of();
            }
            try (ResultSet resultSet = statement.getResultSet()) {
                return rows(resultSet);
            }
        }
    }

    public void call(String callSql, Object... params) throws SQLException {
        try (Connection connection = database.getConnection();
             CallableStatement statement = connection.prepareCall(callSql)) {
            bind(statement, params);
            statement.execute();
        }
    }

    public int registrarRecepcionConInventario(int idOc, String tipoRecepcion, String itemsJson,
                                               String observaciones, String usuarioOperacion,
                                               int bodegaId, String usuarioIntegracion) throws SQLException {
        try (Connection connection = database.getConnection()) {
            boolean previousAutoCommit = connection.getAutoCommit();
            connection.setAutoCommit(false);
            try {
                int idRecepcion = crearRecepcion(connection, idOc, tipoRecepcion, itemsJson, observaciones, usuarioOperacion);
                actualizarInventarioModuloB(connection, idRecepcion, bodegaId, usuarioIntegracion);
                connection.commit();
                return idRecepcion;
            } catch (Exception ex) {
                connection.rollback();
                if (ex instanceof SQLException sqlException) {
                    throw sqlException;
                }
                throw new SQLException(ex.getMessage(), ex);
            } finally {
                connection.setAutoCommit(previousAutoCommit);
            }
        }
    }

    public void procesarInventarioRecepcion(int idRecepcion, int bodegaId, String usuarioIntegracion) throws SQLException {
        try (Connection connection = database.getConnection()) {
            boolean previousAutoCommit = connection.getAutoCommit();
            connection.setAutoCommit(false);
            try {
                actualizarInventarioModuloB(connection, idRecepcion, bodegaId, usuarioIntegracion);
                connection.commit();
            } catch (Exception ex) {
                connection.rollback();
                if (ex instanceof SQLException sqlException) {
                    throw sqlException;
                }
                throw new SQLException(ex.getMessage(), ex);
            } finally {
                connection.setAutoCommit(previousAutoCommit);
            }
        }
    }

    public List<Map<String, Object>> productosModuloB() throws SQLException {
        try (Connection connection = database.getConnection()) {
            ensureExternalTable(connection, "modulo_b", "productos");
            try (PreparedStatement statement = connection.prepareStatement("""
                    SELECT producto_id, codigo, descripcion, costo, stock_actual
                    FROM modulo_b.productos
                    WHERE activo = 1
                    ORDER BY descripcion
                    LIMIT 100
                    """)) {
                try (ResultSet resultSet = statement.executeQuery()) {
                    return rows(resultSet);
                }
            }
        } catch (SQLException ex) {
            throw moduloBException(ex, "IF-04", null);
        }
    }

    public Map<String, Object> productoModuloB(int productoId) throws SQLException {
        try (Connection connection = database.getConnection()) {
            ensureExternalTable(connection, "modulo_b", "productos");
            return singleRow(connection, """
                    SELECT producto_id, codigo, descripcion, costo
                    FROM modulo_b.productos
                    WHERE producto_id = ? AND activo = 1
                    """, productoId);
        } catch (SQLException ex) {
            throw moduloBException(ex, "IF-04", null);
        }
    }

    public List<Map<String, Object>> bodegasModuloB() throws SQLException {
        try (Connection connection = database.getConnection()) {
            ensureExternalTable(connection, "modulo_b", "bodegas");
            try (PreparedStatement statement = connection.prepareStatement("""
                    SELECT bodega_id, codigo, nombre
                    FROM modulo_b.bodegas
                    WHERE activo = 1
                    ORDER BY nombre
                    """)) {
                try (ResultSet resultSet = statement.executeQuery()) {
                    return rows(resultSet);
                }
            }
        } catch (SQLException ex) {
            throw moduloBException(ex, "IF-03", null);
        }
    }

    public List<Map<String, Object>> tarifasIvaModuloD() throws SQLException {
        try (Connection connection = database.getConnection()) {
            ensureExternalTable(connection, "modulo_d", "tarifas_iva");
            try (PreparedStatement statement = connection.prepareStatement("""
                    SELECT id_tarifa, codigo, porcentaje, descripcion
                    FROM modulo_d.tarifas_iva
                    WHERE activo = 1
                    ORDER BY porcentaje, codigo
                    """)) {
                try (ResultSet resultSet = statement.executeQuery()) {
                    return rows(resultSet);
                }
            }
        } catch (SQLException ex) {
            throw moduloDException(ex, "IF-06", null);
        }
    }

    public Map<String, Object> tarifaIvaModuloD(int idTarifa) throws SQLException {
        try (Connection connection = database.getConnection()) {
            ensureExternalTable(connection, "modulo_d", "tarifas_iva");
            return singleRow(connection, """
                    SELECT id_tarifa, codigo, porcentaje, descripcion
                    FROM modulo_d.tarifas_iva
                    WHERE id_tarifa = ? AND activo = 1
                    """, idTarifa);
        } catch (SQLException ex) {
            throw moduloDException(ex, "IF-06", null);
        }
    }

    public List<Map<String, Object>> retencionesRentaConfig() throws SQLException {
        try (Connection connection = database.getConnection()) {
            ensureExternalTable(connection, "modulo_d", "retenciones_renta_config");
            try (PreparedStatement statement = connection.prepareStatement("""
                    SELECT id_ret_renta, codigo_sri, concepto, descripcion, porcentaje_retencion
                    FROM modulo_d.retenciones_renta_config
                    WHERE activo = 1
                    ORDER BY codigo_sri
                    """)) {
                try (ResultSet resultSet = statement.executeQuery()) {
                    return rows(resultSet);
                }
            }
        } catch (SQLException ex) {
            throw moduloDException(ex, "IF-06", null);
        }
    }

    public List<Map<String, Object>> retencionesIvaConfig() throws SQLException {
        try (Connection connection = database.getConnection()) {
            ensureExternalTable(connection, "modulo_d", "retenciones_iva_config");
            try (PreparedStatement statement = connection.prepareStatement("""
                    SELECT id_ret_iva, codigo_sri, descripcion, porcentaje_retencion
                    FROM modulo_d.retenciones_iva_config
                    WHERE activo = 1
                    ORDER BY codigo_sri
                    """)) {
                try (ResultSet resultSet = statement.executeQuery()) {
                    return rows(resultSet);
                }
            }
        } catch (SQLException ex) {
            throw moduloDException(ex, "IF-06", null);
        }
    }

    public void registrarRetencionReal(int idFactura, int idRetRenta, int idRetIva,
                                       String numeroComprobante, String numeroAutorizacion) throws SQLException {
        try (Connection connection = database.getConnection()) {
            boolean previousAutoCommit = connection.getAutoCommit();
            connection.setAutoCommit(false);
            try {
                Map<String, Object> factura = singleRow(connection, """
                        SELECT f.id_factura_prov, f.id_proveedor, f.base_imponible, f.monto_iva,
                               f.total, f.codigo_sustento, f.ref_mod_d_tarifa_id, p.identificacion
                        FROM FacturaProveedor f
                        JOIN Proveedor p ON p.id_proveedor = f.id_proveedor
                        WHERE f.id_factura_prov = ? AND f.activo = 1
                        """, idFactura);
                if (factura.isEmpty()) {
                    throw new SQLException("La factura no existe o esta inactiva.");
                }

                String xml;
                try {
                    ensureExternalTable(connection, "modulo_d", "comprobantes_retencion");
                    ensureExternalTable(connection, "modulo_d", "log_xml_comprobantes");
                    ensureExternalTable(connection, "modulo_d", "retenciones_renta_config");
                    ensureExternalTable(connection, "modulo_d", "retenciones_iva_config");

                    BigDecimal base = decimal(factura.get("base_imponible"));
                    BigDecimal iva = decimal(factura.get("monto_iva"));
                    BigDecimal total = decimal(factura.get("total"));
                    BigDecimal porcentajeRenta = porcentajeRetencion(connection, "retenciones_renta_config", "id_ret_renta", idRetRenta);
                    BigDecimal porcentajeIva = porcentajeRetencion(connection, "retenciones_iva_config", "id_ret_iva", idRetIva);
                    BigDecimal valorRenta = base.multiply(porcentajeRenta).divide(new BigDecimal("100"), 2, RoundingMode.HALF_UP);
                    BigDecimal valorIva = iva.multiply(porcentajeIva).divide(new BigDecimal("100"), 2, RoundingMode.HALF_UP);
                    BigDecimal porcentajeTarifaIva = porcentajeTarifaIva(connection, factura.get("ref_mod_d_tarifa_id"));
                    xml = xmlRetencion(numeroComprobante, numeroAutorizacion, idFactura, factura, valorRenta, valorIva);

                    int idComprobante;
                    try (PreparedStatement statement = connection.prepareStatement("""
                            INSERT INTO modulo_d.comprobantes_retencion (
                                numero, fecha, ref_mod_c_proveedor_id, ref_mod_c_factura_id,
                                base_imponible_renta, id_ret_renta, valor_retencion_renta,
                                base_imponible_iva, id_ret_iva, valor_retencion_iva,
                                subtotal_factura, total_factura, porcentaje_iva_aplicado,
                                codigo_sustento, xml_generado, numero_autorizacion_simulado, estado_sri
                            ) VALUES (?, CURDATE(), ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'autorizado')
                            """, Statement.RETURN_GENERATED_KEYS)) {
                        bind(statement,
                                numeroComprobante,
                                factura.get("id_proveedor"),
                                idFactura,
                                base,
                                idRetRenta,
                                valorRenta,
                                iva,
                                idRetIva,
                                valorIva,
                                base,
                                total,
                                porcentajeTarifaIva,
                                factura.get("codigo_sustento"),
                                xml,
                                numeroAutorizacion);
                        statement.executeUpdate();
                        try (ResultSet keys = statement.getGeneratedKeys()) {
                            if (!keys.next()) {
                                throw new SQLException("No se pudo obtener el comprobante de retencion creado en modulo_d.");
                            }
                            idComprobante = keys.getInt(1);
                        }
                    }

                    try (PreparedStatement statement = connection.prepareStatement("""
                            INSERT INTO modulo_d.log_xml_comprobantes
                            (tipo, referencia_id, xml_content, estado_generacion)
                            VALUES ('RETENCION', ?, ?, 'exitoso')
                            """)) {
                        bind(statement, idComprobante, xml);
                        statement.executeUpdate();
                    }
                } catch (SQLException ex) {
                    throw moduloDException(ex, "IF-05", idFactura);
                }

                try (CallableStatement statement = connection.prepareCall("{CALL sp_actualizar_retencion_desde_modd(?, ?, ?)}")) {
                    bind(statement, idFactura, xml, numeroAutorizacion);
                    statement.execute();
                }

                connection.commit();
            } catch (Exception ex) {
                connection.rollback();
                if (ex instanceof SQLException sqlException) {
                    throw sqlException;
                }
                throw new SQLException(ex.getMessage(), ex);
            } finally {
                connection.setAutoCommit(previousAutoCommit);
            }
        }
    }

    public List<Map<String, Object>> explainPagosPorVencer(int dias) throws SQLException {
        return query("""
                EXPLAIN
                SELECT c.id_cxp, p.razon_social, f.numero_factura_proveedor,
                       c.saldo_pendiente, c.fecha_vencimiento, c.estado,
                       DATEDIFF(c.fecha_vencimiento, CURDATE()) AS dias_para_vencer
                FROM CuentaPorPagar c
                JOIN Proveedor p ON p.id_proveedor = c.id_proveedor
                JOIN FacturaProveedor f ON f.id_factura_prov = c.id_factura_prov
                WHERE c.activo = 1
                  AND c.estado IN ('pendiente', 'pagada_parcial')
                  AND c.saldo_pendiente > 0
                  AND c.fecha_vencimiento BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL ? DAY)
                ORDER BY c.fecha_vencimiento, p.razon_social
                """, dias);
    }

    public List<Map<String, Object>> costoProductoModuloA(int productoId) throws SQLException {
        return callQuery("{CALL sp_consultar_precio_costo_producto(?)}", productoId);
    }

    public List<Map<String, Object>> ultimosCostosAdquisicionModuloA(int productoId, int limite) throws SQLException {
        return callQuery("{CALL sp_consultar_ultimo_costo_adquisicion(?, ?)}", productoId, limite);
    }

    private int crearRecepcion(Connection connection, int idOc, String tipoRecepcion, String itemsJson,
                               String observaciones, String usuarioOperacion) throws SQLException {
        try (CallableStatement statement = connection.prepareCall("{CALL sp_registrar_recepcion(?, ?, ?, ?, ?)}")) {
            bind(statement, idOc, tipoRecepcion, itemsJson, observaciones, usuarioOperacion);
            boolean hasResult = statement.execute();
            if (hasResult) {
                try (ResultSet resultSet = statement.getResultSet()) {
                    if (resultSet.next()) {
                        return resultSet.getInt("id_recepcion_creada");
                    }
                }
            }
        }
        throw new SQLException("sp_registrar_recepcion no devolvio id_recepcion_creada.");
    }

    private void actualizarInventarioModuloB(Connection connection, int idRecepcion, int bodegaId,
                                             String usuarioIntegracion) throws SQLException {
        List<Map<String, Object>> pendientes = query(connection, """
                SELECT id_recepcion, id_detalle_rec, ref_mod_b_id_producto, cantidad_recibida
                FROM vw_recepciones_pendientes_notificar
                WHERE id_recepcion = ?
                ORDER BY id_detalle_rec
                """, idRecepcion);
        if (pendientes.isEmpty()) {
            throw new SQLException("La recepcion no tiene detalles pendientes de notificar a inventario.");
        }

        try {
            ensureExternalTable(connection, "modulo_b", "productos");
            ensureExternalTable(connection, "modulo_b", "bodegas");
            ensureExternalTable(connection, "modulo_b", "movimientos_inventario");
            ensureExternalTable(connection, "modulo_b", "kardex");
            ensureActiveBodega(connection, bodegaId);

            for (Map<String, Object> row : pendientes) {
                int productoId = ((Number) row.get("ref_mod_b_id_producto")).intValue();
                BigDecimal cantidad = decimal(row.get("cantidad_recibida"));
                Map<String, Object> producto = singleRow(connection, """
                        SELECT producto_id, costo, stock_actual
                        FROM modulo_b.productos
                        WHERE producto_id = ? AND activo = 1
                        """, productoId);
                if (producto.isEmpty()) {
                    throw new SQLException("No existe producto activo en modulo_b.productos para producto_id=" + productoId + ".");
                }

                try (PreparedStatement statement = connection.prepareStatement("""
                        INSERT INTO modulo_b.movimientos_inventario
                        (producto_id, bodega_id, tipo, cantidad, referencia, usuario_id, observaciones)
                        VALUES (?, ?, 'ENTRADA', ?, ?, ?, ?)
                        """)) {
                    bind(statement, productoId, bodegaId, cantidad, "MOD-C-REC-" + idRecepcion, null,
                            "Recepcion registrada en Modulo C por " + usuarioIntegracion);
                    statement.executeUpdate();
                }

                try (PreparedStatement statement = connection.prepareStatement("""
                        UPDATE modulo_b.productos
                        SET stock_actual = stock_actual + ?
                        WHERE producto_id = ? AND activo = 1
                        """)) {
                    bind(statement, cantidad, productoId);
                    statement.executeUpdate();
                }

                Map<String, Object> actualizado = singleRow(connection, """
                        SELECT costo, stock_actual
                        FROM modulo_b.productos
                        WHERE producto_id = ? AND activo = 1
                        """, productoId);
                BigDecimal costo = decimal(actualizado.get("costo"));
                BigDecimal stock = decimal(actualizado.get("stock_actual"));
                try (PreparedStatement statement = connection.prepareStatement("""
                        INSERT INTO modulo_b.kardex
                        (producto_id, bodega_id, tipo_movimiento, cantidad_entrada, cantidad_salida,
                         stock_resultante, costo_unitario, costo_total, referencia)
                        VALUES (?, ?, 'ENTRADA', ?, 0, ?, ?, ?, ?)
                        """)) {
                    bind(statement, productoId, bodegaId, cantidad, stock, costo, cantidad.multiply(costo),
                            "MOD-C-REC-" + idRecepcion);
                    statement.executeUpdate();
                }
            }
        } catch (SQLException ex) {
            throw moduloBException(ex, "IF-03", idRecepcion);
        }

        try (CallableStatement statement = connection.prepareCall("{CALL sp_marcar_recepcion_notificada(?, ?)}")) {
            bind(statement, idRecepcion, usuarioIntegracion);
            statement.execute();
        }
        try (PreparedStatement statement = connection.prepareStatement("""
                UPDATE LogSincronizacion
                SET estado = 'exitoso', mensaje_error = NULL
                WHERE modulo_destino = 'MOD-B' AND interfaz = 'IF-03'
                  AND id_referencia = ?
                """)) {
            bind(statement, idRecepcion);
            statement.executeUpdate();
        }
    }

    private void ensureExternalTable(Connection connection, String schema, String table) throws SQLException {
        try (PreparedStatement statement = connection.prepareStatement("""
                SELECT COUNT(*) AS total
                FROM information_schema.tables
                WHERE table_schema = ? AND table_name = ?
                """)) {
            bind(statement, schema, table);
            try (ResultSet resultSet = statement.executeQuery()) {
                resultSet.next();
                if (resultSet.getInt("total") == 0) {
                    throw new SQLException("No existe " + schema + "." + table + ". Cargue DataBase/ScriptsMODS_Externos.sql y verifique el esquema externo.");
                }
            }
        }
    }

    private ModuleIntegrationException moduloBException(SQLException cause, String interfaz, Integer idReferencia) {
        return ModuleIntegrationException.moduloB(cause, registrarErrorSincronizacion("MOD-B", interfaz, idReferencia, cause));
    }

    private ModuleIntegrationException moduloDException(SQLException cause, String interfaz, Integer idReferencia) {
        return ModuleIntegrationException.moduloD(cause, registrarErrorSincronizacion("MOD-D", interfaz, idReferencia, cause));
    }

    private String registrarErrorSincronizacion(String moduloDestino, String interfaz, Integer idReferencia, SQLException cause) {
        try (Connection connection = database.getConnection();
             CallableStatement statement = connection.prepareCall("{CALL sp_registrar_error_sincronizacion(?, ?, ?, ?)}")) {
            bind(statement, moduloDestino, interfaz, idReferencia, shortMessage(cause));
            statement.execute();
            return null;
        } catch (SQLException logException) {
            return shortMessage(logException);
        }
    }

    private String shortMessage(Throwable throwable) {
        String message = throwable == null ? null : throwable.getMessage();
        if (message == null || message.isBlank()) {
            return "Error sin detalle devuelto por MySQL.";
        }
        String oneLine = message.replaceAll("\\s+", " ").trim();
        int maxLength = 500;
        return oneLine.length() <= maxLength ? oneLine : oneLine.substring(0, maxLength) + "...";
    }

    private void ensureActiveBodega(Connection connection, int bodegaId) throws SQLException {
        Map<String, Object> bodega = singleRow(connection, """
                SELECT bodega_id
                FROM modulo_b.bodegas
                WHERE bodega_id = ? AND activo = 1
                """, bodegaId);
        if (bodega.isEmpty()) {
            throw new SQLException("No existe bodega activa en modulo_b.bodegas para bodega_id=" + bodegaId + ".");
        }
    }

    private BigDecimal porcentajeRetencion(Connection connection, String table, String idColumn, int id) throws SQLException {
        Map<String, Object> row = singleRow(connection, """
                SELECT porcentaje_retencion
                FROM modulo_d.%s
                WHERE %s = ? AND activo = 1
                """.formatted(table, idColumn), id);
        if (row.isEmpty()) {
            throw new SQLException("No existe configuracion activa en modulo_d." + table + " para id=" + id + ".");
        }
        return decimal(row.get("porcentaje_retencion"));
    }

    private BigDecimal porcentajeTarifaIva(Connection connection, Object tarifaId) throws SQLException {
        if (tarifaId == null) {
            return null;
        }
        ensureExternalTable(connection, "modulo_d", "tarifas_iva");
        Map<String, Object> row = singleRow(connection, """
                SELECT porcentaje
                FROM modulo_d.tarifas_iva
                WHERE id_tarifa = ? AND activo = 1
                """, tarifaId);
        if (row.isEmpty()) {
            throw new SQLException("No existe tarifa activa en modulo_d.tarifas_iva para id_tarifa=" + tarifaId + ".");
        }
        return decimal(row.get("porcentaje"));
    }

    private Map<String, Object> singleRow(Connection connection, String sql, Object... params) throws SQLException {
        List<Map<String, Object>> rows = query(connection, sql, params);
        return rows.isEmpty() ? Map.of() : rows.get(0);
    }

    private List<Map<String, Object>> query(Connection connection, String sql, Object... params) throws SQLException {
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            bind(statement, params);
            try (ResultSet resultSet = statement.executeQuery()) {
                return rows(resultSet);
            }
        }
    }

    private BigDecimal decimal(Object value) {
        if (value instanceof BigDecimal decimalValue) {
            return decimalValue;
        }
        if (value instanceof Number number) {
            return BigDecimal.valueOf(number.doubleValue());
        }
        return new BigDecimal(value.toString());
    }

    private String xmlRetencion(String numeroComprobante, String numeroAutorizacion, int idFactura,
                                Map<String, Object> factura, BigDecimal valorRenta, BigDecimal valorIva) {
        return "<retencion numero=\"" + xml(numeroComprobante) + "\" autorizacion=\"" + xml(numeroAutorizacion) + "\">"
                + "<factura id=\"" + idFactura + "\" proveedor=\"" + xml(String.valueOf(factura.get("identificacion"))) + "\"/>"
                + "<valores renta=\"" + valorRenta + "\" iva=\"" + valorIva + "\"/>"
                + "</retencion>";
    }

    private String xml(String value) {
        return value == null ? "" : value.replace("&", "&amp;").replace("\"", "&quot;")
                .replace("<", "&lt;").replace(">", "&gt;");
    }

    private void bind(PreparedStatement statement, Object... params) throws SQLException {
        for (int i = 0; i < params.length; i++) {
            Object value = params[i];
            int index = i + 1;
            if (value == null) {
                statement.setNull(index, Types.NULL);
            } else if (value instanceof Integer intValue) {
                statement.setInt(index, intValue);
            } else if (value instanceof Long longValue) {
                statement.setLong(index, longValue);
            } else if (value instanceof BigDecimal decimalValue) {
                statement.setBigDecimal(index, decimalValue);
            } else if (value instanceof LocalDate dateValue) {
                statement.setDate(index, Date.valueOf(dateValue));
            } else if (value instanceof Boolean booleanValue) {
                statement.setBoolean(index, booleanValue);
            } else {
                statement.setString(index, value.toString());
            }
        }
    }

    private List<Map<String, Object>> rows(ResultSet resultSet) throws SQLException {
        ResultSetMetaData metaData = resultSet.getMetaData();
        int count = metaData.getColumnCount();
        List<Map<String, Object>> rows = new ArrayList<>();
        while (resultSet.next()) {
            Map<String, Object> row = new LinkedHashMap<>();
            for (int i = 1; i <= count; i++) {
                row.put(metaData.getColumnLabel(i), resultSet.getObject(i));
            }
            rows.add(row);
        }
        return rows;
    }
}

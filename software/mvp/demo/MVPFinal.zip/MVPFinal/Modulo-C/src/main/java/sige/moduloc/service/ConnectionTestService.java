package sige.moduloc.service;

import sige.moduloc.dao.ConnectionTestDao;

public class ConnectionTestService {
    private final ConnectionTestDao connectionTestDao;

    public ConnectionTestService(ConnectionTestDao connectionTestDao) {
        this.connectionTestDao = connectionTestDao;
    }

    public ConnectionTestResult testConnection() {
        try {
            String databaseName = connectionTestDao.readCurrentDatabase();
            return new ConnectionTestResult(true, "Conexion abierta correctamente. Base actual: " + databaseName + ".");
        } catch (Exception ex) {
            return new ConnectionTestResult(false, ex.getMessage());
        }
    }
}

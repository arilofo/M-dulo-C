package sige.moduloc.controller;

import com.sun.net.httpserver.HttpExchange;
import sige.moduloc.config.AppConfig;
import sige.moduloc.http.HtmlResponse;
import sige.moduloc.http.PageRenderer;
import sige.moduloc.service.ConnectionTestResult;
import sige.moduloc.service.ConnectionTestService;

import java.io.IOException;

public class HomeController {
    private final AppConfig config;
    private final ConnectionTestService connectionTestService;

    public HomeController(AppConfig config, ConnectionTestService connectionTestService) {
        this.config = config;
        this.connectionTestService = connectionTestService;
    }

    public void index(HttpExchange exchange) throws IOException {
        HtmlResponse.ok(exchange, PageRenderer.layout("""
                <section class="section">
                    <div class="status">
                        <strong>Prototipo inicial activo.</strong>
                        <p>Esta base usa Java local, HttpServer embebido, JDBC, MySQL y HTML simple.</p>
                        <p>
                            <a class="button" href="/proveedores">Gestionar proveedores</a>
                            <a class="button" href="/db-test">Probar conexion a MySQL</a>
                        </p>
                    </div>
                </section>
                <section class="section">
                    <div class="grid">
                        <article class="module"><h2><a href="/proveedores">Proveedores</a></h2><p>Alta, edicion y baja logica mediante procedimientos almacenados.</p></article>
                        <article class="module"><h2><a href="/ordenes">Ordenes de compra</a></h2><p>Creacion con items y consulta de pendientes.</p></article>
                        <article class="module"><h2><a href="/recepciones">Recepciones</a></h2><p>Recepcion parcial o completa e IF-03.</p></article>
                        <article class="module"><h2><a href="/facturas">Facturas de proveedor</a></h2><p>Ingreso y retencion real con Modulo D.</p></article>
                        <article class="module"><h2><a href="/cuentas">Cuentas por pagar</a></h2><p>Consulta, vencimientos y programacion.</p></article>
                        <article class="module"><h2><a href="/pagos">Pagos</a></h2><p>Registro de pagos parciales o totales.</p></article>
                        <article class="module"><h2><a href="/reportes">Reportes</a></h2><p>Vencimientos, obligaciones y conciliacion.</p></article>
                        <article class="module"><h2><a href="/integraciones">Integraciones</a></h2><p>IF-01 costos, IF-03 inventario e impuestos reales.</p></article>
                        <article class="module"><h2><a href="/demo">Demo</a></h2><p>Guia del flujo completo de sustentacion.</p></article>
                    </div>
                </section>
                """));
    }

    public void databaseTest(HttpExchange exchange) throws IOException {
        ConnectionTestResult result = connectionTestService.testConnection();
        String statusClass = result.ok() ? "ok" : "error";
        String title = result.ok() ? "Conexion exitosa" : "No se pudo conectar";
        String message = HtmlResponse.escape(result.message());

        HtmlResponse.ok(exchange, PageRenderer.layout("""
                <section class="section">
                    <div class="status %s">
                        <strong>%s</strong>
                        <p>%s</p>
                        <p><code>%s</code></p>
                        <p><a class="button" href="/">Volver al inicio</a></p>
                    </div>
                </section>
                """.formatted(statusClass, title, message, HtmlResponse.escape(config.dbUrl()))));
    }
}

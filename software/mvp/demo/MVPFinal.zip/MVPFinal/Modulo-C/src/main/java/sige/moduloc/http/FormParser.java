package sige.moduloc.http;

import com.sun.net.httpserver.HttpExchange;

import java.io.IOException;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

public final class FormParser {
    private FormParser() {
    }

    public static Map<String, String> parseForm(HttpExchange exchange) throws IOException {
        String body = new String(exchange.getRequestBody().readAllBytes(), StandardCharsets.UTF_8);
        return parseUrlEncoded(body);
    }

    public static Map<String, String> parseQuery(HttpExchange exchange) {
        String query = exchange.getRequestURI().getRawQuery();
        return parseUrlEncoded(query == null ? "" : query);
    }

    private static Map<String, String> parseUrlEncoded(String value) {
        Map<String, String> params = new HashMap<>();
        if (value == null || value.isBlank()) {
            return params;
        }

        String[] pairs = value.split("&");
        for (String pair : pairs) {
            String[] parts = pair.split("=", 2);
            String key = decode(parts[0]);
            String paramValue = parts.length > 1 ? decode(parts[1]) : "";
            params.put(key, paramValue);
        }
        return params;
    }

    private static String decode(String value) {
        return URLDecoder.decode(value, StandardCharsets.UTF_8);
    }
}

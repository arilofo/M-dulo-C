package sige.moduloc.model;

public record ProveedorForm(
        int idProveedor,
        String tipoProveedor,
        String identificacion,
        String razonSocial,
        String email,
        String telefono,
        String direccion,
        Integer diasCredito,
        String cuentaBancaria,
        String banco,
        String calificacion,
        String cedula,
        String razonSocialComercial,
        String nombreComercial,
        String usuario
) {
}

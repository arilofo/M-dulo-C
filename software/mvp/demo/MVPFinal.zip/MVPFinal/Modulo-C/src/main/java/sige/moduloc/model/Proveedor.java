package sige.moduloc.model;

public record Proveedor(
        int idProveedor,
        String tipoProveedor,
        String identificacion,
        String razonSocial,
        String email,
        String telefono,
        String direccion,
        int diasCredito,
        String cuentaBancaria,
        String banco,
        String calificacion,
        String cedula,
        String razonSocialComercial,
        String nombreComercial
) {
}

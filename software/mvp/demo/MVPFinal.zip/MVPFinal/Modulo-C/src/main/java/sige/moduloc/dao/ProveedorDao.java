package sige.moduloc.dao;

import sige.moduloc.config.Database;
import sige.moduloc.model.Proveedor;
import sige.moduloc.model.ProveedorForm;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class ProveedorDao {
    private final Database database;

    public ProveedorDao(Database database) {
        this.database = database;
    }

    public List<Proveedor> listarActivos() throws SQLException {
        String sql = """
                SELECT p.id_proveedor, p.tipo_proveedor, p.identificacion, p.razon_social,
                       p.email, p.telefono, p.direccion, p.dias_credito,
                       p.cuenta_bancaria, p.banco, p.calificacion,
                       pn.cedula,
                       pj.razon_social AS razon_social_comercial,
                       pj.nombre_comercial
                FROM Proveedor p
                LEFT JOIN ProveedorPersonaNatural pn ON pn.id_proveedor = p.id_proveedor
                LEFT JOIN ProveedorPersonaJuridica pj ON pj.id_proveedor = p.id_proveedor
                WHERE p.activo = 1
                ORDER BY p.razon_social
                """;
        try (Connection connection = database.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet resultSet = statement.executeQuery()) {
            List<Proveedor> proveedores = new ArrayList<>();
            while (resultSet.next()) {
                proveedores.add(mapProveedor(resultSet));
            }
            return proveedores;
        }
    }

    public Optional<Proveedor> buscarActivoPorId(int idProveedor) throws SQLException {
        String sql = """
                SELECT p.id_proveedor, p.tipo_proveedor, p.identificacion, p.razon_social,
                       p.email, p.telefono, p.direccion, p.dias_credito,
                       p.cuenta_bancaria, p.banco, p.calificacion,
                       pn.cedula,
                       pj.razon_social AS razon_social_comercial,
                       pj.nombre_comercial
                FROM Proveedor p
                LEFT JOIN ProveedorPersonaNatural pn ON pn.id_proveedor = p.id_proveedor
                LEFT JOIN ProveedorPersonaJuridica pj ON pj.id_proveedor = p.id_proveedor
                WHERE p.id_proveedor = ? AND p.activo = 1
                """;
        try (Connection connection = database.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, idProveedor);
            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    return Optional.of(mapProveedor(resultSet));
                }
                return Optional.empty();
            }
        }
    }

    public void registrar(ProveedorForm form) throws SQLException {
        try (Connection connection = database.getConnection();
             CallableStatement statement = connection.prepareCall("{CALL sp_registrar_proveedor(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)}")) {
            statement.setString(1, form.tipoProveedor());
            statement.setString(2, form.identificacion());
            statement.setString(3, form.razonSocial());
            setNullableString(statement, 4, form.email());
            setNullableString(statement, 5, form.telefono());
            setNullableString(statement, 6, form.direccion());
            setNullableInteger(statement, 7, form.diasCredito());
            setNullableString(statement, 8, form.cuentaBancaria());
            setNullableString(statement, 9, form.banco());
            setNullableString(statement, 10, form.calificacion());
            setNullableString(statement, 11, form.cedula());
            setNullableString(statement, 12, form.razonSocialComercial());
            setNullableString(statement, 13, form.nombreComercial());
            setNullableString(statement, 14, form.usuario());
            statement.execute();
        }
    }

    public void actualizar(ProveedorForm form) throws SQLException {
        try (Connection connection = database.getConnection();
             CallableStatement statement = connection.prepareCall("{CALL sp_actualizar_proveedor(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)}")) {
            statement.setInt(1, form.idProveedor());
            statement.setString(2, form.razonSocial());
            setNullableString(statement, 3, form.email());
            setNullableString(statement, 4, form.telefono());
            setNullableString(statement, 5, form.direccion());
            setNullableInteger(statement, 6, form.diasCredito());
            setNullableString(statement, 7, form.cuentaBancaria());
            setNullableString(statement, 8, form.banco());
            setNullableString(statement, 9, form.calificacion());
            setNullableString(statement, 10, form.usuario());
            statement.execute();
        }
    }

    public void eliminarLogico(int idProveedor, String usuario) throws SQLException {
        try (Connection connection = database.getConnection();
             CallableStatement statement = connection.prepareCall("{CALL sp_eliminar_proveedor_logico(?, ?)}")) {
            statement.setInt(1, idProveedor);
            setNullableString(statement, 2, usuario);
            statement.execute();
        }
    }

    private Proveedor mapProveedor(ResultSet resultSet) throws SQLException {
        return new Proveedor(
                resultSet.getInt("id_proveedor"),
                resultSet.getString("tipo_proveedor"),
                resultSet.getString("identificacion"),
                resultSet.getString("razon_social"),
                resultSet.getString("email"),
                resultSet.getString("telefono"),
                resultSet.getString("direccion"),
                resultSet.getInt("dias_credito"),
                resultSet.getString("cuenta_bancaria"),
                resultSet.getString("banco"),
                resultSet.getString("calificacion"),
                resultSet.getString("cedula"),
                resultSet.getString("razon_social_comercial"),
                resultSet.getString("nombre_comercial")
        );
    }

    private void setNullableString(PreparedStatement statement, int index, String value) throws SQLException {
        if (value == null || value.isBlank()) {
            statement.setNull(index, Types.VARCHAR);
        } else {
            statement.setString(index, value.trim());
        }
    }

    private void setNullableInteger(PreparedStatement statement, int index, Integer value) throws SQLException {
        if (value == null) {
            statement.setNull(index, Types.INTEGER);
        } else {
            statement.setInt(index, value);
        }
    }
}

package sige.moduloc.service;

import sige.moduloc.dao.MvpDao;
import sige.moduloc.security.AppRole;
import sige.moduloc.security.RoleGuard;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MvpService {
    private static final String USUARIO_OPERATIVO = "jefe_compras_demo";
    private static final String USUARIO_TESORERIA = "tesorero_demo";
    private static final String USUARIO_INTEGRACION_B = "integracion_modb";

    private final MvpDao dao;

    public MvpService(MvpDao dao) {
        this.dao = dao;
    }

    public List<Map<String, Object>> proveedoresActivos() throws SQLException {
        return dao.query("""
                SELECT id_proveedor, razon_social, identificacion
                FROM Proveedor
                WHERE activo = 1
                ORDER BY razon_social
                """);
    }

    public List<Map<String, Object>> ordenes() throws SQLException {
        return dao.query("""
                SELECT o.id_oc, o.numero_oc, p.razon_social, o.fecha_emision,
                       o.fecha_entrega_esperada, o.estado, o.total_estimado
                FROM OrdenCompra o
                JOIN Proveedor p ON p.id_proveedor = o.id_proveedor
                WHERE o.activo = 1
                ORDER BY o.fecha_emision DESC, o.id_oc DESC
                """);
    }

    public List<Map<String, Object>> ordenDetalle(int idOc) throws SQLException {
        return dao.query("""
                SELECT id_detalle_oc, ref_mod_b_id_producto, codigo_producto_al_momento,
                       descripcion_al_momento, unidad_medida_al_momento,
                       cantidad_solicitada, precio_unitario_pactado, subtotal
                FROM DetalleOrdenCompra
                WHERE id_oc = ? AND activo = 1
                ORDER BY id_detalle_oc
                """, idOc);
    }

    public List<Map<String, Object>> ordenDetalleParaRecepcion(int idOc) throws SQLException {
        return dao.query("""
                SELECT d.id_detalle_oc,
                       d.ref_mod_b_id_producto,
                       d.descripcion_al_momento,
                       d.cantidad_solicitada,
                       COALESCE(rec.cantidad_recibida_previa, 0) AS cantidad_recibida_previa,
                       d.cantidad_solicitada - COALESCE(rec.cantidad_recibida_previa, 0) AS cantidad_restante
                FROM DetalleOrdenCompra d
                LEFT JOIN (
                    SELECT dr.id_detalle_oc, SUM(dr.cantidad_recibida) AS cantidad_recibida_previa
                    FROM DetalleRecepcion dr
                    JOIN Recepcion r ON r.id_recepcion = dr.id_recepcion
                    WHERE dr.activo = 1 AND r.activo = 1
                    GROUP BY dr.id_detalle_oc
                ) rec ON rec.id_detalle_oc = d.id_detalle_oc
                WHERE d.id_oc = ? AND d.activo = 1
                ORDER BY d.id_detalle_oc
                """, idOc);
    }

    public List<Map<String, Object>> ordenCabecera(int idOc) throws SQLException {
        return dao.query("""
                SELECT o.id_oc, o.numero_oc, p.razon_social, o.fecha_emision,
                       o.fecha_entrega_esperada, o.estado, o.total_estimado, o.observaciones
                FROM OrdenCompra o
                JOIN Proveedor p ON p.id_proveedor = o.id_proveedor
                WHERE o.id_oc = ? AND o.activo = 1
                """, idOc);
    }

    public List<Map<String, Object>> ordenesPendientes() throws SQLException {
        return dao.callQuery("{CALL sp_reporte_ordenes_pendientes_recepcion(?)}", (Object) null);
    }

    public List<Map<String, Object>> ordenesParaRecepcion() throws SQLException {
        return dao.query("""
                SELECT o.id_oc, o.numero_oc, p.razon_social, o.estado
                FROM OrdenCompra o
                JOIN Proveedor p ON p.id_proveedor = o.id_proveedor
                WHERE o.activo = 1 AND o.estado IN ('emitida', 'recibida_parcial')
                ORDER BY o.fecha_emision DESC
                """);
    }

    public List<Map<String, Object>> productosModuloB() throws SQLException {
        return dao.productosModuloB();
    }

    public List<Map<String, Object>> bodegasModuloB() throws SQLException {
        return dao.bodegasModuloB();
    }

    public void crearOrden(Map<String, String> form) throws SQLException {
        RoleGuard.require(AppRole.ADMINISTRADOR, AppRole.JEFE_COMPRAS);
        Integer idProveedor = requiredInt(form, "id_proveedor", "Seleccione un proveedor.");
        Integer idSolicitud = optionalInt(form, "id_solicitud");
        LocalDate fechaEntrega = optionalDate(form, "fecha_entrega");
        String itemsJson = buildOrdenItemsJson(form);
        dao.call("{CALL sp_crear_orden_compra(?, ?, ?, ?, ?, ?)}",
                idProveedor, idSolicitud, itemsJson, fechaEntrega,
                clean(form.get("observaciones")), USUARIO_OPERATIVO);
    }

    public List<Map<String, Object>> recepciones() throws SQLException {
        return dao.query("""
                SELECT r.id_recepcion, o.numero_oc, p.razon_social, r.fecha_recepcion,
                       r.tipo_recepcion, r.notificado_inventario, r.fecha_notificacion_inventario
                FROM Recepcion r
                JOIN OrdenCompra o ON o.id_oc = r.id_oc
                JOIN Proveedor p ON p.id_proveedor = o.id_proveedor
                WHERE r.activo = 1
                ORDER BY r.fecha_recepcion DESC, r.id_recepcion DESC
                """);
    }

    public void registrarRecepcion(Map<String, String> form) throws SQLException {
        RoleGuard.require(AppRole.ADMINISTRADOR, AppRole.JEFE_COMPRAS);
        Integer idOc = requiredInt(form, "id_oc", "Seleccione una orden de compra.");
        Integer bodegaId = requiredInt(form, "bodega_id", "Seleccione una bodega real del Modulo B.");
        String tipo = required(form, "tipo_recepcion", "Seleccione el tipo de recepcion.");
        String itemsJson = buildRecepcionItemsJson(form, ordenDetalleParaRecepcion(idOc));
        dao.registrarRecepcionConInventario(idOc, tipo, itemsJson, clean(form.get("observaciones")),
                USUARIO_OPERATIVO, bodegaId, USUARIO_INTEGRACION_B);
    }

    public List<Map<String, Object>> recepcionesPendientesNotificar() throws SQLException {
        return dao.query("SELECT * FROM vw_recepciones_pendientes_notificar ORDER BY id_recepcion, id_detalle_rec");
    }

    public void marcarRecepcionNotificada(Map<String, String> form) throws SQLException {
        RoleGuard.require(AppRole.ADMINISTRADOR, AppRole.JEFE_COMPRAS);
        Integer idRecepcion = requiredInt(form, "id_recepcion", "Seleccione una recepcion.");
        Integer bodegaId = requiredInt(form, "bodega_id", "Seleccione una bodega real del Modulo B.");
        dao.procesarInventarioRecepcion(idRecepcion, bodegaId, USUARIO_INTEGRACION_B);
    }

    public List<Map<String, Object>> facturas() throws SQLException {
        return dao.query("""
                SELECT f.id_factura_prov, f.numero_serie, f.numero_factura_proveedor,
                       p.razon_social, f.fecha_emision, f.total, f.estado, f.factura_excepcional
                FROM FacturaProveedor f
                JOIN Proveedor p ON p.id_proveedor = f.id_proveedor
                WHERE f.activo = 1
                ORDER BY f.fecha_emision DESC, f.id_factura_prov DESC
                """);
    }

    public List<Map<String, Object>> ordenesFacturables() throws SQLException {
        return dao.query("""
                SELECT o.id_oc, o.numero_oc, p.razon_social, o.estado, o.total_estimado
                FROM OrdenCompra o
                JOIN Proveedor p ON p.id_proveedor = o.id_proveedor
                WHERE o.activo = 1 AND o.estado IN ('recibida_parcial', 'recibida_total')
                ORDER BY o.fecha_emision DESC
                """);
    }

    public List<Map<String, Object>> recepcionesActivas() throws SQLException {
        return dao.query("""
                SELECT r.id_recepcion, o.id_oc, o.numero_oc, p.razon_social, r.fecha_recepcion, r.tipo_recepcion
                FROM Recepcion r
                JOIN OrdenCompra o ON o.id_oc = r.id_oc
                JOIN Proveedor p ON p.id_proveedor = o.id_proveedor
                WHERE r.activo = 1
                ORDER BY r.fecha_recepcion DESC
                """);
    }

    public Map<String, Object> referenciaFactura(Integer idOc, Integer idRecepcion) throws SQLException {
        if (idRecepcion != null) {
            List<Map<String, Object>> rows = dao.query("""
                    SELECT r.id_recepcion, r.id_oc, o.numero_oc, o.id_proveedor, p.razon_social,
                           o.total_estimado, o.estado,
                           COALESCE(SUM(dr.cantidad_recibida * d.precio_unitario_pactado), 0) AS subtotal_recepcion,
                           COALESCE((
                               SELECT SUM(fp.base_imponible)
                               FROM FacturaProveedor fp
                               WHERE fp.id_oc = o.id_oc AND fp.activo = 1 AND fp.estado <> 'anulada'
                           ), 0) AS base_facturada_orden,
                           COALESCE((
                               SELECT SUM(fp.base_imponible)
                               FROM FacturaProveedor fp
                               WHERE fp.id_recepcion = r.id_recepcion AND fp.activo = 1 AND fp.estado <> 'anulada'
                           ), 0) AS base_facturada_recepcion
                    FROM Recepcion r
                    JOIN OrdenCompra o ON o.id_oc = r.id_oc
                    JOIN Proveedor p ON p.id_proveedor = o.id_proveedor
                    JOIN DetalleRecepcion dr ON dr.id_recepcion = r.id_recepcion
                    JOIN DetalleOrdenCompra d ON d.id_detalle_oc = dr.id_detalle_oc
                    WHERE r.id_recepcion = ? AND r.activo = 1 AND dr.activo = 1
                      AND d.activo = 1 AND o.activo = 1
                    GROUP BY r.id_recepcion, r.id_oc, o.numero_oc, o.id_proveedor,
                             p.razon_social, o.total_estimado, o.estado
                    """, idRecepcion);
            Map<String, Object> ref = rows.isEmpty() ? Map.of() : new HashMap<>(rows.get(0));
            if (ref.isEmpty()) {
                return ref;
            }
            BigDecimal sugerida = money(ref.get("subtotal_recepcion"));
            BigDecimal facturada = money(ref.get("base_facturada_recepcion"));
            ref.put("base_sugerida", sugerida);
            ref.put("base_facturada_referencia", facturada);
            ref.put("monto_pendiente_base", maxZero(sugerida.subtract(facturada)));
            return ref;
        }
        if (idOc != null) {
            List<Map<String, Object>> rows = dao.query("""
                    SELECT o.id_oc, o.numero_oc, o.id_proveedor, p.razon_social,
                           o.total_estimado, o.estado,
                           COALESCE((
                               SELECT SUM(fp.base_imponible)
                               FROM FacturaProveedor fp
                               WHERE fp.id_oc = o.id_oc AND fp.activo = 1 AND fp.estado <> 'anulada'
                           ), 0) AS base_facturada_orden
                    FROM OrdenCompra o
                    JOIN Proveedor p ON p.id_proveedor = o.id_proveedor
                    WHERE o.id_oc = ? AND o.activo = 1
                    """, idOc);
            Map<String, Object> ref = rows.isEmpty() ? Map.of() : new HashMap<>(rows.get(0));
            if (ref.isEmpty()) {
                return ref;
            }
            BigDecimal sugerida = money(ref.get("total_estimado"));
            BigDecimal facturada = money(ref.get("base_facturada_orden"));
            ref.put("subtotal_recepcion", null);
            ref.put("base_sugerida", sugerida);
            ref.put("base_facturada_referencia", facturada);
            ref.put("monto_pendiente_base", maxZero(sugerida.subtract(facturada)));
            return ref;
        }
        return Map.of();
    }

    public List<Map<String, Object>> detalleRecepcionFactura(int idRecepcion) throws SQLException {
        return dao.query("""
                SELECT d.ref_mod_b_id_producto, d.codigo_producto_al_momento,
                       d.descripcion_al_momento, dr.cantidad_recibida,
                       d.precio_unitario_pactado,
                       dr.cantidad_recibida * d.precio_unitario_pactado AS subtotal_recepcion
                FROM DetalleRecepcion dr
                JOIN DetalleOrdenCompra d ON d.id_detalle_oc = dr.id_detalle_oc
                JOIN Recepcion r ON r.id_recepcion = dr.id_recepcion
                WHERE dr.id_recepcion = ? AND dr.activo = 1 AND d.activo = 1 AND r.activo = 1
                ORDER BY dr.id_detalle_rec
                """, idRecepcion);
    }

    public void crearFactura(Map<String, String> form) throws SQLException {
        RoleGuard.require(AppRole.ADMINISTRADOR, AppRole.JEFE_COMPRAS);
        boolean excepcional = "1".equals(form.get("factura_excepcional"));
        if (excepcional) {
            RoleGuard.require(AppRole.ADMINISTRADOR);
        }
        Integer idProveedor = requiredInt(form, "id_proveedor", "Seleccione un proveedor.");
        Integer idOc = excepcional ? null : requiredInt(form, "id_oc", "Seleccione una orden para factura regular.");
        Integer idRecepcion = excepcional ? null : requiredInt(form, "id_recepcion", "Seleccione una recepcion para factura regular.");
        Integer idTarifaIva = requiredInt(form, "ref_mod_d_tarifa_id", "Seleccione una tarifa IVA real del Modulo D.");
        Map<String, Object> tarifaIva = dao.tarifaIvaModuloD(idTarifaIva);
        if (tarifaIva.isEmpty()) {
            throw new IllegalArgumentException("No existe tarifa IVA activa en modulo_d.tarifas_iva para id_tarifa=" + idTarifaIva + ".");
        }
        BigDecimal baseImponible = requiredDecimal(form, "base_imponible", "Ingrese la base imponible.");
        if (baseImponible.compareTo(BigDecimal.ZERO) <= 0) {
            throw new IllegalArgumentException("La base imponible debe ser mayor a cero.");
        }
        if (!excepcional) {
            Map<String, Object> referencia = referenciaFactura(idOc, idRecepcion);
            if (referencia.isEmpty()) {
                throw new IllegalArgumentException("No se encontro referencia activa de orden/recepcion para calcular la base imponible.");
            }
            Integer idOcReferencia = ((Number) referencia.get("id_oc")).intValue();
            Integer idProveedorReferencia = ((Number) referencia.get("id_proveedor")).intValue();
            if (!idOc.equals(idOcReferencia) || !idProveedor.equals(idProveedorReferencia)) {
                throw new IllegalArgumentException("La orden, recepcion y proveedor no corresponden entre si.");
            }
            BigDecimal pendiente = money(referencia.get("monto_pendiente_base"));
            if (pendiente.compareTo(BigDecimal.ZERO) <= 0) {
                throw new IllegalArgumentException("La orden o recepcion seleccionada no tiene base pendiente por facturar.");
            }
            if (baseImponible.compareTo(pendiente) > 0) {
                throw new IllegalArgumentException("La base imponible supera el monto pendiente facturable de la referencia seleccionada (" + pendiente + ").");
            }
        }
        BigDecimal porcentajeIva = money(tarifaIva.get("porcentaje"));
        BigDecimal montoIva = baseImponible.multiply(porcentajeIva)
                .divide(new BigDecimal("100"), 2, RoundingMode.HALF_UP);
        dao.call("{CALL sp_ingresar_factura_proveedor(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)}",
                required(form, "numero_factura", "Ingrese el numero de factura."),
                required(form, "numero_serie", "Ingrese la serie."),
                required(form, "codigo_sustento", "Ingrese el codigo de sustento."),
                idProveedor,
                idOc,
                idRecepcion,
                baseImponible,
                montoIva,
                clean(form.get("tipo_bien_servicio")),
                idTarifaIva,
                excepcional,
                excepcional ? required(form, "motivo_excepcion", "Ingrese el motivo de excepcion.") : null,
                excepcional ? required(form, "usuario_autorizador", "Ingrese el usuario autorizador.") : null,
                USUARIO_OPERATIVO);
    }

    public List<Map<String, Object>> facturasPendientesRetencion() throws SQLException {
        return dao.query("SELECT * FROM vw_facturas_pendientes_retencion ORDER BY fecha DESC, idFactura DESC");
    }

    public List<Map<String, Object>> retencionesRentaConfig() throws SQLException {
        return dao.retencionesRentaConfig();
    }

    public List<Map<String, Object>> retencionesIvaConfig() throws SQLException {
        return dao.retencionesIvaConfig();
    }

    public List<Map<String, Object>> tarifasIvaModuloD() throws SQLException {
        return dao.tarifasIvaModuloD();
    }

    public void marcarRetencion(Map<String, String> form) throws SQLException {
        RoleGuard.require(AppRole.ADMINISTRADOR, AppRole.JEFE_COMPRAS);
        Integer idFactura = requiredInt(form, "id_factura", "Seleccione una factura.");
        Integer idRetRenta = requiredInt(form, "id_ret_renta", "Seleccione configuracion de retencion de renta del Modulo D.");
        Integer idRetIva = requiredInt(form, "id_ret_iva", "Seleccione configuracion de retencion de IVA del Modulo D.");
        String numeroComprobante = required(form, "numero_comprobante", "Ingrese numero de comprobante de retencion.");
        String autorizacion = required(form, "num_autorizacion", "Ingrese numero de autorizacion de retencion.");
        dao.registrarRetencionReal(idFactura, idRetRenta, idRetIva, numeroComprobante, autorizacion);
    }

    public List<Map<String, Object>> cuentas() throws SQLException {
        return dao.query("""
                SELECT c.id_cxp, p.razon_social, f.numero_factura_proveedor,
                       c.monto_original, c.saldo_pendiente, c.fecha_vencimiento,
                       c.fecha_programada, c.estado
                FROM CuentaPorPagar c
                JOIN Proveedor p ON p.id_proveedor = c.id_proveedor
                JOIN FacturaProveedor f ON f.id_factura_prov = c.id_factura_prov
                WHERE c.activo = 1
                ORDER BY c.fecha_vencimiento, c.id_cxp
                """);
    }

    public List<Map<String, Object>> cuentasPendientes() throws SQLException {
        return dao.query("SELECT * FROM vw_cuentas_pendientes ORDER BY fecha_vencimiento, id_cxp");
    }

    public void programarPago(Map<String, String> form) throws SQLException {
        RoleGuard.require(AppRole.ADMINISTRADOR, AppRole.TESORERO);
        Integer idCxp = requiredInt(form, "id_cxp", "Seleccione una cuenta por pagar.");
        LocalDate fecha = requiredDate(form, "fecha_programada", "Ingrese la fecha programada.");
        dao.call("{CALL sp_programar_pago(?, ?, ?)}", idCxp, fecha, USUARIO_TESORERIA);
    }

    public List<Map<String, Object>> estadoProveedor(Map<String, String> query) throws SQLException {
        Integer idProveedor = optionalInt(query, "id_proveedor");
        if (idProveedor == null) {
            return List.of();
        }
        return dao.callQuery("{CALL sp_estado_cuenta_proveedor(?, ?, ?)}",
                idProveedor,
                optionalDateOrDefault(query, "desde", LocalDate.now().minusYears(2)),
                optionalDateOrDefault(query, "hasta", LocalDate.now().plusYears(1)));
    }

    public List<Map<String, Object>> pagos() throws SQLException {
        return dao.query("""
                SELECT pp.id_pago, p.razon_social, pp.id_cxp, pp.fecha_pago,
                       pp.monto, pp.forma_pago, pp.referencia
                FROM PagoProveedor pp
                JOIN Proveedor p ON p.id_proveedor = pp.id_proveedor
                WHERE pp.activo = 1
                ORDER BY pp.fecha_pago DESC, pp.id_pago DESC
                """);
    }

    public List<Map<String, Object>> cuentaPorId(int idCxp) throws SQLException {
        return dao.query("""
                SELECT c.id_cxp, p.razon_social, f.numero_factura_proveedor,
                       c.monto_original, c.saldo_pendiente, c.fecha_vencimiento, c.estado
                FROM CuentaPorPagar c
                JOIN Proveedor p ON p.id_proveedor = c.id_proveedor
                JOIN FacturaProveedor f ON f.id_factura_prov = c.id_factura_prov
                WHERE c.id_cxp = ? AND c.activo = 1
                """, idCxp);
    }

    public void registrarPago(Map<String, String> form) throws SQLException {
        RoleGuard.require(AppRole.ADMINISTRADOR, AppRole.TESORERO);
        dao.call("{CALL sp_registrar_pago(?, ?, ?, ?, ?)}",
                requiredInt(form, "id_cxp", "Seleccione una cuenta por pagar."),
                requiredDecimal(form, "monto", "Ingrese el monto del pago."),
                required(form, "forma_pago", "Seleccione la forma de pago."),
                clean(form.get("referencia")),
                USUARIO_TESORERIA);
    }

    public List<Map<String, Object>> pagosPorVencer(Map<String, String> query) throws SQLException {
        Integer dias = optionalInt(query, "dias");
        List<Map<String, Object>> rows = dao.callQuery("{CALL sp_alertar_pagos_por_vencer(?)}", dias);
        for (Map<String, Object> row : rows) {
            Object id = row.get("id_cxp");
            if (id == null) {
                continue;
            }
            List<Map<String, Object>> estado = dao.query("""
                    SELECT estado
                    FROM CuentaPorPagar
                    WHERE id_cxp = ? AND activo = 1
                    """, id);
            if (!estado.isEmpty()) {
                row.put("estado", estado.get(0).get("estado"));
            }
        }
        return rows;
    }

    public List<Map<String, Object>> explainPagosPorVencer(Map<String, String> query) throws SQLException {
        Integer dias = optionalInt(query, "dias");
        return dao.explainPagosPorVencer(dias == null ? 7 : dias);
    }

    public List<Map<String, Object>> obligaciones(Map<String, String> query) throws SQLException {
        String criterio = clean(query.getOrDefault("criterio", "vencimiento"));
        if (criterio == null) {
            criterio = "vencimiento";
        }
        return dao.callQuery("{CALL sp_reporte_obligaciones_pendientes(?, ?, ?)}",
                criterio,
                optionalDateOrDefault(query, "desde", LocalDate.now().minusYears(1)),
                optionalDateOrDefault(query, "hasta", LocalDate.now().plusYears(1)));
    }

    public List<Map<String, Object>> conciliacion(Map<String, String> query) throws SQLException {
        return dao.callQuery("{CALL sp_conciliar_saldos_proveedor(?)}", optionalInt(query, "id_proveedor"));
    }

    public List<Map<String, Object>> costoProductoModuloA(Map<String, String> form) throws SQLException {
        Integer productoId = requiredInt(form, "id_producto", "Ingrese el id_producto de Modulo B.");
        return dao.costoProductoModuloA(productoId);
    }

    public List<Map<String, Object>> ultimosCostosModuloA(Map<String, String> form) throws SQLException {
        Integer productoId = requiredInt(form, "id_producto", "Ingrese el id_producto de Modulo B.");
        Integer limite = optionalInt(form, "limite");
        return dao.ultimosCostosAdquisicionModuloA(productoId, limite == null ? 5 : limite);
    }

    private String buildOrdenItemsJson(Map<String, String> form) throws SQLException {
        List<String> items = new ArrayList<>();
        for (int i = 1; i <= 3; i++) {
            String id = clean(form.get("id_producto_" + i));
            if (id == null) {
                continue;
            }
            Integer productoId = parseInt(id, "Cada item requiere producto_id numerico.");
            Map<String, Object> producto = dao.productoModuloB(productoId);
            if (producto.isEmpty()) {
                throw new IllegalArgumentException("No existe producto activo en modulo_b.productos para producto_id=" + productoId + ".");
            }
            BigDecimal precio = optionalDecimal(form, "precio_costo_" + i);
            if (precio == null) {
                precio = decimal(producto.get("costo"));
            }
            items.add("{\"id_producto\":" + productoId +
                    ",\"codigo_producto\":\"" + json(String.valueOf(producto.get("codigo"))) + "\"" +
                    ",\"descripcion\":\"" + json(String.valueOf(producto.get("descripcion"))) + "\"" +
                    ",\"unidad_medida\":\"unidad\"" +
                    ",\"cantidad\":" + requiredInt(form, "cantidad_" + i, "Cada item requiere cantidad.") +
                    ",\"precio_costo\":" + precio +
                    "}");
        }
        if (items.isEmpty()) {
            throw new IllegalArgumentException("La orden debe tener al menos un producto activo del Modulo B.");
        }
        return "[" + String.join(",", items) + "]";
    }

    private String buildRecepcionItemsJson(Map<String, String> form, List<Map<String, Object>> detalles) {
        Map<Integer, Integer> restantes = new HashMap<>();
        Map<Integer, String> productos = new HashMap<>();
        for (Map<String, Object> detalle : detalles) {
            Integer idDetalle = ((Number) detalle.get("id_detalle_oc")).intValue();
            restantes.put(idDetalle, intValue(detalle.get("cantidad_restante")));
            productos.put(idDetalle, String.valueOf(detalle.get("descripcion_al_momento")));
        }

        List<String> items = new ArrayList<>();
        for (Map.Entry<String, String> entry : form.entrySet()) {
            if (!entry.getKey().startsWith("cantidad_recibida_")) {
                continue;
            }
            String value = clean(entry.getValue());
            if (value == null) {
                continue;
            }
            String idDetalle = entry.getKey().substring("cantidad_recibida_".length());
            int detalleId = parseInt(idDetalle, "Detalle de orden invalido.");
            int cantidad = parseInt(value, "Cantidad recibida invalida.");
            if (cantidad < 0) {
                throw new IllegalArgumentException("La cantidad recibida no puede ser negativa.");
            }
            if (cantidad == 0) {
                continue;
            }
            Integer restante = restantes.get(detalleId);
            if (restante == null) {
                throw new IllegalArgumentException("El detalle de orden no pertenece a la orden seleccionada.");
            }
            if (cantidad > restante) {
                throw new IllegalArgumentException("La cantidad recibida para " + productos.get(detalleId)
                        + " supera la cantidad restante (" + restante + ").");
            }
            items.add("{\"id_detalle_oc\":" + detalleId +
                    ",\"cantidad_recibida\":" + cantidad + "}");
        }
        if (items.isEmpty()) {
            throw new IllegalArgumentException("La recepcion debe tener al menos un detalle recibido.");
        }
        return "[" + String.join(",", items) + "]";
    }

    private String json(String value) {
        return value.replace("\\", "\\\\").replace("\"", "\\\"");
    }

    private String required(Map<String, String> form, String name, String message) {
        String value = clean(form.get(name));
        if (value == null) {
            throw new IllegalArgumentException(message);
        }
        return value;
    }

    private Integer requiredInt(Map<String, String> form, String name, String message) {
        return parseInt(required(form, name, message), message);
    }

    private Integer optionalInt(Map<String, String> form, String name) {
        String value = clean(form.get(name));
        return value == null ? null : parseInt(value, name + " debe ser numerico.");
    }

    private Integer parseInt(String value, String message) {
        try {
            return Integer.parseInt(value);
        } catch (NumberFormatException ex) {
            throw new IllegalArgumentException(message);
        }
    }

    private BigDecimal requiredDecimal(Map<String, String> form, String name, String message) {
        try {
            return new BigDecimal(required(form, name, message));
        } catch (NumberFormatException ex) {
            throw new IllegalArgumentException(message);
        }
    }

    private BigDecimal optionalDecimal(Map<String, String> form, String name) {
        String value = clean(form.get(name));
        if (value == null) {
            return null;
        }
        try {
            return new BigDecimal(value);
        } catch (NumberFormatException ex) {
            throw new IllegalArgumentException(name + " debe ser numerico.");
        }
    }

    private BigDecimal decimal(Object value) {
        if (value instanceof BigDecimal decimalValue) {
            return decimalValue;
        }
        if (value instanceof Number number) {
            return BigDecimal.valueOf(number.doubleValue());
        }
        return new BigDecimal(value.toString());
    }

    private BigDecimal money(Object value) {
        return decimal(value).setScale(2, RoundingMode.HALF_UP);
    }

    private BigDecimal maxZero(BigDecimal value) {
        return value.compareTo(BigDecimal.ZERO) < 0 ? BigDecimal.ZERO.setScale(2, RoundingMode.HALF_UP) : value.setScale(2, RoundingMode.HALF_UP);
    }

    private int intValue(Object value) {
        if (value instanceof Number number) {
            return number.intValue();
        }
        return Integer.parseInt(value.toString());
    }

    private LocalDate requiredDate(Map<String, String> form, String name, String message) {
        try {
            return LocalDate.parse(required(form, name, message));
        } catch (Exception ex) {
            throw new IllegalArgumentException(message);
        }
    }

    private LocalDate optionalDate(Map<String, String> form, String name) {
        String value = clean(form.get(name));
        return value == null ? null : LocalDate.parse(value);
    }

    private LocalDate optionalDateOrDefault(Map<String, String> form, String name, LocalDate fallback) {
        String value = clean(form.get(name));
        return value == null ? fallback : LocalDate.parse(value);
    }

    private String clean(String value) {
        return value == null || value.isBlank() ? null : value.trim();
    }
}

package sige.moduloc.integration;

public enum ExternalModule {
    MODULO_B,
    MODULO_D
}

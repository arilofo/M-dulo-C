package sige.moduloc.controller;

import com.sun.net.httpserver.HttpExchange;
import sige.moduloc.http.FormParser;
import sige.moduloc.http.HtmlResponse;
import sige.moduloc.http.PageRenderer;
import sige.moduloc.http.ViewUtil;
import sige.moduloc.security.AppRole;
import sige.moduloc.service.MvpService;

import java.io.IOException;
import java.util.List;
import java.util.Map;

public class OrdenController extends WebControllerSupport {
    private final MvpService service;

    public OrdenController(MvpService service) {
        this.service = service;
    }

    public void listar(HttpExchange exchange) throws IOException {
        try {
            HtmlResponse.ok(exchange, PageRenderer.layout("""
                    <section class="section page-heading">
                        <div><h2>Ordenes de compra</h2><p>Ordenes activas del Modulo C.</p></div>
                        <div class="actions">
                            <a class="button" href="/ordenes/pendientes">Pendientes de recepcion</a>
                            <a class="button primary" href="/ordenes/nueva">Nueva orden</a>
                        </div>
                    </section>
                    %s
                    %s
                    """.formatted(ViewUtil.message(FormParser.parseQuery(exchange)), ordenesConAcciones(service.ordenes()))));
        } catch (Exception ex) {
            renderError(exchange, "No se pudieron cargar las ordenes.", ex, "/");
        }
    }

    public void nueva(HttpExchange exchange) throws IOException {
        try {
            requireRole(AppRole.ADMINISTRADOR, AppRole.JEFE_COMPRAS);
            List<Map<String, Object>> productos = service.productosModuloB();
            String catalogo = "<div class=\"status\"><strong>Catalogo modulo B conectado.</strong><p>Los items de la orden se toman de <code>modulo_b.productos</code>.</p></div>" + ViewUtil.table(productos);
            HtmlResponse.ok(exchange, PageRenderer.layout("""
                    <section class="section page-heading">
                        <div><h2>Nueva orden de compra</h2><p>Usa <code>sp_crear_orden_compra</code>.</p></div>
                        <a class="button" href="/ordenes">Volver</a>
                    </section>
                    <form class="form-panel" method="post" action="/ordenes/crear">
                        <div class="status">
                            <strong>Referencia IF-02 de Modulo B</strong>
                            <p>No se encontro una tabla o vista real de solicitudes de compra en el script del Modulo B; se permite ingresar la referencia logica manualmente.</p>
                        </div>
                        <div class="form-grid">
                            <label>Proveedor
                                <select name="id_proveedor" required>
                                    <option value="">Seleccione...</option>
                                    %s
                                </select>
                            </label>
                            <label>ID solicitud Modulo B (opcional)
                                <input name="id_solicitud" type="number" min="1">
                            </label>
                            <label>Fecha entrega esperada
                                <input name="fecha_entrega" type="date">
                            </label>
                            <label>Observaciones
                                <input name="observaciones" maxlength="300">
                            </label>
                        </div>
                        <h3>Items de la orden</h3>
                        %s
                        <div class="form-actions">
                            <button class="button primary" type="submit">Crear orden</button>
                            <a class="button" href="/ordenes">Cancelar</a>
                        </div>
                    </form>
                    <section class="section">%s</section>
                    """.formatted(
                    ViewUtil.options(service.proveedoresActivos(), "id_proveedor", "razon_social", "identificacion"),
                    itemsOrdenForm(productos),
                    catalogo)));
        } catch (Exception ex) {
            renderError(exchange, "No se pudo abrir el formulario de orden.", ex, "/ordenes");
        }
    }

    public void crear(HttpExchange exchange) throws IOException {
        try {
            requireRole(AppRole.ADMINISTRADOR, AppRole.JEFE_COMPRAS);
            service.crearOrden(FormParser.parseForm(exchange));
            redirect(exchange, "/ordenes", "ok", "Orden creada correctamente. Quedo en estado emitida.");
        } catch (Exception ex) {
            renderError(exchange, "No se pudo crear la orden.", ex, "/ordenes/nueva");
        }
    }

    public void detalle(HttpExchange exchange) throws IOException {
        try {
            int id = Integer.parseInt(FormParser.parseQuery(exchange).getOrDefault("id", "0"));
            HtmlResponse.ok(exchange, PageRenderer.layout("""
                    <section class="section page-heading">
                        <div><h2>Detalle de orden</h2><p>Cabecera y detalles activos.</p></div>
                        <a class="button" href="/ordenes">Volver</a>
                    </section>
                    %s
                    %s
                    """.formatted(ViewUtil.table(service.ordenCabecera(id)), ViewUtil.table(service.ordenDetalle(id)))));
        } catch (Exception ex) {
            renderError(exchange, "No se pudo cargar el detalle.", ex, "/ordenes");
        }
    }

    public void pendientes(HttpExchange exchange) throws IOException {
        try {
            HtmlResponse.ok(exchange, PageRenderer.layout("""
                    <section class="section page-heading">
                        <div><h2>Ordenes pendientes de recepcion</h2><p>Consulta por <code>sp_reporte_ordenes_pendientes_recepcion</code>.</p></div>
                        <a class="button" href="/ordenes">Volver</a>
                    </section>
                    %s
                    """.formatted(ViewUtil.table(service.ordenesPendientes()))));
        } catch (Exception ex) {
            renderError(exchange, "No se pudieron cargar las ordenes pendientes.", ex, "/ordenes");
        }
    }

    private String ordenesConAcciones(List<Map<String, Object>> rows) {
        if (rows.isEmpty()) {
            return ViewUtil.table(rows);
        }
        StringBuilder html = new StringBuilder("<section class=\"section table-wrap\"><table><thead><tr><th>ID</th><th>Numero</th><th>Proveedor</th><th>Emision</th><th>Entrega</th><th>Estado</th><th>Total</th><th>Acciones</th></tr></thead><tbody>");
        for (Map<String, Object> row : rows) {
            Object id = row.get("id_oc");
            html.append("<tr><td>").append(ViewUtil.e(id)).append("</td><td>").append(ViewUtil.e(row.get("numero_oc")))
                    .append("</td><td>").append(ViewUtil.e(row.get("razon_social"))).append("</td><td>").append(ViewUtil.e(row.get("fecha_emision")))
                    .append("</td><td>").append(ViewUtil.e(row.get("fecha_entrega_esperada"))).append("</td><td>").append(ViewUtil.e(row.get("estado")))
                    .append("</td><td>").append(ViewUtil.e(row.get("total_estimado"))).append("</td><td class=\"actions\">")
                    .append("<a class=\"button compact\" href=\"/ordenes/detalle?id=").append(ViewUtil.e(id)).append("\">Detalle</a>")
                    .append("<a class=\"button compact\" href=\"/recepciones/nueva?ordenId=").append(ViewUtil.e(id)).append("\">Recibir</a>")
                    .append("</td></tr>");
        }
        return html.append("</tbody></table></section>").toString();
    }

    private String itemsOrdenForm(List<Map<String, Object>> productos) {
        StringBuilder html = new StringBuilder();
        for (int i = 1; i <= 3; i++) {
            html.append("""
                    <div class="subpanel">
                        <strong>Item %d</strong>
                        <div class="form-grid">
                            <label>Producto Modulo B
                                <select name="id_producto_%d">
                                    <option value="">Sin item</option>
                                    %s
                                </select>
                            </label>
                            <label>Cantidad<input name="cantidad_%d" type="number" min="1"></label>
                            <label>Precio pactado<input name="precio_costo_%d" type="number" step="0.01" min="0"><span class="hint">Si se deja vacio, se usa costo de modulo_b.productos.</span></label>
                        </div>
                    </div>
                    """.formatted(i, i, productOptions(productos), i, i));
        }
        return html.toString();
    }

    private String productOptions(List<Map<String, Object>> productos) {
        StringBuilder html = new StringBuilder();
        for (Map<String, Object> row : productos) {
            html.append("<option value=\"").append(ViewUtil.e(row.get("producto_id"))).append("\">")
                    .append(ViewUtil.e(row.get("producto_id"))).append(" - ")
                    .append(ViewUtil.e(row.get("codigo"))).append(" - ")
                    .append(ViewUtil.e(row.get("descripcion"))).append(" - costo ")
                    .append(ViewUtil.e(row.get("costo"))).append("</option>");
        }
        return html.toString();
    }
}

package sige.moduloc.service;

import sige.moduloc.dao.ProveedorDao;
import sige.moduloc.model.Proveedor;
import sige.moduloc.model.ProveedorForm;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;
import java.util.Optional;

public class ProveedorService {
    private static final String USUARIO_DEMO = "app_modulo_c";

    private final ProveedorDao proveedorDao;

    public ProveedorService(ProveedorDao proveedorDao) {
        this.proveedorDao = proveedorDao;
    }

    public List<Proveedor> listarActivos() throws SQLException {
        return proveedorDao.listarActivos();
    }

    public Optional<Proveedor> buscarActivoPorId(int idProveedor) throws SQLException {
        return proveedorDao.buscarActivoPorId(idProveedor);
    }

    public void registrar(Map<String, String> params) throws SQLException {
        ProveedorForm form = toForm(params, 0, true);
        proveedorDao.registrar(form);
    }

    public void actualizar(Map<String, String> params) throws SQLException {
        int idProveedor = parseRequiredInt(params.get("id_proveedor"), "El proveedor es obligatorio.");
        ProveedorForm form = toForm(params, idProveedor, false);
        proveedorDao.actualizar(form);
    }

    public void eliminar(Map<String, String> params) throws SQLException {
        int idProveedor = parseRequiredInt(params.get("id_proveedor"), "El proveedor es obligatorio.");
        proveedorDao.eliminarLogico(idProveedor, USUARIO_DEMO);
    }

    private ProveedorForm toForm(Map<String, String> params, int idProveedor, boolean includeSubtype) {
        return new ProveedorForm(
                idProveedor,
                clean(params.get("tipo_proveedor")),
                clean(params.get("identificacion")),
                clean(params.get("razon_social")),
                clean(params.get("email")),
                clean(params.get("telefono")),
                clean(params.get("direccion")),
                parseOptionalInt(params.get("dias_credito")),
                clean(params.get("cuenta_bancaria")),
                clean(params.get("banco")),
                clean(params.get("calificacion")),
                includeSubtype ? clean(params.get("cedula")) : null,
                includeSubtype ? clean(params.get("razon_social_comercial")) : null,
                includeSubtype ? clean(params.get("nombre_comercial")) : null,
                USUARIO_DEMO
        );
    }

    private int parseRequiredInt(String value, String message) {
        try {
            return Integer.parseInt(value);
        } catch (Exception ex) {
            throw new IllegalArgumentException(message);
        }
    }

    private Integer parseOptionalInt(String value) {
        String cleanValue = clean(value);
        if (cleanValue == null) {
            return null;
        }
        try {
            return Integer.parseInt(cleanValue);
        } catch (NumberFormatException ex) {
            throw new IllegalArgumentException("Dias de credito debe ser un numero entero.");
        }
    }

    private String clean(String value) {
        if (value == null || value.isBlank()) {
            return null;
        }
        return value.trim();
    }
}

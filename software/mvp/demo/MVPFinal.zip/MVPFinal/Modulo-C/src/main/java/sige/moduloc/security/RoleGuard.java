package sige.moduloc.security;

import java.util.Arrays;

public final class RoleGuard {
    private RoleGuard() {
    }

    public static void require(AppRole... allowed) {
        AppRole current = RoleContext.current();
        boolean permitted = Arrays.stream(allowed).anyMatch(role -> role == current);
        if (!permitted) {
            throw new SecurityException("No tiene permisos para realizar esta operacion");
        }
    }
}

package sige.moduloc.controller;

import com.sun.net.httpserver.HttpExchange;
import sige.moduloc.http.FormParser;
import sige.moduloc.http.HtmlResponse;
import sige.moduloc.http.PageRenderer;
import sige.moduloc.http.ViewUtil;
import sige.moduloc.security.AppRole;
import sige.moduloc.service.MvpService;

import java.io.IOException;

public class PagoController extends WebControllerSupport {
    private final MvpService service;

    public PagoController(MvpService service) {
        this.service = service;
    }

    public void listar(HttpExchange exchange) throws IOException {
        try {
            requireRole(AppRole.ADMINISTRADOR, AppRole.TESORERO);
            HtmlResponse.ok(exchange, PageRenderer.layout("""
                    <section class="section page-heading">
                        <div><h2>Pagos</h2><p>Pagos registrados contra cuentas por pagar.</p></div>
                        <a class="button primary" href="/pagos/nuevo">Nuevo pago</a>
                    </section>
                    %s
                    %s
                    """.formatted(ViewUtil.message(FormParser.parseQuery(exchange)), ViewUtil.table(service.pagos()))));
        } catch (Exception ex) {
            renderError(exchange, "No se pudieron cargar los pagos.", ex, "/");
        }
    }

    public void nuevo(HttpExchange exchange) throws IOException {
        try {
            requireRole(AppRole.ADMINISTRADOR, AppRole.TESORERO);
            var query = FormParser.parseQuery(exchange);
            String cuentaId = query.getOrDefault("cuentaId", "");
            String resumen = "";
            if (!cuentaId.isBlank()) {
                resumen = ViewUtil.table(service.cuentaPorId(Integer.parseInt(cuentaId)));
            }
            HtmlResponse.ok(exchange, PageRenderer.layout("""
                    <section class="section page-heading">
                        <div><h2>Nuevo pago</h2><p>Usa <code>sp_registrar_pago</code>.</p></div>
                        <a class="button" href="/pagos">Volver</a>
                    </section>
                    %s
                    <form class="form-panel" method="post" action="/pagos/crear">
                        <div class="form-grid">
                            <label>ID cuenta por pagar<input name="id_cxp" type="number" min="1" required value="%s"></label>
                            <label>Monto<input name="monto" type="number" step="0.01" min="0.01" required></label>
                            <label>Forma de pago
                                <select name="forma_pago" required>
                                    <option value="transferencia">Transferencia</option>
                                    <option value="cheque">Cheque</option>
                                    <option value="efectivo">Efectivo</option>
                                </select>
                            </label>
                            <label>Referencia<input name="referencia" maxlength="100"></label>
                        </div>
                        <div class="form-actions">
                            <button class="button primary" type="submit">Registrar pago</button>
                            <a class="button" href="/cuentas">Cancelar</a>
                        </div>
                    </form>
                    """.formatted(resumen, ViewUtil.e(cuentaId))));
        } catch (Exception ex) {
            renderError(exchange, "No se pudo abrir el formulario de pago.", ex, "/pagos");
        }
    }

    public void crear(HttpExchange exchange) throws IOException {
        try {
            requireRole(AppRole.ADMINISTRADOR, AppRole.TESORERO);
            service.registrarPago(FormParser.parseForm(exchange));
            redirect(exchange, "/pagos", "ok", "Pago registrado. El saldo fue actualizado por el procedimiento almacenado.");
        } catch (Exception ex) {
            renderError(exchange, "No se pudo registrar el pago.", ex, "/pagos/nuevo");
        }
    }
}

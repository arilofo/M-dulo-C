package sige.moduloc.http;

import com.sun.net.httpserver.HttpExchange;

import java.io.IOException;

@FunctionalInterface
public interface Handler {
    void handle(HttpExchange exchange) throws IOException;
}

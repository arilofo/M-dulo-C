package sige.moduloc.controller;

import com.sun.net.httpserver.HttpExchange;
import sige.moduloc.http.FormParser;
import sige.moduloc.http.HtmlResponse;
import sige.moduloc.http.PageRenderer;
import sige.moduloc.http.ViewUtil;
import sige.moduloc.security.AppRole;
import sige.moduloc.service.MvpService;

import java.io.IOException;
import java.util.List;
import java.util.Map;

public class RecepcionController extends WebControllerSupport {
    private final MvpService service;

    public RecepcionController(MvpService service) {
        this.service = service;
    }

    public void listar(HttpExchange exchange) throws IOException {
        try {
            HtmlResponse.ok(exchange, PageRenderer.layout("""
                    <section class="section page-heading">
                        <div><h2>Recepciones</h2><p>Recepciones activas y estado de notificacion a inventario.</p></div>
                        <div class="actions">
                            <a class="button" href="/recepciones/pendientes-notificar">Pendientes de notificar</a>
                            <a class="button primary" href="/recepciones/nueva">Nueva recepcion</a>
                        </div>
                    </section>
                    %s
                    %s
                    """.formatted(ViewUtil.message(FormParser.parseQuery(exchange)), ViewUtil.table(service.recepciones()))));
        } catch (Exception ex) {
            renderError(exchange, "No se pudieron cargar las recepciones.", ex, "/");
        }
    }

    public void nueva(HttpExchange exchange) throws IOException {
        try {
            requireRole(AppRole.ADMINISTRADOR, AppRole.JEFE_COMPRAS);
            Map<String, String> query = FormParser.parseQuery(exchange);
            String selected = query.get("ordenId");
            String detalle = "";
            if (selected != null && !selected.isBlank()) {
                detalle = detalleRecepcionForm(Integer.parseInt(selected));
            }
            HtmlResponse.ok(exchange, PageRenderer.layout("""
                    <section class="section page-heading">
                        <div><h2>Nueva recepcion</h2><p>Usa <code>sp_registrar_recepcion</code> y actualiza inventario real en Modulo B.</p></div>
                        <a class="button" href="/recepciones">Volver</a>
                    </section>
                    <form class="form-panel" method="get" action="/recepciones/nueva">
                        <div class="form-grid">
                            <label>Orden pendiente
                                <select name="ordenId" required>
                                    <option value="">Seleccione...</option>
                                    %s
                                </select>
                            </label>
                        </div>
                        <div class="form-actions"><button class="button" type="submit">Cargar detalles</button></div>
                    </form>
                    %s
                    """.formatted(ordenOptions(service.ordenesParaRecepcion(), selected), detalle)));
        } catch (Exception ex) {
            renderError(exchange, "No se pudo abrir el formulario de recepcion.", ex, "/recepciones");
        }
    }

    public void crear(HttpExchange exchange) throws IOException {
        try {
            requireRole(AppRole.ADMINISTRADOR, AppRole.JEFE_COMPRAS);
            service.registrarRecepcion(FormParser.parseForm(exchange));
            redirect(exchange, "/recepciones", "ok", "Recepcion registrada e inventario actualizado en Modulo B.");
        } catch (Exception ex) {
            renderError(exchange, "No se pudo registrar la recepcion.", ex, "/recepciones");
        }
    }

    public void pendientesNotificar(HttpExchange exchange) throws IOException {
        try {
            HtmlResponse.ok(exchange, PageRenderer.layout("""
                    <section class="section page-heading">
                        <div><h2>Recepciones pendientes de notificar</h2><p>Vista <code>vw_recepciones_pendientes_notificar</code>.</p></div>
                        <a class="button" href="/recepciones">Volver</a>
                    </section>
                    %s
                    %s
                    """.formatted(ViewUtil.message(FormParser.parseQuery(exchange)), pendientesConAccion(service.recepcionesPendientesNotificar()))));
        } catch (Exception ex) {
            renderError(exchange, "No se pudieron cargar las recepciones pendientes.", ex, "/recepciones");
        }
    }

    public void marcarNotificada(HttpExchange exchange) throws IOException {
        try {
            requireRole(AppRole.ADMINISTRADOR, AppRole.JEFE_COMPRAS);
            service.marcarRecepcionNotificada(FormParser.parseForm(exchange));
            redirect(exchange, "/recepciones/pendientes-notificar", "ok", "Inventario actualizado en Modulo B y recepcion marcada como notificada.");
        } catch (Exception ex) {
            renderError(exchange, "No se pudo marcar la recepcion.", ex, "/recepciones/pendientes-notificar");
        }
    }

    private String detalleRecepcionForm(int ordenId) throws Exception {
        List<Map<String, Object>> detalles = service.ordenDetalleParaRecepcion(ordenId);
        if (detalles.isEmpty()) {
            return "<section class=\"section status error\">La orden no tiene detalles activos.</section>";
        }
        StringBuilder html = new StringBuilder("""
                <form class="form-panel" method="post" action="/recepciones/crear">
                    <input type="hidden" name="id_oc" value="%d">
                    <div class="form-grid">
                        <label>Tipo recepcion
                            <select name="tipo_recepcion" required>
                                <option value="parcial">Parcial</option>
                                <option value="completa">Completa</option>
                            </select>
                        </label>
                        <label>Bodega Modulo B
                            <select name="bodega_id" required>
                                <option value="">Seleccione...</option>
                                %s
                            </select>
                        </label>
                        <label>Observaciones<input name="observaciones" maxlength="300"></label>
                    </div>
                    <h3>Cantidades recibidas</h3>
                    <div class="form-actions">
                        <button class="button" type="button" data-fill-restantes>Recibir totalmente</button>
                    </div>
                    <section class="table-wrap"><table><thead><tr><th>Detalle</th><th>Producto</th><th>Solicitada</th><th>Recibido anteriormente</th><th>Restante</th><th>Recibir ahora</th></tr></thead><tbody>
                """.formatted(ordenId, ViewUtil.options(service.bodegasModuloB(), "bodega_id", "codigo", "nombre")));
        for (Map<String, Object> row : detalles) {
            Object idDetalle = row.get("id_detalle_oc");
            int restante = intValue(row.get("cantidad_restante"));
            String input = restante <= 0
                    ? "<span class=\"hint\">Recibido completamente</span><input class=\"cantidad-recepcion\" name=\"cantidad_recibida_" + ViewUtil.e(idDetalle) + "\" type=\"number\" min=\"0\" max=\"0\" value=\"0\" data-restante=\"0\" disabled>"
                    : "<input class=\"cantidad-recepcion\" name=\"cantidad_recibida_" + ViewUtil.e(idDetalle) + "\" type=\"number\" min=\"0\" max=\"" + restante + "\" value=\"0\" data-restante=\"" + restante + "\">";
            html.append("<tr><td>").append(ViewUtil.e(idDetalle)).append("</td><td>")
                    .append(ViewUtil.e(row.get("descripcion_al_momento"))).append("</td><td>")
                    .append(ViewUtil.e(row.get("cantidad_solicitada"))).append("</td><td>")
                    .append(ViewUtil.e(row.get("cantidad_recibida_previa"))).append("</td><td>")
                    .append(restante <= 0 ? "<strong>0</strong>" : ViewUtil.e(restante)).append("</td><td>")
                    .append("<div class=\"hint\">Solicitado: ").append(ViewUtil.e(row.get("cantidad_solicitada")))
                    .append(" | Recibido anteriormente: ").append(ViewUtil.e(row.get("cantidad_recibida_previa")))
                    .append(" | Restante: ").append(ViewUtil.e(restante)).append("</div>")
                    .append(input).append("</td></tr>");
        }
        html.append("""
                    </tbody></table></section>
                    <div class="form-actions">
                        <button class="button primary" type="submit">Registrar recepcion</button>
                        <a class="button" href="/recepciones">Cancelar</a>
                    </div>
                </form>
                <script>
                document.querySelectorAll('[data-fill-restantes]').forEach(function (button) {
                    button.addEventListener('click', function () {
                        var form = button.closest('form');
                        form.querySelectorAll('input[data-restante]').forEach(function (input) {
                            input.value = input.dataset.restante || '0';
                        });
                        var tipo = form.querySelector('select[name="tipo_recepcion"]');
                        if (tipo) {
                            tipo.value = 'completa';
                        }
                    });
                });
                </script>
                """);
        return html.toString();
    }

    private int intValue(Object value) {
        if (value instanceof Number number) {
            return number.intValue();
        }
        return Integer.parseInt(String.valueOf(value));
    }

    private String ordenOptions(List<Map<String, Object>> ordenes, String selected) {
        StringBuilder html = new StringBuilder();
        for (Map<String, Object> row : ordenes) {
            String id = String.valueOf(row.get("id_oc"));
            String selectedAttr = id.equals(selected) ? " selected" : "";
            html.append("<option value=\"").append(ViewUtil.e(id)).append("\"").append(selectedAttr).append(">")
                    .append(ViewUtil.e(row.get("numero_oc"))).append(" - ")
                    .append(ViewUtil.e(row.get("razon_social"))).append(" - ")
                    .append(ViewUtil.e(row.get("estado"))).append("</option>");
        }
        return html.toString();
    }

    private String pendientesConAccion(List<Map<String, Object>> rows) {
        if (rows.isEmpty()) {
            return ViewUtil.table(rows);
        }
        StringBuilder html = new StringBuilder("<section class=\"section table-wrap\"><table><thead><tr><th>Recepcion</th><th>Orden</th><th>Fecha</th><th>Producto</th><th>Cantidad</th><th>Accion</th></tr></thead><tbody>");
        for (Map<String, Object> row : rows) {
            Object id = row.get("id_recepcion");
            html.append("<tr><td>").append(ViewUtil.e(id)).append("</td><td>").append(ViewUtil.e(row.get("id_oc")))
                    .append("</td><td>").append(ViewUtil.e(row.get("fecha_recepcion"))).append("</td><td>").append(ViewUtil.e(row.get("ref_mod_b_id_producto")))
                    .append("</td><td>").append(ViewUtil.e(row.get("cantidad_recibida"))).append("</td><td>")
                    .append("<form method=\"post\" action=\"/recepciones/marcar-notificada\" class=\"inline-form\"><input type=\"hidden\" name=\"id_recepcion\" value=\"")
                    .append(ViewUtil.e(id)).append("\"><input name=\"bodega_id\" type=\"number\" min=\"1\" placeholder=\"Bodega\" required>")
                    .append("<button class=\"button compact primary\" type=\"submit\">Actualizar inventario</button></form>")
                    .append("</td></tr>");
        }
        return html.append("</tbody></table></section>").toString();
    }
}

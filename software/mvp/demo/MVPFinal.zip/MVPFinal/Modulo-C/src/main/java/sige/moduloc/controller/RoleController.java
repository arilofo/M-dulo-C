package sige.moduloc.controller;

import com.sun.net.httpserver.HttpExchange;
import sige.moduloc.http.FormParser;
import sige.moduloc.http.HtmlResponse;
import sige.moduloc.http.PageRenderer;
import sige.moduloc.security.AppRole;
import sige.moduloc.security.RoleContext;

import java.io.IOException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.Map;

public class RoleController {
    public void seleccionar(HttpExchange exchange) throws IOException {
        HtmlResponse.ok(exchange, PageRenderer.layout("""
                <section class="section page-heading">
                    <div><h2>Rol de demo</h2><p>Seleccione el rol operativo para validar permisos en la capa de aplicacion.</p></div>
                    <a class="button" href="/">Volver</a>
                </section>
                %s
                """.formatted(form("/"))));
    }

    public void guardar(HttpExchange exchange) throws IOException {
        Map<String, String> form = FormParser.parseForm(exchange);
        AppRole role = AppRole.fromCookie(form.get("rol"));
        RoleContext.set(role);
        exchange.getResponseHeaders().add("Set-Cookie", "rol=" + role.name() + "; Path=/; HttpOnly; SameSite=Lax");
        String volver = form.getOrDefault("volver", "/");
        exchange.getResponseHeaders().set("Location", safeLocation(volver));
        exchange.sendResponseHeaders(303, -1);
        exchange.close();
    }

    public static String form(String volver) {
        StringBuilder options = new StringBuilder();
        for (AppRole role : AppRole.values()) {
            String selected = role == RoleContext.current() ? " selected" : "";
            options.append("<option value=\"").append(role.name()).append("\"").append(selected).append(">")
                    .append(HtmlResponse.escape(role.label())).append("</option>");
        }
        return """
                <form class="role-form" method="post" action="/rol">
                    <input type="hidden" name="volver" value="%s">
                    <label>Rol activo
                        <select name="rol">%s</select>
                    </label>
                    <button class="button compact" type="submit">Cambiar</button>
                </form>
                """.formatted(HtmlResponse.escape(volver), options);
    }

    private String safeLocation(String value) {
        if (value == null || value.isBlank() || !value.startsWith("/")) {
            return "/";
        }
        return URLEncoder.encode(value, StandardCharsets.UTF_8).replace("%2F", "/").replace("%3F", "?").replace("%3D", "=").replace("%26", "&");
    }
}

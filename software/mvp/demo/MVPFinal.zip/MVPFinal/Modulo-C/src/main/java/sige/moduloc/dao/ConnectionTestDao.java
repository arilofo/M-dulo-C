package sige.moduloc.dao;

import sige.moduloc.config.Database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ConnectionTestDao {
    private final Database database;

    public ConnectionTestDao(Database database) {
        this.database = database;
    }

    public String readCurrentDatabase() throws SQLException {
        try (Connection connection = database.getConnection();
             PreparedStatement statement = connection.prepareStatement("SELECT DATABASE()");
             ResultSet resultSet = statement.executeQuery()) {
            if (resultSet.next()) {
                String databaseName = resultSet.getString(1);
                return databaseName == null ? "(sin base seleccionada)" : databaseName;
            }
            return "(sin resultado)";
        }
    }
}

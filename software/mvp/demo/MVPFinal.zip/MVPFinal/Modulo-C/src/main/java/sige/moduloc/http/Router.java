package sige.moduloc.http;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;
import sige.moduloc.security.AppRole;
import sige.moduloc.security.RoleContext;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

public class Router {
    private final Map<String, Handler> getHandlers = new HashMap<>();
    private final Map<String, Handler> postHandlers = new HashMap<>();

    public Router(HttpServer server) {
        server.createContext("/", this::dispatch);
    }

    public void get(String path, Handler handler) {
        getHandlers.put(path, handler);
    }

    public void post(String path, Handler handler) {
        postHandlers.put(path, handler);
    }

    public void staticFile(String path, String resourcePath, String contentType) {
        get(path, exchange -> {
            try (InputStream input = Router.class.getClassLoader().getResourceAsStream(resourcePath)) {
                if (input == null) {
                    HtmlResponse.notFound(exchange);
                    return;
                }
                HtmlResponse.send(exchange, 200, new String(input.readAllBytes(), StandardCharsets.UTF_8), contentType);
            }
        });
    }

    private void dispatch(HttpExchange exchange) throws IOException {
        try {
            RoleContext.set(AppRole.fromCookie(cookie(exchange, "rol")));
            String method = exchange.getRequestMethod();
            Map<String, Handler> handlers;
            if ("GET".equalsIgnoreCase(method)) {
                handlers = getHandlers;
            } else if ("POST".equalsIgnoreCase(method)) {
                handlers = postHandlers;
            } else {
                HtmlResponse.methodNotAllowed(exchange);
                return;
            }

            String path = exchange.getRequestURI().getPath();
            Handler handler = handlers.get(path);
            if (handler == null) {
                HtmlResponse.notFound(exchange);
                return;
            }

            handler.handle(exchange);
        } catch (Exception ex) {
            HtmlResponse.serverError(exchange, ex);
        } finally {
            RoleContext.clear();
        }
    }

    private String cookie(HttpExchange exchange, String name) {
        String header = exchange.getRequestHeaders().getFirst("Cookie");
        if (header == null) {
            return null;
        }
        for (String cookie : header.split(";")) {
            String[] parts = cookie.trim().split("=", 2);
            if (parts.length == 2 && parts[0].equals(name)) {
                return parts[1];
            }
        }
        return null;
    }
}

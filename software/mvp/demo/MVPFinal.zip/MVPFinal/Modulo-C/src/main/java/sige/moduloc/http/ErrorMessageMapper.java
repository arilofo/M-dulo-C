package sige.moduloc.http;

import sige.moduloc.integration.ExternalModule;
import sige.moduloc.integration.ModuleIntegrationException;

import java.sql.SQLException;

public final class ErrorMessageMapper {
    private ErrorMessageMapper() {
    }

    public static String toUserMessage(Throwable throwable) {
        ModuleIntegrationException integration = find(throwable, ModuleIntegrationException.class);
        if (integration != null) {
            return integrationMessage(integration);
        }

        SQLException sql = find(throwable, SQLException.class);
        if (sql != null && isConnectionError(sql)) {
            return "Error de conexion general a MySQL: " + summarize(sql);
        }

        if (sql != null) {
            return summarize(sql);
        }

        return summarize(throwable);
    }

    private static String integrationMessage(ModuleIntegrationException exception) {
        String detail = summarize(exception);
        String logDetail = exception.logFailureDetail() == null
                ? ""
                : " Ademas, no se pudo registrar el log de sincronizacion: " + exception.logFailureDetail() + ".";
        if (exception.module() == ExternalModule.MODULO_B) {
            return "Error de integracion con Modulo B - Inventarios: " + detail
                    + ". Verifique que el esquema modulo_b este cargado y que existan las tablas productos, bodegas, movimientos_inventario y kardex."
                    + logDetail;
        }
        if (exception.module() == ExternalModule.MODULO_D && detail.startsWith("Advertencia de integracion")) {
            return detail + logDetail;
        }
        return "Error de integracion con Modulo D - Impuestos: " + detail
                + ". Verifique que el esquema modulo_d este cargado y que existan las tablas tarifas_iva, retenciones_iva_config, retenciones_renta_config, comprobantes_retencion y log_xml_comprobantes."
                + logDetail;
    }

    private static boolean isConnectionError(SQLException exception) {
        String state = exception.getSQLState();
        String className = exception.getClass().getName();
        String message = exception.getMessage();
        return (state != null && state.startsWith("08"))
                || className.contains("CommunicationsException")
                || (message != null && message.toLowerCase().contains("communications link failure"));
    }

    private static String summarize(Throwable throwable) {
        String message = throwable == null ? null : throwable.getMessage();
        if (message == null || message.isBlank()) {
            return "Error sin detalle devuelto por MySQL.";
        }
        String oneLine = message.replaceAll("\\s+", " ").trim();
        int maxLength = 320;
        return oneLine.length() <= maxLength ? oneLine : oneLine.substring(0, maxLength) + "...";
    }

    private static <T extends Throwable> T find(Throwable throwable, Class<T> type) {
        Throwable current = throwable;
        while (current != null) {
            if (type.isInstance(current)) {
                return type.cast(current);
            }
            current = current.getCause();
        }
        return null;
    }
}

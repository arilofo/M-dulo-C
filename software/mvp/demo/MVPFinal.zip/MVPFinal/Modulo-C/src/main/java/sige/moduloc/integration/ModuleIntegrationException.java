package sige.moduloc.integration;

import java.sql.SQLException;

public class ModuleIntegrationException extends SQLException {
    private final ExternalModule module;
    private final String logFailureDetail;

    public ModuleIntegrationException(ExternalModule module, SQLException cause) {
        this(module, cause, null);
    }

    public ModuleIntegrationException(ExternalModule module, SQLException cause, String logFailureDetail) {
        super(cause.getMessage(), cause.getSQLState(), cause.getErrorCode(), cause);
        this.module = module;
        this.logFailureDetail = logFailureDetail;
    }

    public ExternalModule module() {
        return module;
    }

    public String logFailureDetail() {
        return logFailureDetail;
    }

    public static ModuleIntegrationException moduloB(SQLException cause, String logFailureDetail) {
        return new ModuleIntegrationException(ExternalModule.MODULO_B, cause, logFailureDetail);
    }

    public static ModuleIntegrationException moduloD(SQLException cause, String logFailureDetail) {
        return new ModuleIntegrationException(ExternalModule.MODULO_D, cause, logFailureDetail);
    }
}

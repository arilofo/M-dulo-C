package sige.moduloc;

import sige.moduloc.config.AppConfig;
import sige.moduloc.config.Database;
import sige.moduloc.controller.CuentaController;
import sige.moduloc.controller.DemoController;
import sige.moduloc.controller.FacturaController;
import sige.moduloc.controller.HomeController;
import sige.moduloc.controller.IntegracionController;
import sige.moduloc.controller.OrdenController;
import sige.moduloc.controller.PagoController;
import sige.moduloc.controller.ProveedorController;
import sige.moduloc.controller.RecepcionController;
import sige.moduloc.controller.ReporteController;
import sige.moduloc.controller.RoleController;
import sige.moduloc.dao.ConnectionTestDao;
import sige.moduloc.dao.MvpDao;
import sige.moduloc.dao.ProveedorDao;
import sige.moduloc.http.Router;
import sige.moduloc.service.ConnectionTestService;
import sige.moduloc.service.MvpService;
import sige.moduloc.service.ProveedorService;

import java.io.IOException;
import java.net.InetSocketAddress;

import com.sun.net.httpserver.HttpServer;

public class Main {
    public static void main(String[] args) throws IOException {
        AppConfig config = AppConfig.load();
        Database database = new Database(config);
        ConnectionTestDao connectionTestDao = new ConnectionTestDao(database);
        ConnectionTestService connectionTestService = new ConnectionTestService(connectionTestDao);
        HomeController homeController = new HomeController(config, connectionTestService);
        ProveedorDao proveedorDao = new ProveedorDao(database);
        ProveedorService proveedorService = new ProveedorService(proveedorDao);
        ProveedorController proveedorController = new ProveedorController(proveedorService);
        MvpService mvpService = new MvpService(new MvpDao(database));
        OrdenController ordenController = new OrdenController(mvpService);
        RecepcionController recepcionController = new RecepcionController(mvpService);
        FacturaController facturaController = new FacturaController(mvpService);
        CuentaController cuentaController = new CuentaController(mvpService);
        PagoController pagoController = new PagoController(mvpService);
        ReporteController reporteController = new ReporteController(mvpService);
        IntegracionController integracionController = new IntegracionController(mvpService);
        DemoController demoController = new DemoController();
        RoleController roleController = new RoleController();

        InetSocketAddress address = new InetSocketAddress(config.serverHost(), config.serverPort());
        HttpServer server = HttpServer.create(address, 0);
        Router router = new Router(server);

        router.get("/", homeController::index);
        router.get("/rol", roleController::seleccionar);
        router.post("/rol", roleController::guardar);
        router.get("/db-test", homeController::databaseTest);
        router.get("/proveedores", proveedorController::listar);
        router.get("/proveedores/nuevo", proveedorController::nuevo);
        router.post("/proveedores/crear", proveedorController::crear);
        router.get("/proveedores/editar", proveedorController::editar);
        router.post("/proveedores/actualizar", proveedorController::actualizar);
        router.post("/proveedores/eliminar", proveedorController::eliminar);
        router.get("/ordenes", ordenController::listar);
        router.get("/ordenes/nueva", ordenController::nueva);
        router.post("/ordenes/crear", ordenController::crear);
        router.get("/ordenes/detalle", ordenController::detalle);
        router.get("/ordenes/pendientes", ordenController::pendientes);
        router.get("/recepciones", recepcionController::listar);
        router.get("/recepciones/nueva", recepcionController::nueva);
        router.post("/recepciones/crear", recepcionController::crear);
        router.get("/recepciones/pendientes-notificar", recepcionController::pendientesNotificar);
        router.post("/recepciones/marcar-notificada", recepcionController::marcarNotificada);
        router.get("/facturas", facturaController::listar);
        router.get("/facturas/nueva", facturaController::nueva);
        router.post("/facturas/crear", facturaController::crear);
        router.get("/facturas/pendientes-retencion", facturaController::pendientesRetencion);
        router.post("/facturas/marcar-retencion", facturaController::marcarRetencion);
        router.get("/cuentas", cuentaController::listar);
        router.get("/cuentas/pendientes", cuentaController::pendientes);
        router.get("/cuentas/estado-proveedor", cuentaController::estadoProveedor);
        router.post("/cuentas/programar-pago", cuentaController::programarPago);
        router.get("/pagos", pagoController::listar);
        router.get("/pagos/nuevo", pagoController::nuevo);
        router.post("/pagos/crear", pagoController::crear);
        router.get("/reportes", reporteController::index);
        router.get("/reportes/pagos-vencer", reporteController::pagosVencer);
        router.get("/reportes/obligaciones", reporteController::obligaciones);
        router.get("/reportes/ordenes-pendientes", reporteController::ordenesPendientes);
        router.get("/reportes/conciliacion", reporteController::conciliacion);
        router.get("/integraciones", integracionController::index);
        router.get("/integraciones/modulo-a-costos", integracionController::moduloACostos);
        router.post("/integraciones/modulo-a-costos/consultar", integracionController::consultarModuloACostos);
        router.get("/demo", demoController::index);
        router.staticFile("/static/styles.css", "static/styles.css", "text/css; charset=utf-8");

        server.setExecutor(null);
        server.start();

        System.out.println("Modulo C iniciado en http://" + config.serverHost() + ":" + config.serverPort());
    }
}

package sige.moduloc.config;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class AppConfig {
    private static final String CONFIG_FILE = "app.properties";

    private final Properties properties;

    private AppConfig(Properties properties) {
        this.properties = properties;
    }

    public static AppConfig load() {
        Properties properties = new Properties();
        try (InputStream input = AppConfig.class.getClassLoader().getResourceAsStream(CONFIG_FILE)) {
            if (input == null) {
                throw new IllegalStateException("No se encontro " + CONFIG_FILE + " en resources.");
            }
            properties.load(input);
        } catch (IOException ex) {
            throw new IllegalStateException("No se pudo cargar " + CONFIG_FILE + ".", ex);
        }
        return new AppConfig(properties);
    }

    public String serverHost() {
        return properties.getProperty("server.host", "localhost");
    }

    public int serverPort() {
        return Integer.parseInt(properties.getProperty("server.port", "8080"));
    }

    public String dbUrl() {
        return properties.getProperty("db.url");
    }

    public String dbUser() {
        return properties.getProperty("db.user");
    }

    public String dbPassword() {
        return properties.getProperty("db.password", "");
    }
}

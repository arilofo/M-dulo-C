package sige.moduloc.controller;

import com.sun.net.httpserver.HttpExchange;
import sige.moduloc.http.FormParser;
import sige.moduloc.http.HtmlResponse;
import sige.moduloc.http.PageRenderer;
import sige.moduloc.http.ViewUtil;
import sige.moduloc.security.AppRole;
import sige.moduloc.service.MvpService;

import java.io.IOException;
import java.time.LocalDate;

public class ReporteController extends WebControllerSupport {
    private final MvpService service;

    public ReporteController(MvpService service) {
        this.service = service;
    }

    public void index(HttpExchange exchange) throws IOException {
        HtmlResponse.ok(exchange, PageRenderer.layout("""
                <section class="section page-heading">
                    <div><h2>Reportes</h2><p>Consultas principales del MVP.</p></div>
                </section>
                <section class="section grid">
                    <a class="module" href="/reportes/pagos-vencer"><h2>Pagos por vencer</h2><p>Horizonte configurable.</p></a>
                    <a class="module" href="/reportes/obligaciones"><h2>Obligaciones pendientes</h2><p>Filtro por fechas.</p></a>
                    <a class="module" href="/reportes/ordenes-pendientes"><h2>Ordenes pendientes</h2><p>Recepcion incompleta.</p></a>
                    <a class="module" href="/reportes/conciliacion"><h2>Conciliacion</h2><p>Diferencia de saldos.</p></a>
                </section>
                """));
    }

    public void pagosVencer(HttpExchange exchange) throws IOException {
        try {
            requireRole(AppRole.ADMINISTRADOR, AppRole.TESORERO);
            var query = FormParser.parseQuery(exchange);
            String explain = "1".equals(query.get("explain"))
                    ? "<h3>EXPLAIN consulta optimizada</h3>" + ViewUtil.table(service.explainPagosPorVencer(query))
                    : "";
            HtmlResponse.ok(exchange, PageRenderer.layout("""
                    <section class="section page-heading"><div><h2>Pagos proximos a vencer</h2><p>Usa <code>sp_alertar_pagos_por_vencer</code>.</p></div><a class="button" href="/reportes">Volver</a></section>
                    <form class="form-panel" method="get" action="/reportes/pagos-vencer"><label>Dias horizonte<input name="dias" type="number" min="1" value="%s"></label><label><input name="explain" type="checkbox" value="1"> Mostrar EXPLAIN</label><div class="form-actions"><button class="button primary" type="submit">Consultar</button></div></form>
                    %s
                    %s
                    """.formatted(ViewUtil.e(query.getOrDefault("dias", "7")), ViewUtil.table(service.pagosPorVencer(query)), explain)));
        } catch (Exception ex) {
            renderError(exchange, "No se pudo cargar el reporte.", ex, "/reportes");
        }
    }

    public void obligaciones(HttpExchange exchange) throws IOException {
        try {
            requireRole(AppRole.ADMINISTRADOR, AppRole.TESORERO);
            var query = FormParser.parseQuery(exchange);
            String desde = query.getOrDefault("desde", LocalDate.now().minusYears(1).toString());
            String hasta = query.getOrDefault("hasta", LocalDate.now().plusYears(1).toString());
            HtmlResponse.ok(exchange, PageRenderer.layout("""
                    <section class="section page-heading"><div><h2>Obligaciones pendientes</h2><p>Usa <code>sp_reporte_obligaciones_pendientes</code>.</p></div><a class="button" href="/reportes">Volver</a></section>
                    <form class="form-panel" method="get" action="/reportes/obligaciones">
                        <div class="form-grid">
                            <label>Criterio<select name="criterio"><option value="vencimiento">Vencimiento</option><option value="proveedor">Proveedor</option><option value="estado">Estado</option></select></label>
                            <label>Desde<input name="desde" type="date" value="%s"></label>
                            <label>Hasta<input name="hasta" type="date" value="%s"></label>
                        </div>
                        <div class="form-actions"><button class="button primary" type="submit">Consultar</button></div>
                    </form>
                    %s
                    """.formatted(ViewUtil.e(desde), ViewUtil.e(hasta), ViewUtil.table(service.obligaciones(query)))));
        } catch (Exception ex) {
            renderError(exchange, "No se pudo cargar el reporte.", ex, "/reportes");
        }
    }

    public void ordenesPendientes(HttpExchange exchange) throws IOException {
        try {
            requireRole(AppRole.ADMINISTRADOR, AppRole.JEFE_COMPRAS);
            HtmlResponse.ok(exchange, PageRenderer.layout("""
                    <section class="section page-heading"><div><h2>Ordenes pendientes de recepcion</h2><p>Usa <code>sp_reporte_ordenes_pendientes_recepcion</code>.</p></div><a class="button" href="/reportes">Volver</a></section>
                    %s
                    """.formatted(ViewUtil.table(service.ordenesPendientes()))));
        } catch (Exception ex) {
            renderError(exchange, "No se pudo cargar el reporte.", ex, "/reportes");
        }
    }

    public void conciliacion(HttpExchange exchange) throws IOException {
        try {
            requireRole(AppRole.ADMINISTRADOR, AppRole.TESORERO);
            var query = FormParser.parseQuery(exchange);
            HtmlResponse.ok(exchange, PageRenderer.layout("""
                    <section class="section page-heading"><div><h2>Conciliacion de saldos</h2><p>Usa <code>sp_conciliar_saldos_proveedor</code>.</p></div><a class="button" href="/reportes">Volver</a></section>
                    <form class="form-panel" method="get" action="/reportes/conciliacion"><label>Proveedor opcional<select name="id_proveedor"><option value="">Todos</option>%s</select></label><div class="form-actions"><button class="button primary" type="submit">Consultar</button></div></form>
                    %s
                    """.formatted(ViewUtil.options(service.proveedoresActivos(), "id_proveedor", "razon_social", "identificacion"), ViewUtil.table(service.conciliacion(query)))));
        } catch (Exception ex) {
            renderError(exchange, "No se pudo cargar el reporte.", ex, "/reportes");
        }
    }
}

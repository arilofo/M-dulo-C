# 13 — Prompt inicial recomendado para Codex

Usa este prompt al abrir el repositorio con Codex.

```txt
Revisa este repositorio siguiendo primero los archivos de `documentacion-contexto/`.

Orden de lectura obligatorio:

1. documentacion-contexto/00_reglas_obligatorias_proyecto.md
2. documentacion-contexto/01_resumen_general.md
3. documentacion-contexto/02_alcance_mvp.md
4. documentacion-contexto/03_requerimientos_modulo_c.md
5. documentacion-contexto/04_flujos_principales.md
6. documentacion-contexto/05_integracion_modulos.md
7. documentacion-contexto/06_diccionario_datos.md
8. documentacion-contexto/07_reglas_negocio_validaciones.md
9. documentacion-contexto/08_procedimientos_vistas_bd.md
10. documentacion-contexto/11_notas_compatibilidad.md

No modifiques archivos todavía.

Quiero que hagas un diagnóstico inicial:

1. Qué entiende como alcance del MVP.
2. Qué tablas principales existen para el Módulo C.
3. Qué procedimientos almacenados se deben usar.
4. Qué dependencias existen con los módulos A, B y D.
5. Qué pantallas o endpoints mínimos debería tener el prototipo.
6. Qué riesgos técnicos detectas antes de empezar a programar.
7. Qué archivos del repo deberíamos revisar antes de tocar código.

Reglas:
- No inventes tablas, columnas ni procedimientos.
- No modifiques scripts SQL originales sin autorización.
- No implementes completos los módulos A, B o D.
- Respeta borrado lógico.
- Usa procedimientos almacenados para operaciones críticas.
- Si hay incompatibilidad de nombres entre módulos, indícala antes de proponer cambios.
```

## Prompt para generar arquitectura

```txt
Propón una arquitectura simple para implementar el prototipo del Módulo C.

Debe respetar:
- flujo orden → recepción → factura proveedor → cuenta por pagar → pago;
- uso de procedimientos almacenados existentes;
- borrado lógico;
- integración modular con A, B y D;
- roles Jefe de Compras, Tesorero y Administrador;
- reportes obligatorios.

No escribas código todavía. Primero propón estructura de carpetas, capas, endpoints o pantallas mínimas y flujo de datos.
```

## Prompt para crear esqueleto

```txt
Implementa solo el esqueleto inicial del proyecto.

Debe incluir:
- estructura de carpetas;
- conexión a MySQL con variables de entorno;
- archivo .env.example;
- rutas base;
- página o endpoint de salud;
- README con pasos para ejecutar.

No implementes todavía la lógica de negocio.
```

## Prompt para implementar por módulos

```txt
Implementa únicamente el flujo de [NOMBRE DEL FLUJO].

Usa los procedimientos almacenados existentes.
No cambies el schema.
No modifiques scripts externos.
Respeta borrado lógico.
Al final explica:
1. Archivos modificados.
2. Cómo probarlo.
3. Qué procedimiento SQL usa.
4. Qué validaciones quedan cubiertas.
```

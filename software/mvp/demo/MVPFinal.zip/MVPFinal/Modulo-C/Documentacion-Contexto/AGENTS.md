## Stack tecnológico obligatorio

El prototipo debe implementarse usando el siguiente stack:

- Lenguaje: Java.
- Tipo de aplicación: aplicación local ejecutada en una PC.
- Backend: Java con JDBC.
- Base de datos: MySQL 8.x.
- Frontend: vistas simples HTML.
- Servidor web: servidor HTTP local embebido en Java, no Tomcat.
- Gestor de dependencias: opcional. Se puede usar Maven si facilita la gestión del conector MySQL, pero no es obligatorio.

Codex no debe cambiar el stack tecnológico a Spring Boot, Node.js, Python, React u otro framework salvo que el usuario lo autorice explícitamente.

La arquitectura esperada es:

HTML simple → Controladores Java locales → Servicios → DAO/JDBC → MySQL

El programa debe ejecutarse localmente y exponer una interfaz web simple en localhost, por ejemplo:

http://localhost:8080

El acceso a la base de datos debe priorizar el uso de procedimientos almacenados existentes. No se debe modificar directamente tablas críticas si existe un procedimiento almacenado para la operación.
# 09 — Roles, seguridad y auditoría

Este archivo resume reglas de seguridad del Módulo C.

## Roles definidos

El script SQL define tres roles principales:

- `rol_jefe_compras`
- `rol_tesorero`
- `rol_admin_modulo_c`

## Rol: Jefe de Compras

Responsabilidad: ciclo operativo.

Puede gestionar:

- proveedores;
- órdenes de compra;
- recepciones;
- facturas de proveedor;
- órdenes pendientes;
- recepciones pendientes de notificación;
- facturas pendientes de retención.

Procedimientos permitidos:

- `sp_registrar_proveedor`
- `sp_actualizar_proveedor`
- `sp_eliminar_proveedor_logico`
- `sp_crear_orden_compra`
- `sp_registrar_recepcion`
- `sp_marcar_recepcion_notificada`
- `sp_ingresar_factura_proveedor`
- `sp_reporte_ordenes_pendientes_recepcion`

Vistas permitidas:

- `vw_ordenes_pendientes_recepcion`
- `vw_recepciones_pendientes_notificar`
- `vw_facturas_pendientes_retencion`
- `vw_proveedores_seguro`

Restricciones:

- No debe registrar pagos.
- No debe modificar saldos financieros.
- No debe programar pagos.
- No debe conciliar saldos financieros.

## Rol: Tesorero

Responsabilidad: ciclo financiero.

Puede gestionar:

- pagos;
- programación de pagos;
- estados de cuenta;
- reportes de obligaciones;
- alertas de vencimiento;
- conciliación;
- actualización de cuentas vencidas.

Procedimientos permitidos:

- `sp_registrar_pago`
- `sp_programar_pago`
- `sp_estado_cuenta_proveedor`
- `sp_reporte_obligaciones_pendientes`
- `sp_alertar_pagos_por_vencer`
- `sp_conciliar_saldos_proveedor`
- `sp_actualizar_cuentas_vencidas`

Vistas permitidas:

- `vw_cuentas_pendientes`
- `vw_pagos_por_vencer`
- `vw_estado_cuenta_proveedor`
- `cuentas_por_pagar`
- `pagos_proveedor`
- `vw_proveedores_seguro`

Restricciones:

- No debe crear órdenes.
- No debe registrar recepciones.
- No debe ingresar facturas proveedor.

## Rol: Administrador del sistema

Responsabilidad: acceso total y control excepcional.

Puede:

- ejecutar cualquier procedimiento;
- consultar auditoría;
- consultar logs de sincronización;
- autorizar facturas excepcionales sin orden de compra;
- revisar errores de integración.

Permisos:

- `ALL PRIVILEGES ON modulo_c.*`
- `SELECT ON BitacoraAuditoria`
- `SELECT ON LogSincronizacion`

## Usuarios de prueba

El script define usuarios referenciales:

- `jefe_compras_c`
- `tesorero_c`
- `admin_modulo_c`

Estos usuarios son útiles para pruebas, pero en el prototipo se puede simular rol con una selección simple si no se implementa autenticación real.

## Regla para el prototipo

No es obligatorio implementar autenticación compleja.

Opciones válidas para el MVP:

1. Selector de rol en pantalla.
2. Variables de sesión simples.
3. Rutas separadas por rol.
4. Usuario fijo para demo.

Lo importante es que el flujo respete la separación funcional:

```txt
Jefe de Compras → ciclo operativo
Tesorero → ciclo financiero
Administrador → autorización y revisión
```

## Auditoría

La tabla de auditoría es:

```sql
BitacoraAuditoria
```

Debe registrar operaciones sensibles:

- ingreso de facturas;
- generación de cuentas por pagar;
- registro de pagos;
- programación de pagos;
- actualización de retención;
- actualización de cuentas vencidas.

Campos principales:

- `tabla_afectada`
- `operacion`
- `id_registro`
- `usuario`
- `valor_anterior`
- `valor_nuevo`
- `fecha_evento`

## Log de sincronización

La tabla de sincronización es:

```sql
LogSincronizacion
```

Estados:

- `pendiente`
- `exitoso`
- `fallido`

Usos:

- IF-02 con Módulo B.
- IF-03 con Módulo B.
- IF-05/IF-06 con Módulo D.

## Enmascaramiento

La vista segura es:

```sql
vw_proveedores_seguro
```

Debe usarse cuando el usuario no necesite ver datos completos de identificación o cuenta bancaria.

Muestra:

- identificación enmascarada;
- cuenta bancaria enmascarada.

## Prevención de inyección SQL

El prototipo debe usar:

- consultas parametrizadas;
- procedimientos almacenados;
- no concatenar SQL con entradas del usuario.

## Backups

Los comandos de respaldo están documentados en el script SQL. No se ejecutan dentro de MySQL Workbench como sentencias SQL.

Tipos:

- respaldo completo;
- respaldo solo estructura;
- respaldo solo datos;
- restauración completa;
- restauración de datos.

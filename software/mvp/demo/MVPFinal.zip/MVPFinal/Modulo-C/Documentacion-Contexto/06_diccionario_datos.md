# 06 — Diccionario de datos del Módulo C

Este archivo resume las tablas, vistas y campos principales del Módulo C para que Codex no tenga que interpretar todo el script SQL completo en cada tarea.

## Tablas propias del Módulo C

### Proveedor

Propósito: tabla raíz de proveedores.

Campos principales:

- `id_proveedor`
- `tipo_proveedor`: `persona_natural` o `persona_juridica`
- `identificacion`: RUC/cédula o identificación del proveedor
- `razon_social`
- `email`
- `telefono`
- `direccion`
- `dias_credito`
- `cuenta_bancaria`
- `banco`
- `calificacion`: `A`, `B`, `C`
- `activo`
- `fecha_creacion`
- `usuario_creacion`
- `fecha_eliminacion`
- `eliminado_por`

Notas:

- `identificacion` es única.
- Usar `activo = 1` para consultas normales.
- Borrado lógico, no `DELETE`.

### ProveedorPersonaNatural

Propósito: subtipo de proveedor persona natural.

Campos:

- `id_proveedor`
- `cedula`

Relación:

- `id_proveedor` referencia `Proveedor.id_proveedor`.

### ProveedorPersonaJuridica

Propósito: subtipo de proveedor persona jurídica.

Campos:

- `id_proveedor`
- `razon_social`
- `nombre_comercial`

Relación:

- `id_proveedor` referencia `Proveedor.id_proveedor`.

### OrdenCompra

Propósito: cabecera de la orden de compra.

Campos principales:

- `id_oc`
- `numero_oc`
- `id_proveedor`
- `ref_mod_b_id_solicitud`
- `fecha_emision`
- `fecha_entrega_esperada`
- `estado`
- `total_estimado`
- `observaciones`
- `activo`
- `fecha_creacion`
- `usuario_creacion`
- `fecha_modificacion`
- `usuario_modificacion`
- `fecha_eliminacion`
- `eliminado_por`

Estados:

- `borrador`
- `emitida`
- `recibida_parcial`
- `recibida_total`
- `anulada`

Relaciones:

- Pertenece a un `Proveedor`.
- Tiene muchos `DetalleOrdenCompra`.
- Puede tener muchas `Recepcion`.
- Puede asociarse a `FacturaProveedor`.

### DetalleOrdenCompra

Propósito: detalle de productos solicitados en una orden.

Campos principales:

- `id_detalle_oc`
- `id_oc`
- `ref_mod_b_id_producto`
- `codigo_producto_al_momento`
- `descripcion_al_momento`
- `unidad_medida_al_momento`
- `cantidad_solicitada`
- `precio_unitario_pactado`
- `subtotal`
- `activo`
- `fecha_creacion`
- `usuario_creacion`
- `fecha_eliminacion`
- `eliminado_por`

Notas:

- `ref_mod_b_id_producto` referencia lógicamente al producto del Módulo B.
- Los campos `*_al_momento` conservan snapshot del producto para trazabilidad histórica.
- El precio pactado sirve para la consulta de costo al Módulo A.

### Recepcion

Propósito: cabecera del ingreso físico de mercadería.

Campos principales:

- `id_recepcion`
- `id_oc`
- `fecha_recepcion`
- `tipo_recepcion`: `completa` o `parcial`
- `notificado_inventario`
- `fecha_notificacion_inventario`
- `usuario_notificacion`
- `observaciones`
- `activo`
- `fecha_creacion`
- `usuario_creacion`
- `fecha_eliminacion`
- `eliminado_por`

Relaciones:

- Pertenece a una `OrdenCompra`.
- Tiene muchos `DetalleRecepcion`.

Notas:

- `notificado_inventario = 0` indica pendiente de integración con Módulo B.
- `notificado_inventario = 1` indica que la recepción ya fue procesada por inventario.

### DetalleRecepcion

Propósito: detalle de productos efectivamente recibidos.

Campos principales:

- `id_detalle_rec`
- `id_recepcion`
- `id_detalle_oc`
- `ref_mod_b_id_producto`
- `cantidad_recibida`
- `activo`
- `fecha_creacion`
- `usuario_creacion`
- `fecha_eliminacion`
- `eliminado_por`

Relaciones:

- Pertenece a `Recepcion`.
- Se vincula con `DetalleOrdenCompra`.

Regla:

- `cantidad_recibida` no puede superar cantidad pendiente del detalle de orden.

### FacturaProveedor

Propósito: factura emitida por proveedor.

Campos principales:

- `id_factura_prov`
- `numero_factura_proveedor`
- `numero_serie`
- `id_proveedor`
- `id_oc`
- `id_recepcion`
- `fecha_emision`
- `base_imponible`
- `monto_iva`
- `total`
- `codigo_sustento`
- `tipo_bien_servicio`
- `ref_mod_d_tarifa_id`
- `estado`
- `ref_mod_d_doc_id`
- `num_autorizacion_retencion`
- `xml_retencion`
- `factura_excepcional`
- `motivo_excepcion`
- `usuario_autorizador`
- `fecha_autorizacion`
- `activo`
- `fecha_creacion`
- `usuario_creacion`
- `fecha_modificacion`
- `usuario_modificacion`
- `fecha_eliminacion`
- `eliminado_por`

Estados tributarios:

- `pendiente_retencion`
- `retencion_generada`
- `anulada`

Reglas:

- Factura regular requiere `id_oc` e `id_recepcion`.
- Factura excepcional exige motivo y usuario autorizador.
- Una factura válida genera una `CuentaPorPagar`.

### CuentaPorPagar

Propósito: obligación financiera derivada de factura proveedor.

Campos principales:

- `id_cxp`
- `id_proveedor`
- `id_factura_prov`
- `monto_original`
- `saldo_pendiente`
- `fecha_vencimiento`
- `fecha_programada`
- `estado`
- `fecha_cancelacion`
- `activo`
- `fecha_creacion`
- `usuario_creacion`
- `fecha_modificacion`
- `usuario_modificacion`
- `fecha_eliminacion`
- `eliminado_por`

Estados:

- `pendiente`
- `pagada_parcial`
- `pagada`
- `vencida`

Reglas:

- `id_factura_prov` es único.
- Una factura genera una sola cuenta por pagar.
- El saldo se actualiza por pagos.
- No usar actualización manual si existe `sp_registrar_pago`.

Índices relevantes:

- `idx_cxp_vencimiento`
- `idx_cxp_programada`
- `idx_cxp_alertas`
- `idx_cxp_proveedor_estado`

### PagoProveedor

Propósito: pago realizado a una cuenta por pagar.

Campos principales:

- `id_pago`
- `id_cxp`
- `id_proveedor`
- `fecha_pago`
- `monto`
- `forma_pago`
- `referencia`
- `activo`
- `fecha_creacion`
- `usuario_creacion`
- `fecha_eliminacion`
- `eliminado_por`

Formas de pago:

- `transferencia`
- `cheque`
- `efectivo`

Reglas:

- `monto > 0`.
- No puede superar el saldo pendiente.
- Se registra mediante `sp_registrar_pago`.

### LogSincronizacion

Propósito: registrar eventos de integración entre módulos.

Campos principales:

- `id_log`
- `modulo_destino`
- `interfaz`
- `id_referencia`
- `estado`
- `mensaje_error`
- `fecha_registro`

Estados:

- `pendiente`
- `exitoso`
- `fallido`

Usos:

- IF-02: solicitud desde Módulo B.
- IF-03: recepción pendiente de notificar a inventario.
- IF-05/IF-06: errores con Módulo D.

### BitacoraAuditoria

Propósito: auditoría de operaciones sensibles.

Campos principales:

- `id_auditoria`
- `tabla_afectada`
- `operacion`
- `id_registro`
- `usuario`
- `valor_anterior`
- `valor_nuevo`
- `fecha_evento`

Usos:

- ingreso de factura;
- generación de cuenta por pagar;
- registro de pago;
- programación de pago;
- actualización de retención;
- actualización de cuentas vencidas.

## Funciones

### fn_calcular_fecha_vencimiento

Calcula fecha de vencimiento usando `fecha_emision` y `dias_credito` del proveedor.

### fn_saldo_proveedor

Calcula saldo pendiente total de un proveedor.

### fn_dias_vencimiento

Devuelve diferencia entre `fecha_vencimiento` y fecha actual.

### fn_porcentaje_recepcion_oc

Calcula porcentaje recibido de una orden de compra.

## Vistas principales

### vw_cuentas_pendientes

Consulta cuentas por pagar activas con saldo pendiente.

### vw_pagos_por_vencer

Consulta pagos próximos a vencer en horizonte fijo de 7 días.

### vw_estado_cuenta_proveedor

Consulta facturas, pagos y saldos por proveedor.

### vw_ordenes_pendientes_recepcion

Consulta órdenes en estado `emitida` o `recibida_parcial`.

### vw_recepciones_pendientes_notificar

Consulta recepciones no notificadas a Módulo B.

### vw_facturas_pendientes_retencion

Payload para Módulo D con facturas en estado `pendiente_retencion`.

### vw_proveedores_seguro

Vista segura con identificación y cuenta bancaria enmascaradas.

## Vistas de compatibilidad snake_case

El script crea vistas de compatibilidad para contratos o convenciones externas:

- `proveedores`
- `ordenes_compra`
- `detalle_orden_compra`
- `recepciones`
- `detalle_recepcion`
- `facturas_proveedor`
- `cuentas_por_pagar`
- `pagos_proveedor`

Codex puede usarlas para lectura si conviene, pero para escritura debe preferir procedimientos almacenados.

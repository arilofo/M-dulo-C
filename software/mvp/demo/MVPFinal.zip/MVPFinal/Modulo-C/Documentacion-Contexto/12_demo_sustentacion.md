# 12 — Demo de sustentación del prototipo

Este archivo propone una demostración ordenada del MVP para defender el Módulo C.

## Objetivo de la demo

Mostrar en vivo el flujo completo:

```txt
Proveedor → Orden de compra → Recepción → Factura proveedor → Cuenta por pagar → Pago → Reportes
```

Además, demostrar:

- integración con Módulo B;
- integración con Módulo D;
- reportes financieros;
- control de órdenes pendientes;
- borrado lógico;
- auditoría y log de sincronización.

## Preparación previa

Antes de la demo:

1. Crear base de datos.
2. Ejecutar script del Módulo C.
3. Cargar datos de prueba.
4. Tener productos de prueba del Módulo B o mock compatible.
5. Confirmar que existen proveedores activos.
6. Confirmar que existen órdenes o que se puede crear una nueva.
7. Tener a mano IDs de prueba.

## Flujo principal sugerido

### Paso 1 — Mostrar proveedores

Objetivo: evidenciar RF01.

Acción:

- Abrir pantalla o endpoint de proveedores.
- Mostrar lista de proveedores activos.
- Opcional: registrar un proveedor nuevo.

Procedimiento:

```sql
CALL sp_registrar_proveedor(...);
```

### Paso 2 — Crear orden de compra

Objetivo: evidenciar RF02, RF14 y RF15.

Acción:

- Seleccionar proveedor.
- Seleccionar productos.
- Ingresar cantidad y precio.
- Crear orden.

Procedimiento:

```sql
CALL sp_crear_orden_compra(...);
```

Resultado esperado:

- Orden en estado `emitida`.
- Detalles registrados.
- Total calculado.

### Paso 3 — Registrar recepción

Objetivo: evidenciar RF03, RF04 y RF13.

Acción:

- Seleccionar orden emitida.
- Registrar cantidad recibida.
- Confirmar recepción.

Procedimiento:

```sql
CALL sp_registrar_recepcion(...);
```

Resultado esperado:

- Se crea `Recepcion`.
- Se crea `DetalleRecepcion`.
- Orden cambia a `recibida_parcial` o `recibida_total`.
- Se registra evento IF-03 en `LogSincronizacion`.

### Paso 4 — Simular actualización de inventario

Objetivo: evidenciar integración con Módulo B.

Acción:

- Consultar recepciones pendientes.
- Simular o ejecutar movimiento de inventario en Módulo B.
- Marcar recepción como notificada.

Consultas / procedimientos:

```sql
SELECT * FROM vw_recepciones_pendientes_notificar;

CALL sp_marcar_recepcion_notificada(id_recepcion, 'integracion_modb');
```

Resultado esperado:

- `notificado_inventario = 1`.

### Paso 5 — Registrar factura proveedor

Objetivo: evidenciar RF05, RF06 y RF17.

Acción:

- Seleccionar proveedor.
- Seleccionar orden y recepción.
- Ingresar factura.
- Confirmar.

Procedimiento:

```sql
CALL sp_ingresar_factura_proveedor(...);
```

Resultado esperado:

- Factura en estado `pendiente_retencion`.
- Cuenta por pagar generada automáticamente.
- Auditoría registrada.

### Paso 6 — Simular retención con Módulo D

Objetivo: evidenciar IF-05 / IF-06.

Acción:

- Consultar facturas pendientes de retención.
- Simular respuesta del Módulo D.
- Actualizar factura con XML y autorización.

Consultas / procedimientos:

```sql
SELECT * FROM vw_facturas_pendientes_retencion;

CALL sp_actualizar_retencion_desde_modd(
  id_factura,
  '<xml>retencion</xml>',
  '1234567890123456789012345678901234567890123456789'
);
```

Resultado esperado:

- Factura cambia a `retencion_generada`.

### Paso 7 — Programar pago

Objetivo: evidenciar programación de pagos.

Procedimiento:

```sql
CALL sp_programar_pago(id_cxp, DATE_ADD(CURDATE(), INTERVAL 3 DAY), 'tesorero_demo');
```

Resultado esperado:

- `fecha_programada` actualizada.
- Auditoría registrada.

### Paso 8 — Registrar pago

Objetivo: evidenciar RF07 y RF08.

Acción:

- Seleccionar cuenta por pagar.
- Registrar pago parcial o total.

Procedimiento:

```sql
CALL sp_registrar_pago(
  id_cxp,
  monto,
  'transferencia',
  'TRX-DEMO-001',
  'tesorero_demo'
);
```

Resultado esperado:

- Pago registrado.
- Saldo pendiente actualizado.
- Estado actualizado:
  - `pagada_parcial`; o
  - `pagada`.
- Auditoría registrada.

### Paso 9 — Reportes

Objetivo: evidenciar RF09, RF10, RF11 y RF12.

Ejecutar:

```sql
CALL sp_estado_cuenta_proveedor(id_proveedor, '2025-01-01', '2026-12-31');

CALL sp_alertar_pagos_por_vencer(7);

CALL sp_reporte_ordenes_pendientes_recepcion(NULL);

CALL sp_reporte_obligaciones_pendientes('vencimiento', '2025-01-01', '2026-12-31');

CALL sp_conciliar_saldos_proveedor(NULL);
```

## Pruebas de error recomendadas

### Prueba 1 — Pago superior al saldo

Objetivo: demostrar validación financiera.

```sql
CALL sp_registrar_pago(
  1,
  999999.00,
  'transferencia',
  'TRX-ERROR-001',
  'tesorero_prueba'
);
```

Resultado esperado:

```txt
El monto a pagar supera el saldo pendiente de la cuenta.
```

### Prueba 2 — Factura superior al monto pendiente

Objetivo: demostrar control de facturación contra orden.

Resultado esperado:

```txt
El monto de la factura supera el valor pendiente de facturación de la orden de compra.
```

### Prueba 3 — Recepción superior a cantidad pendiente

Objetivo: demostrar control de recepción.

Resultado esperado:

```txt
La cantidad recibida supera la cantidad pendiente de recepción.
```

### Prueba 4 — Marcar recepción ya notificada

Objetivo: demostrar protección contra reproceso.

Resultado esperado:

```txt
La recepción no existe, está inactiva o ya fue notificada al inventario.
```

## Orden de explicación oral

1. El Módulo C gestiona compras y cuentas por pagar.
2. El flujo principal es orden → recepción → factura → pago.
3. Las entidades principales están separadas para mantener trazabilidad.
4. El inventario se actualiza mediante integración con Módulo B.
5. Las retenciones se gestionan mediante integración con Módulo D.
6. Los saldos se actualizan por procedimientos almacenados.
7. Los reportes usan vistas y consultas optimizadas.
8. La seguridad se separa por roles.
9. El borrado es lógico.
10. Auditoría y log permiten trazabilidad y control de errores.

## Checklist antes de presentar

- [ ] Base de datos creada.
- [ ] Script del Módulo C ejecutado.
- [ ] Datos de prueba cargados.
- [ ] Procedimientos probados.
- [ ] Demo ensayada.
- [ ] Tener IDs de proveedor, orden, recepción, factura y CxP.
- [ ] Tener respaldo de capturas o consultas si falla la interfaz.
- [ ] Tener claro qué parte es real y qué parte es simulada por integración.

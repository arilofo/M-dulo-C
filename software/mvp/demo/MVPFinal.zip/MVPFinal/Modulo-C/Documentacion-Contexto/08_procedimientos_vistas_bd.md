# 08 — Procedimientos, funciones y vistas de base de datos

Este archivo resume qué objetos SQL existen y cómo deben usarse desde el prototipo.

## Regla principal para Codex

Si existe un procedimiento almacenado para una operación, usarlo. No escribir `INSERT`, `UPDATE` o `DELETE` directo sobre tablas críticas salvo para consultas de lectura o pruebas controladas.

## Funciones

| Función | Propósito |
|---|---|
| `fn_calcular_fecha_vencimiento` | Calcula vencimiento de una factura según días de crédito del proveedor. |
| `fn_saldo_proveedor` | Calcula saldo total pendiente de un proveedor. |
| `fn_dias_vencimiento` | Calcula días entre vencimiento y fecha actual. |
| `fn_porcentaje_recepcion_oc` | Calcula porcentaje recibido de una orden de compra. |

## Procedimientos de proveedores

### sp_registrar_proveedor

Cubre RF01 / CU-01.

Uso:

- registra proveedor;
- registra subtipo persona natural o jurídica;
- valida identificación única;
- usa transacción.

### sp_actualizar_proveedor

Actualiza datos generales del proveedor activo.

### sp_eliminar_proveedor_logico

Desactiva proveedor mediante borrado lógico.

No permite eliminar si existen cuentas por pagar con saldo pendiente.

## Procedimientos de órdenes

### sp_crear_orden_compra

Cubre RF02 / RF15 / CU-02.

Responsabilidades:

- validar proveedor activo;
- validar JSON de ítems;
- generar número de orden;
- insertar cabecera;
- insertar detalles;
- calcular total;
- encolar IF-02 si viene de solicitud del Módulo B.

JSON esperado:

```json
[
  {
    "id_producto": 1,
    "codigo_producto": "PROD-001",
    "descripcion": "Producto prueba",
    "unidad_medida": "unidad",
    "cantidad": 10,
    "precio_costo": 25.00
  }
]
```

### sp_eliminar_orden_logico

Realiza borrado lógico en cascada:

```txt
OrdenCompra → DetalleOrdenCompra → Recepcion → DetalleRecepcion
```

### sp_reporte_ordenes_pendientes_recepcion

Consulta órdenes activas en estado `emitida` o `recibida_parcial`.

Permite filtro opcional por proveedor.

## Procedimientos de recepción

### sp_registrar_recepcion

Cubre RF03 / RF04 / RF13 / CU-03 / CU-04.

Responsabilidades:

- validar orden activa y estado permitido;
- insertar recepción;
- insertar detalle;
- validar cantidad pendiente;
- actualizar estado de orden;
- encolar IF-03 hacia Módulo B.

JSON esperado:

```json
[
  {
    "id_detalle_oc": 1,
    "cantidad_recibida": 10
  }
]
```

### sp_marcar_recepcion_notificada

Marca una recepción como ya procesada por Módulo B.

Actualiza:

- `notificado_inventario = 1`
- `fecha_notificacion_inventario`
- `usuario_notificacion`

### sp_reintentar_notificaciones_modb

Devuelve recepciones pendientes para reintento de integración con Módulo B.

### sp_registrar_error_sincronizacion

Registra fallos de comunicación en `LogSincronizacion`.

## Procedimientos de facturas

### sp_ingresar_factura_proveedor

Cubre RF05 / RF17 / CU-05 / CU-17.

Responsabilidades:

- validar factura regular o excepcional;
- validar coherencia proveedor-orden-recepción;
- validar monto pendiente de facturación;
- insertar factura;
- registrar auditoría;
- llamar `sp_generar_cuenta_por_pagar`.

### sp_actualizar_retencion_desde_modd

Cubre respuesta de Módulo D.

Actualiza:

- XML de retención;
- número de autorización;
- estado `retencion_generada`.

## Procedimientos de cuentas por pagar

### sp_generar_cuenta_por_pagar

Cubre RF06 / CU-06.

Responsabilidades:

- validar que factura existe;
- validar que no esté anulada;
- validar que no tenga CxP duplicada;
- calcular vencimiento;
- insertar `CuentaPorPagar`;
- registrar auditoría.

### sp_programar_pago

Permite programar fecha de pago.

Responsabilidades:

- validar fecha obligatoria;
- validar fecha no anterior a hoy;
- validar cuenta activa, con saldo y estado operable;
- actualizar `fecha_programada`;
- registrar auditoría.

### sp_actualizar_cuentas_vencidas

Marca cuentas vencidas de forma batch.

Debe ejecutarse periódicamente desde la aplicación.

## Procedimientos de pagos

### sp_registrar_pago

Cubre RF07 / RF08 / CU-07 / CU-08.

Responsabilidades:

- validar monto;
- bloquear cuenta con `FOR UPDATE`;
- evitar sobrepago;
- insertar `PagoProveedor`;
- actualizar saldo y estado de CxP;
- registrar auditoría.

## Procedimientos de reportes

### sp_reporte_obligaciones_pendientes

Cubre RF12 / CU-12.

Parámetros:

- criterio: `proveedor`, `vencimiento`, `estado`;
- fecha desde;
- fecha hasta.

### sp_estado_cuenta_proveedor

Cubre RF09 / CU-09.

Devuelve estado de cuenta por proveedor y período.

### sp_alertar_pagos_por_vencer

Cubre RF10 / CU-10.

Parámetro:

- `p_dias`

Si `p_dias` es nulo o inválido, usa 7 días.

### sp_conciliar_saldos_proveedor

Cubre conciliación de saldos.

Devuelve:

- monto original;
- total pagado;
- saldo registrado;
- diferencia;
- estado.

### sp_ejecutar_flujo_completo_compra

Orquesta flujo completo:

```txt
orden → recepción → factura → pago
```

Uso recomendado:

- pruebas de integración;
- demostración controlada;
- documentación ejecutable.

Debe usarse con cuidado porque requiere JSON de orden y recepción consistentes.

## Procedimientos de consulta para Módulo A

### sp_consultar_precio_costo_producto

Expone último costo de adquisición de un producto.

### sp_consultar_ultimo_costo_adquisicion

Expone historial limitado de costos de adquisición.

Si no hay datos, devuelven `SIN_COSTO_REGISTRADO`.

## Vistas de reportes

| Vista | Uso |
|---|---|
| `vw_cuentas_pendientes` | Cuentas activas no pagadas. |
| `vw_pagos_por_vencer` | Pagos próximos a vencer en 7 días. |
| `vw_estado_cuenta_proveedor` | Estado de cuenta por proveedor. |
| `vw_ordenes_pendientes_recepcion` | Órdenes pendientes o parciales. |
| `vw_recepciones_pendientes_notificar` | Recepciones pendientes de notificar a inventario. |
| `vw_facturas_pendientes_retencion` | Facturas pendientes de retención para Módulo D. |
| `vw_proveedores_seguro` | Vista segura con datos sensibles enmascarados. |

## Vistas de compatibilidad

| Vista | Tabla base |
|---|---|
| `proveedores` | `Proveedor` |
| `ordenes_compra` | `OrdenCompra` |
| `detalle_orden_compra` | `DetalleOrdenCompra` |
| `recepciones` | `Recepcion` |
| `detalle_recepcion` | `DetalleRecepcion` |
| `facturas_proveedor` | `FacturaProveedor` |
| `cuentas_por_pagar` | `CuentaPorPagar` |
| `pagos_proveedor` | `PagoProveedor` |

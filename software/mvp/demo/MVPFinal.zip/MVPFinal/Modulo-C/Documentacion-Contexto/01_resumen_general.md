# 01 — Resumen general del proyecto

## Sistema

El proyecto pertenece al **Sistema Integrado de Gestión Empresarial (SIGE)**, organizado en cuatro módulos:

- Módulo A: Facturación y Cuentas por Cobrar.
- Módulo B: Control de Inventarios.
- Módulo C: Cuentas por Pagar.
- Módulo D: Gestión de Impuestos.

Este repositorio se enfoca en el **Módulo C — Cuentas por Pagar**.

## Propósito del Módulo C

El Módulo C administra el ciclo de compras y obligaciones financieras de la empresa con sus proveedores. Su responsabilidad inicia con la emisión o creación de una orden de compra y termina con el pago y conciliación del saldo pendiente.

Flujo general:

```txt
Solicitud de compra → Orden de compra → Recepción de mercadería → Factura de proveedor → Cuenta por pagar → Pago → Conciliación de saldo
```

## Funciones principales

El módulo debe permitir:

- Registrar y mantener proveedores.
- Crear órdenes de compra manuales o desde solicitudes del Módulo B.
- Registrar detalles de órdenes de compra.
- Registrar recepciones de mercadería, completas o parciales.
- Notificar al Módulo B la entrada de productos al inventario.
- Ingresar facturas emitidas por proveedores.
- Consultar o aplicar información tributaria proveniente del Módulo D.
- Generar cuentas por pagar desde facturas válidas.
- Programar pagos.
- Registrar pagos parciales o totales.
- Actualizar saldos pendientes.
- Generar estados de cuenta por proveedor.
- Reportar pagos próximos a vencer.
- Reportar obligaciones pendientes.
- Conciliar saldos.

## Entidades de dominio principales

Desde la visión de software y base de datos, las entidades principales son:

- `Proveedor`
- `ProveedorPersonaNatural`
- `ProveedorPersonaJuridica`
- `OrdenCompra`
- `DetalleOrdenCompra`
- `Recepcion`
- `DetalleRecepcion`
- `FacturaProveedor`
- `CuentaPorPagar`
- `PagoProveedor`
- `LogSincronizacion`
- `BitacoraAuditoria`

## Integración con otros módulos

### Módulo B — Inventarios

El Módulo C se integra con Inventarios para:

- Consultar catálogo de productos.
- Recibir solicitudes de compra por stock mínimo.
- Notificar recepciones para actualizar inventario.

### Módulo D — Impuestos

El Módulo C se integra con Impuestos para:

- Consultar tarifa de IVA y retenciones.
- Enviar facturas de proveedor.
- Recibir XML y número de autorización de retención.

### Módulo A — Facturación y Cuentas por Cobrar

La integración con Módulo A es indirecta:

- Módulo C expone precios de costo de adquisición.
- Módulo A puede consultar esos costos para análisis de márgenes o precios de venta.

## Arquitectura conceptual

El diseño de software usa una organización por capas:

- Capa de presentación.
- Capa de lógica de negocio.
- Capa de datos / dominio.

Además, la integración entre módulos debe hacerse mediante contratos e interfaces, evitando acceso directo e innecesario a las estructuras internas de otros módulos.

## Patrón de diseño relevante

El patrón **Observer** se aplica en dos flujos:

1. Recepción de mercadería:
   - `Recepcion` como sujeto.
   - Observadores: `NotificadorInventarioB`, `ActualizadorEstadoOrdenCompra`.

2. Registro de factura proveedor:
   - `FacturaProveedor` como sujeto.
   - Observadores: `EnviadorRetencionModuloD`, `GeneradorCuentaPorPagarAutomatica`.

En la implementación SQL, estas reacciones se representan principalmente mediante procedimientos almacenados y registros de sincronización.

# 10 — Consultas y reportes

Este archivo resume los reportes principales que el prototipo debe exponer.

## Reporte 1 — Pagos próximos a vencer

### Objetivo

Mostrar cuentas por pagar activas que vencen dentro de un horizonte configurable.

### Procedimiento principal

```sql
CALL sp_alertar_pagos_por_vencer(p_dias);
```

### Vista relacionada

```sql
vw_pagos_por_vencer
```

### Campos esperados

- `id_cxp`
- `razon_social`
- `identificacion`
- `numero_factura_proveedor`
- `saldo_pendiente`
- `fecha_vencimiento`
- `fecha_programada`
- `dias_para_vencer`

### Filtros esperados

```sql
c.activo = 1
AND c.estado IN ('pendiente','pagada_parcial')
AND c.saldo_pendiente > 0
AND c.fecha_vencimiento BETWEEN CURDATE()
    AND DATE_ADD(CURDATE(), INTERVAL p_dias DAY)
```

### Índice relevante

```sql
idx_cxp_alertas (activo, estado, fecha_vencimiento, saldo_pendiente)
```

### EXPLAIN de referencia

Para documentar optimización:

```sql
EXPLAIN
SELECT
    c.id_cxp,
    p.razon_social,
    p.identificacion,
    f.numero_factura_proveedor,
    c.saldo_pendiente,
    c.fecha_vencimiento,
    c.fecha_programada,
    fn_dias_vencimiento(c.fecha_vencimiento) AS dias_para_vencer
FROM CuentaPorPagar c
JOIN Proveedor p
    ON p.id_proveedor = c.id_proveedor
JOIN FacturaProveedor f
    ON f.id_factura_prov = c.id_factura_prov
WHERE c.activo = 1
  AND c.estado IN ('pendiente','pagada_parcial')
  AND c.saldo_pendiente > 0
  AND c.fecha_vencimiento BETWEEN CURDATE()
      AND DATE_ADD(CURDATE(), INTERVAL 7 DAY)
ORDER BY c.fecha_vencimiento ASC;
```

Codex debe evitar filtrar usando funciones sobre la columna en el `WHERE`, por ejemplo:

```sql
WHERE fn_dias_vencimiento(c.fecha_vencimiento) BETWEEN 0 AND 7
```

Esa forma dificulta el uso del índice.

## Reporte 2 — Órdenes pendientes de recepción

### Objetivo

Mostrar órdenes con recepción incompleta o sin recepción.

### Procedimiento

```sql
CALL sp_reporte_ordenes_pendientes_recepcion(NULL);
```

También puede filtrarse por proveedor:

```sql
CALL sp_reporte_ordenes_pendientes_recepcion(1);
```

### Vista relacionada

```sql
vw_ordenes_pendientes_recepcion
```

### Campos esperados

- `id_oc`
- `numero_oc`
- `razon_social`
- `identificacion`
- `fecha_emision`
- `fecha_entrega_esperada`
- `estado`
- `porcentaje_recibido`
- `dias_desde_emision`
- `total_estimado`

### Estados filtrados

```sql
estado IN ('emitida', 'recibida_parcial')
```

### Índices útiles

- `idx_oc_estado`
- `idx_oc_fecha_emision`
- `idx_oc_proveedor`

Opcional si se necesita optimizar más:

```sql
CREATE INDEX idx_oc_activo_estado_fecha
ON OrdenCompra (activo, estado, fecha_emision);
```

## Reporte 3 — Obligaciones pendientes

### Objetivo

Generar reporte financiero de cuentas por pagar no pagadas en un rango de fechas.

### Procedimiento

```sql
CALL sp_reporte_obligaciones_pendientes('vencimiento', '2025-01-01', '2025-12-31');
```

Criterios aceptados:

- `proveedor`
- `vencimiento`
- `estado`

### Vista relacionada

```sql
vw_cuentas_pendientes
```

### Campos esperados

- `razon_social`
- `identificacion`
- `numero_factura_proveedor`
- `numero_serie`
- `monto_original`
- `saldo_pendiente`
- `fecha_vencimiento`
- `fecha_programada`
- `estado`
- `dias_para_vencer`

### Índices relevantes

- `idx_cxp_vencimiento`
- `idx_cxp_alertas`
- `idx_cxp_proveedor_estado`

### Optimización recomendada

Si el volumen crece, usar o crear índice compuesto por:

```sql
(activo, fecha_vencimiento, estado)
```

## Reporte 4 — Estado de cuenta por proveedor

### Objetivo

Mostrar historial financiero de un proveedor.

### Procedimiento

```sql
CALL sp_estado_cuenta_proveedor(p_id_proveedor, p_desde, p_hasta);
```

### Vista relacionada

```sql
vw_estado_cuenta_proveedor
```

### Campos esperados

- proveedor;
- identificación;
- factura;
- fecha emisión;
- monto factura;
- vencimiento;
- fecha programada;
- saldo pendiente;
- estado;
- pagos asociados;
- forma de pago.

## Reporte 5 — Conciliación de saldos

### Objetivo

Verificar que el saldo registrado coincida con pagos reales.

### Procedimiento

```sql
CALL sp_conciliar_saldos_proveedor(NULL);
```

Por proveedor:

```sql
CALL sp_conciliar_saldos_proveedor(1);
```

### Campos esperados

- proveedor;
- identificación;
- cuenta por pagar;
- factura;
- monto original;
- total pagado;
- saldo registrado;
- diferencia;
- estado;
- vencimiento;
- cancelación.

### Regla de consistencia

```txt
diferencia = monto_original - total_pagado - saldo_pendiente
```

El valor esperado es 0.

## Reporte 6 — Facturas pendientes de retención

### Objetivo

Permitir que la capa de integración envíe facturas al Módulo D.

### Vista

```sql
vw_facturas_pendientes_retencion
```

### Campos del payload

- `idFactura`
- `rucProveedor`
- `tipoProveedor`
- `baseImponible`
- `iva`
- `tipoBienServicio`
- `codigoSustento`
- `fecha`

## Reporte 7 — Recepciones pendientes de notificar

### Objetivo

Permitir integración con Módulo B para actualización de inventario.

### Vista

```sql
vw_recepciones_pendientes_notificar
```

### Campos esperados

- `id_recepcion`
- `id_oc`
- `fecha_recepcion`
- `tipo_recepcion`
- `id_detalle_rec`
- `ref_mod_b_id_producto`
- `cantidad_recibida`

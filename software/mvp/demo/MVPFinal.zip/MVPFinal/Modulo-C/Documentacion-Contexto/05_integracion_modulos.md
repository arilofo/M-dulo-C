# 05 — Integración con otros módulos

Este archivo define cómo el Módulo C se conecta con los módulos A, B y D.

## Principio general

El Módulo C debe integrarse con otros módulos mediante contratos, vistas, procedimientos o referencias lógicas.

No debe depender innecesariamente de tablas internas externas ni modificar scripts de otros módulos.

## Integración con Módulo B — Inventarios

### Propósito

El Módulo C se integra con Módulo B para:

- consultar productos;
- crear órdenes de compra con productos existentes;
- recibir solicitudes de compra por stock mínimo;
- notificar recepciones para actualizar stock.

### Entidad compartida principal

La entidad compartida es:

```sql
modulo_b.productos
```

En el script actual del Módulo B, la clave primaria se define como:

```sql
producto_id
```

El Módulo C guarda la referencia al producto mediante:

```sql
DetalleOrdenCompra.ref_mod_b_id_producto
DetalleRecepcion.ref_mod_b_id_producto
```

### IF-04 — Consulta de catálogo de productos

Uso:

- Seleccionar productos al crear una orden de compra.
- Obtener datos de snapshot:
  - código;
  - descripción;
  - unidad de medida;
  - precio de costo.

En el procedimiento `sp_crear_orden_compra`, el JSON de ítems espera campos compatibles con:

```json
[
  {
    "id_producto": 1,
    "codigo_producto": "PROD-001",
    "descripcion": "Producto prueba",
    "unidad_medida": "unidad",
    "cantidad": 10,
    "precio_costo": 25.00
  }
]
```

### IF-02 — Solicitud de compra desde Módulo B

Cuando una orden se origina desde una solicitud del Módulo B, el campo usado es:

```sql
OrdenCompra.ref_mod_b_id_solicitud
```

El script del Módulo C no actualiza directamente tablas del Módulo B. En su lugar, registra un evento pendiente en:

```sql
LogSincronizacion
```

con:

```txt
modulo_destino = MOD-B
interfaz = IF-02
estado = pendiente
```

### IF-03 — Notificación de recepción a inventario

Cuando se registra una recepción:

1. `sp_registrar_recepcion` inserta `Recepcion`.
2. Inserta `DetalleRecepcion`.
3. Actualiza estado de la orden.
4. Encola integración en `LogSincronizacion` con interfaz `IF-03`.

La vista de trabajo es:

```sql
vw_recepciones_pendientes_notificar
```

La integración debe generar o simular un movimiento en Módulo B:

```sql
modulo_b.movimientos_inventario
```

Tipo esperado:

```txt
ENTRADA
```

Después de confirmar la actualización de inventario, llamar:

```sql
CALL sp_marcar_recepcion_notificada(id_recepcion, usuario);
```

Si falla la comunicación, registrar error:

```sql
CALL sp_registrar_error_sincronizacion('MOD-B', 'IF-03', id_recepcion, mensaje_error);
```

## Integración con Módulo D — Impuestos

### Propósito

El Módulo C se integra con Módulo D para:

- consultar tarifa IVA;
- consultar retenciones;
- enviar factura de proveedor;
- recibir comprobante de retención.

### Tablas relevantes del Módulo D

El script externo del Módulo D contiene, entre otras:

- `tarifas_iva`
- `cat_tipos_proveedor`
- `retenciones_iva_config`
- `retenciones_renta_config`
- `liquidacion_iva_mensual`
- `comprobantes_retencion`
- `log_xml_comprobantes`
- `feriados_ecuador`

### Referencias lógicas desde Módulo D hacia Módulo C

La tabla `comprobantes_retencion` usa referencias lógicas:

```sql
ref_mod_c_proveedor_id
ref_mod_c_factura_id
```

Estas referencias corresponden conceptualmente a:

```sql
modulo_c.Proveedor.id_proveedor
modulo_c.FacturaProveedor.id_factura_prov
```

### IF-06 / IC-D02 — Consulta de tarifa IVA y retenciones

La consulta de tarifa IVA y reglas de retención pertenece a la capa de aplicación o servicio de integración.

En el Módulo C se registra:

```sql
FacturaProveedor.ref_mod_d_tarifa_id
```

### IF-05 — Envío de factura al Módulo D

Cuando una factura queda registrada, su estado inicial es:

```txt
pendiente_retencion
```

El Módulo C expone las facturas pendientes mediante:

```sql
vw_facturas_pendientes_retencion
```

Campos principales del payload:

- `idFactura`
- `rucProveedor`
- `tipoProveedor`
- `baseImponible`
- `iva`
- `tipoBienServicio`
- `codigoSustento`
- `fecha`

Cuando Módulo D devuelve respuesta, se llama:

```sql
CALL sp_actualizar_retencion_desde_modd(
  id_factura,
  xml_retencion,
  num_autorizacion
);
```

El estado cambia a:

```txt
retencion_generada
```

## Integración con Módulo A — Facturación y Cuentas por Cobrar

### Propósito

La integración con Módulo A es indirecta. El Módulo A puede consultar costos de adquisición para análisis de márgenes o precios de venta.

### IF-01 — Exposición de precio de costo

Procedimientos del Módulo C:

```sql
CALL sp_consultar_precio_costo_producto(id_producto);
CALL sp_consultar_ultimo_costo_adquisicion(id_producto, limite);
```

Estos procedimientos devuelven precio de costo registrado en órdenes de compra con mercadería efectivamente recibida.

Si no existe costo registrado, devuelven:

```txt
SIN_COSTO_REGISTRADO
```

## Tabla de interfaces

| Interfaz | Dirección | Propósito | Implementación en Módulo C |
|---|---|---|---|
| IF-01 | C → A | Exponer precio de costo | `sp_consultar_precio_costo_producto`, `sp_consultar_ultimo_costo_adquisicion` |
| IF-02 | B → C | Solicitud de compra por stock mínimo | `ref_mod_b_id_solicitud`, `LogSincronizacion` |
| IF-03 | C → B | Notificar recepción para inventario | `vw_recepciones_pendientes_notificar`, `sp_marcar_recepcion_notificada` |
| IF-04 | C → B | Consultar catálogo de productos | JSON de ítems con snapshot del producto |
| IF-05 | C → D | Enviar factura para retención | `vw_facturas_pendientes_retencion`, `sp_actualizar_retencion_desde_modd` |
| IF-06 | C → D | Consultar IVA / retenciones | Campo `ref_mod_d_tarifa_id`, capa app |
| IC-D02 | C ↔ D | Contrato tributario | Capa app + tablas de Módulo D |

## Reglas para Codex

- No modificar scripts de A, B ni D.
- No crear integración directa si no es necesaria para la demo.
- Preferir mocks o servicios adaptadores si hay incompatibilidad.
- Registrar errores en `LogSincronizacion`.
- Recordar que la fuente de verdad de productos es Módulo B.

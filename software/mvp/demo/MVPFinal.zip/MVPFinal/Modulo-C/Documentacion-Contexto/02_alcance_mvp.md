# 02 — Alcance del MVP

Este archivo define el alcance práctico del prototipo que Codex debe implementar o respetar.

## Objetivo del MVP

Construir un prototipo funcional y demostrable del **Módulo C — Cuentas por Pagar**, centrado en el flujo principal:

```txt
Proveedor → Orden de compra → Recepción → Factura proveedor → Cuenta por pagar → Pago → Reportes
```

El MVP no debe intentar convertirse en un ERP completo.

## Funcionalidades dentro del alcance

### 1. Proveedores

- Listar proveedores activos.
- Registrar proveedor.
- Actualizar proveedor.
- Desactivar proveedor mediante borrado lógico.
- Distinguir persona natural y persona jurídica.
- Manejar identificación, razón social, días de crédito y calificación.

Procedimientos sugeridos:

- `sp_registrar_proveedor`
- `sp_actualizar_proveedor`
- `sp_eliminar_proveedor_logico`

### 2. Órdenes de compra

- Crear orden de compra.
- Agregar productos a la orden.
- Guardar snapshot del producto:
  - código;
  - descripción;
  - unidad de medida;
  - precio pactado.
- Consultar órdenes pendientes de recepción.
- Permitir órdenes manuales o provenientes de solicitud del Módulo B.

Procedimientos / vistas:

- `sp_crear_orden_compra`
- `sp_reporte_ordenes_pendientes_recepcion`
- `vw_ordenes_pendientes_recepcion`

### 3. Recepciones

- Registrar recepción parcial o completa.
- Validar que la cantidad recibida no supere la cantidad pendiente.
- Actualizar estado de la orden.
- Encolar notificación al Módulo B.
- Marcar recepción como notificada luego de integrar inventario.

Procedimientos / vistas:

- `sp_registrar_recepcion`
- `vw_recepciones_pendientes_notificar`
- `sp_marcar_recepcion_notificada`

### 4. Facturas proveedor

- Registrar factura de proveedor.
- Vincular factura con proveedor, orden y recepción cuando sea regular.
- Permitir factura excepcional sin orden solo si tiene autorización.
- Dejar factura en estado `pendiente_retencion`.
- Generar cuenta por pagar automáticamente.

Procedimientos / vistas:

- `sp_ingresar_factura_proveedor`
- `vw_facturas_pendientes_retencion`
- `sp_actualizar_retencion_desde_modd`

### 5. Cuentas por pagar

- Generar cuenta por pagar desde factura.
- Calcular fecha de vencimiento según días de crédito del proveedor.
- Mantener saldo pendiente.
- Programar fecha de pago.
- Actualizar estado financiero:
  - `pendiente`
  - `pagada_parcial`
  - `pagada`
  - `vencida`

Procedimientos / vistas:

- `sp_generar_cuenta_por_pagar`
- `sp_programar_pago`
- `sp_actualizar_cuentas_vencidas`
- `vw_cuentas_pendientes`

### 6. Pagos

- Registrar pagos parciales o totales.
- Validar monto mayor a cero.
- Evitar pago superior al saldo pendiente.
- Actualizar saldo y estado de la cuenta por pagar.
- Registrar auditoría.

Procedimiento:

- `sp_registrar_pago`

### 7. Reportes

El MVP debe incluir:

- Pagos próximos a vencer.
- Obligaciones pendientes.
- Estado de cuenta por proveedor.
- Órdenes pendientes de recepción.
- Conciliación de saldos.

Procedimientos / vistas:

- `sp_alertar_pagos_por_vencer`
- `sp_reporte_obligaciones_pendientes`
- `sp_estado_cuenta_proveedor`
- `sp_reporte_ordenes_pendientes_recepcion`
- `sp_conciliar_saldos_proveedor`

## Fuera de alcance

Codex no debe implementar:

- Módulo A completo.
- Módulo B completo.
- Módulo D completo.
- Firma electrónica real.
- Conexión real con SRI.
- Autenticación compleja.
- Microservicios distribuidos reales.
- Frontend avanzado con dashboards complejos.
- Facturación electrónica completa.
- Modificación de scripts externos sin autorización.

## Integración aceptada para el MVP

La integración puede ser:

- Real si los scripts externos están disponibles y son compatibles.
- Simulada si existe incompatibilidad de nombres o falta de datos.
- Basada en mocks si el objetivo es demostrar el flujo.

Lo importante es que el prototipo evidencie la intención de integración y no rompa el flujo del Módulo C.

## Criterio de éxito del MVP

El prototipo es suficiente si permite demostrar en vivo:

1. Registrar o seleccionar proveedor.
2. Crear orden de compra.
3. Registrar recepción.
4. Encolar o simular actualización de inventario.
5. Registrar factura proveedor.
6. Generar cuenta por pagar.
7. Registrar pago.
8. Consultar reportes principales.

# 03 — Requerimientos del Módulo C

Este archivo resume los requerimientos funcionales y no funcionales que Codex debe respetar.

## Requerimientos funcionales

### RF01 — Registrar proveedores

El sistema debe permitir registrar proveedores con datos completos, diferenciando:

- persona natural;
- persona jurídica.

Debe incluir:

- identificación / RUC;
- razón social;
- condiciones de pago;
- días de crédito;
- calificación;
- datos bancarios y contacto.

### RF02 — Crear órdenes de compra

El sistema debe permitir crear órdenes de compra:

- manualmente;
- desde solicitudes generadas por el Módulo B cuando el stock llega al mínimo.

### RF03 — Registrar recepciones parciales

El sistema debe permitir registrar recepciones de mercadería vinculadas a una orden de compra.

Debe permitir:

- recepción completa;
- recepción parcial;
- múltiples entregas.

### RF04 — Actualizar inventario en Módulo B

Al confirmar una recepción, el sistema debe actualizar o simular la actualización del inventario en Módulo B.

### RF05 — Ingresar facturas proveedor

El sistema debe permitir ingresar facturas de compra emitidas por proveedores y vincularlas con:

- proveedor;
- orden de compra;
- recepción;
- tarifa IVA;
- datos tributarios.

### RF06 — Generar cuenta por pagar

Al ingresar una factura válida, el sistema debe generar automáticamente una cuenta por pagar con:

- monto original;
- saldo pendiente;
- fecha de vencimiento;
- estado inicial `pendiente`.

### RF07 — Registrar pagos

El sistema debe permitir registrar pagos a proveedores indicando:

- monto;
- fecha;
- forma de pago;
- referencia;
- cuenta por pagar asociada.

### RF08 — Actualizar saldo pendiente

Al registrar un pago, el sistema debe actualizar automáticamente el saldo pendiente.

Estados posibles:

- `pagada_parcial` si queda saldo.
- `pagada` si el saldo llega a cero.

### RF09 — Estado de cuenta por proveedor

El sistema debe generar estado de cuenta por proveedor, mostrando:

- facturas;
- pagos;
- saldos;
- estado financiero.

### RF10 — Alertar pagos próximos a vencer

El sistema debe alertar pagos próximos a vencer dentro de un horizonte configurable.

Valor por defecto: 7 días.

### RF11 — Consultar órdenes pendientes de recepción

El sistema debe permitir consultar órdenes en estado:

- `emitida`;
- `recibida_parcial`.

### RF12 — Reporte de obligaciones pendientes

El sistema debe generar reportes de obligaciones pendientes agrupadas o filtradas por:

- proveedor;
- fecha de vencimiento;
- estado.

### RF13 — Notificar ingreso al inventario

El sistema debe notificar al Módulo B el ingreso de productos al confirmar una recepción.

Interfaz: `IF-03`.

### RF14 — Consultar catálogo del Módulo B

El sistema debe consultar productos del Módulo B para armar órdenes de compra.

Interfaz: `IF-04`.

### RF15 — Recibir solicitudes de compra del Módulo B

El sistema debe procesar solicitudes generadas por el Módulo B cuando el stock alcanza o cae por debajo del mínimo.

Interfaz: `IF-02`.

### RF16 — Exponer precio de costo al Módulo A

El sistema debe exponer el precio de costo de adquisición de productos en modo solo lectura.

Interfaz: `IF-01`.

Procedimientos relacionados:

- `sp_consultar_precio_costo_producto`
- `sp_consultar_ultimo_costo_adquisicion`

### RF17 — Gestión IVA y retenciones con Módulo D

Al registrar factura de proveedor, el sistema debe integrarse con Módulo D para:

- consultar tarifa IVA;
- consultar reglas de retención;
- enviar datos de factura;
- recibir comprobante de retención.

Interfaces:

- `IF-05`
- `IF-06`
- `IC-D02`

## Requerimientos no funcionales

### RNF01 — Rendimiento

Las consultas de estado de cuenta y reportes de obligaciones no deben superar 3 segundos con hasta 50 registros simultáneos.

### RNF02 — Integridad y log de sincronización

El módulo debe mantener integridad referencial. Fallos de comunicación con Módulo B o D deben registrarse en `LogSincronizacion`.

### RNF03 — Control de acceso por roles

Roles principales:

- Jefe de Compras: ciclo operativo.
- Tesorero: ciclo financiero.
- Administrador: acceso completo y autorizaciones.

### RNF04 — Auditoría

Operaciones financieras deben registrarse en `BitacoraAuditoria`, incluyendo:

- usuario;
- fecha;
- hora;
- valores anteriores;
- valores nuevos.

### RNF05 — Contratos de integración

La comunicación con otros módulos debe realizarse mediante contratos e interfaces. Un cambio interno en A, B o D no debe obligar a modificar Módulo C si se respeta el contrato.

## Observación para Codex

Si un requerimiento ya tiene procedimiento almacenado asociado, usar el procedimiento en lugar de escribir lógica duplicada en aplicación.

# 00 — Reglas obligatorias del proyecto

Este archivo define las reglas duras que Codex debe respetar antes de generar o modificar código del prototipo del **Módulo C — Cuentas por Pagar** del SIGE.

## 1. Alcance obligatorio del módulo

El Módulo C gestiona el proceso de compra y pago a proveedores:

```txt
orden de compra → recepción de mercadería → factura proveedor → cuenta por pagar → pago
```

El prototipo debe permitir demostrar este flujo completo con datos reales o de prueba.

## 2. Entidades mínimas exigidas

El prototipo debe cubrir, como mínimo, las siguientes entidades del enunciado y su equivalencia en el modelo real:

| Entidad exigida | Tablas / vistas reales del Módulo C |
|---|---|
| proveedores | `Proveedor`, `ProveedorPersonaNatural`, `ProveedorPersonaJuridica`, vista `proveedores` |
| ordenes_compra | `OrdenCompra`, vista `ordenes_compra` |
| detalle_orden_compra | `DetalleOrdenCompra`, vista `detalle_orden_compra` |
| recepciones | `Recepcion`, `DetalleRecepcion`, vistas `recepciones`, `detalle_recepcion` |
| facturas_proveedor | `FacturaProveedor`, vista `facturas_proveedor` |
| pagos_proveedor | `PagoProveedor`, vista `pagos_proveedor` |
| cuentas_por_pagar | `CuentaPorPagar`, vista `cuentas_por_pagar` |

Codex no debe crear tablas nuevas para estas entidades si ya existen en el script SQL.

## 3. Borrado lógico obligatorio

El proyecto usa **borrado lógico**.

Codex no debe usar `DELETE` físico en las tablas principales del módulo. Para desactivar registros debe usar o respetar campos como:

- `activo = 0`
- `fecha_eliminacion = NOW()`
- `eliminado_por = usuario`

Las consultas operativas normales deben filtrar registros activos:

```sql
WHERE activo = 1
```

Procedimientos relevantes:

- `sp_eliminar_proveedor_logico`
- `sp_eliminar_orden_logico`

## 4. Base de datos modular / distribuida

El SIGE se organiza por módulos:

- Módulo A: Facturación y Cuentas por Cobrar.
- Módulo B: Inventarios.
- Módulo C: Cuentas por Pagar.
- Módulo D: Impuestos.

Codex debe tratar los módulos A, B y D como dependencias externas, no como parte interna del Módulo C.

Reglas:

- No modificar los scripts de módulos A, B o D.
- No implementar completos los módulos A, B o D.
- No acoplar el prototipo a estructuras externas innecesarias.
- Usar interfaces, vistas, procedimientos, referencias lógicas o mocks para integración.
- Los scripts de módulos externos son de referencia y compatibilidad para la demo.

## 5. Procedimientos almacenados como fuente de operación

Cuando exista un procedimiento almacenado para una operación crítica, Codex debe usarlo en lugar de manipular tablas directamente.

Procesos obligatorios por procedimientos:

- Crear orden de compra: `sp_crear_orden_compra`
- Registrar recepción: `sp_registrar_recepcion`
- Marcar recepción notificada: `sp_marcar_recepcion_notificada`
- Ingresar factura proveedor: `sp_ingresar_factura_proveedor`
- Generar cuenta por pagar: `sp_generar_cuenta_por_pagar`
- Registrar pago: `sp_registrar_pago`
- Programar pago: `sp_programar_pago`
- Reportar pagos próximos a vencer: `sp_alertar_pagos_por_vencer`
- Reportar órdenes pendientes: `sp_reporte_ordenes_pendientes_recepcion`
- Conciliar saldos: `sp_conciliar_saldos_proveedor`

## 6. Integración obligatoria con Módulo B

Al registrar una recepción de mercadería:

1. El Módulo C registra `Recepcion`.
2. El Módulo C registra `DetalleRecepcion`.
3. El sistema encola o ejecuta la integración IF-03 hacia Módulo B.
4. El Módulo B debe registrar un movimiento de inventario tipo `ENTRADA` o se debe simular esa integración.
5. La recepción debe quedar marcada como notificada mediante `sp_marcar_recepcion_notificada`.

## 7. Integración obligatoria con Módulo D

Al registrar una factura de proveedor:

1. La factura queda en estado `pendiente_retencion`.
2. La vista `vw_facturas_pendientes_retencion` expone el payload para el Módulo D.
3. El Módulo D genera o simula el comprobante de retención.
4. El Módulo C actualiza la factura mediante `sp_actualizar_retencion_desde_modd`.

## 8. Reportes obligatorios

El prototipo debe incluir, como mínimo:

- Pagos próximos a vencer.
- Órdenes pendientes de recepción.
- Estado de cuenta por proveedor.
- Obligaciones pendientes.
- Conciliación de saldos.

## 9. EXPLAIN en pagos próximos a vencer

El reporte de pagos próximos a vencer debe estar asociado a una consulta optimizada con índice. El índice principal en el script es:

```sql
idx_cxp_alertas (activo, estado, fecha_vencimiento, saldo_pendiente)
```

Para la documentación o pruebas se debe poder ejecutar `EXPLAIN` sobre la consulta del reporte.

## 10. No inventar nombres físicos

La fuente final de verdad para nombres de tablas, columnas, vistas y procedimientos son los scripts SQL reales.

Codex debe revisar los scripts antes de generar consultas SQL.

# 07 — Reglas de negocio y validaciones

Este archivo concentra reglas que Codex debe aplicar en servicios, controladores, vistas y pruebas.

## Reglas generales

1. No usar borrado físico en tablas principales.
2. Toda consulta operativa debe filtrar `activo = 1`.
3. Las operaciones críticas deben usar procedimientos almacenados.
4. No duplicar lógica crítica en la aplicación si ya existe en SQL.
5. Los módulos externos se integran mediante contratos, no por modificación directa de sus scripts.

## Proveedores

### Alta

Validar:

- `tipo_proveedor` obligatorio.
- `identificacion` obligatoria.
- `razon_social` obligatoria.
- `identificacion` no duplicada.
- Si es persona natural, requiere `cedula`.
- Si es persona jurídica, requiere razón social comercial.

Procedimiento:

- `sp_registrar_proveedor`

### Actualización

Validar:

- proveedor existe;
- proveedor está activo;
- razón social no queda vacía.

Procedimiento:

- `sp_actualizar_proveedor`

### Eliminación lógica

Validar:

- proveedor existe y está activo;
- no tiene cuentas por pagar activas con saldo pendiente.

Procedimiento:

- `sp_eliminar_proveedor_logico`

## Órdenes de compra

Reglas:

- La orden debe tener proveedor activo.
- La orden debe tener al menos un ítem.
- Cada ítem requiere:
  - `id_producto`;
  - descripción;
  - cantidad mayor a cero;
  - precio no negativo.
- Estado inicial de orden creada: `emitida`.
- El total estimado se calcula con los subtotales.
- Si existe solicitud de Módulo B, registrar evento IF-02 en `LogSincronizacion`.

Procedimiento:

- `sp_crear_orden_compra`

## Recepciones

Reglas:

- Solo se puede registrar recepción para orden activa en estado:
  - `emitida`;
  - `recibida_parcial`.
- La recepción debe tener al menos un detalle.
- Cada detalle requiere:
  - `id_detalle_oc`;
  - `cantidad_recibida > 0`.
- El detalle debe pertenecer a la orden seleccionada.
- No se puede recibir más de lo pendiente.
- Después de recibir:
  - si porcentaje recibido >= 100, orden pasa a `recibida_total`;
  - si no, pasa a `recibida_parcial`.
- Se encola IF-03 hacia Módulo B en `LogSincronizacion`.

Procedimiento:

- `sp_registrar_recepcion`

## Notificación a inventario

Reglas:

- Una recepción solo puede marcarse notificada si:
  - existe;
  - está activa;
  - aún no fue notificada.
- Si no cumple, debe fallar con mensaje claro.
- Si falla la comunicación con Módulo B, registrar error en `LogSincronizacion`.

Procedimientos:

- `sp_marcar_recepcion_notificada`
- `sp_registrar_error_sincronizacion`

## Facturas proveedor

### Factura regular

Reglas:

- Requiere proveedor.
- Requiere orden de compra.
- Requiere recepción.
- Orden y recepción deben corresponder al proveedor.
- La orden debe estar en estado:
  - `recibida_parcial`;
  - `recibida_total`.
- El monto total no puede superar el pendiente de facturación de la orden.
- El estado inicial de factura es `pendiente_retencion`.
- Se genera cuenta por pagar automáticamente.

Procedimiento:

- `sp_ingresar_factura_proveedor`

### Factura excepcional

Reglas:

- `factura_excepcional = 1`.
- `id_oc` debe ser `NULL`.
- `id_recepcion` debe ser `NULL`.
- Requiere `motivo_excepcion`.
- Requiere `usuario_autorizador`.
- La validación de que el autorizador sea Administrador se hace en la capa de aplicación.
- Debe quedar auditada.

Procedimiento:

- `sp_ingresar_factura_proveedor`

## Cuenta por pagar

Reglas:

- Una factura activa y no anulada genera una sola cuenta por pagar.
- No generar cuenta por pagar duplicada para la misma factura.
- Fecha de vencimiento se calcula con `fn_calcular_fecha_vencimiento`.
- Estado inicial: `pendiente`.
- Saldo inicial igual al total de factura.

Procedimiento:

- `sp_generar_cuenta_por_pagar`

## Pagos

Reglas:

- `monto` obligatorio y mayor que cero.
- Cuenta por pagar debe existir y estar activa.
- El pago no puede superar el saldo pendiente.
- La cuenta debe bloquearse con `FOR UPDATE` durante el pago.
- Si el pago cubre todo:
  - saldo queda 0;
  - estado `pagada`;
  - se registra `fecha_cancelacion`.
- Si queda saldo:
  - estado `pagada_parcial`.
- Registrar auditoría.

Procedimiento:

- `sp_registrar_pago`

## Programación de pagos

Reglas:

- Fecha programada obligatoria.
- Fecha programada no puede ser anterior a hoy.
- Cuenta debe:
  - existir;
  - estar activa;
  - tener saldo pendiente;
  - estar en estado `pendiente`, `pagada_parcial` o `vencida`.
- No se puede programar cuenta ya pagada.
- Registrar auditoría del cambio.

Procedimiento:

- `sp_programar_pago`

## Retenciones con Módulo D

Reglas:

- Solo actualizar factura activa en estado `pendiente_retencion`.
- No reprocesar facturas anuladas o ya procesadas.
- Actualizar:
  - `xml_retencion`;
  - `num_autorizacion_retencion`;
  - estado `retencion_generada`.
- Registrar auditoría.

Procedimiento:

- `sp_actualizar_retencion_desde_modd`

## Cuentas vencidas

Reglas:

- Marcar como `vencida` las cuentas activas con:
  - fecha_vencimiento < hoy;
  - saldo_pendiente > 0;
  - estado `pendiente` o `pagada_parcial`.
- Registrar auditoría si hay cuentas afectadas.

Procedimiento:

- `sp_actualizar_cuentas_vencidas`

## Conciliación

Regla de consistencia:

```txt
monto_original - total_pagado - saldo_pendiente = 0
```

Si la diferencia es distinta de cero, hay inconsistencia.

Procedimiento:

- `sp_conciliar_saldos_proveedor`

## Reportes

### Pagos próximos a vencer

Reglas:

- Horizonte configurable.
- Si el usuario no especifica o envía valor inválido, usar 7 días.
- Filtrar:
  - `activo = 1`;
  - `estado IN ('pendiente', 'pagada_parcial')`;
  - `saldo_pendiente > 0`;
  - `fecha_vencimiento BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL p_dias DAY)`.

Procedimiento:

- `sp_alertar_pagos_por_vencer`

### Órdenes pendientes de recepción

Reglas:

- Mostrar órdenes activas en estado:
  - `emitida`;
  - `recibida_parcial`.

Procedimiento:

- `sp_reporte_ordenes_pendientes_recepcion`

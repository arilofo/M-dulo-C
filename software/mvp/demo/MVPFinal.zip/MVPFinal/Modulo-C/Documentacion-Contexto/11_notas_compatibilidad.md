# 11 — Notas de compatibilidad de nombres y scripts

Este archivo evita errores comunes al generar consultas entre módulos.

## Regla principal

La fuente final de verdad para nombres físicos de tablas y columnas son los scripts SQL reales cargados en `database/`.

Los informes describen el diseño, pero el código debe consultar los nombres exactos del SQL antes de ejecutar o generar consultas.

## Módulo C: PascalCase y vistas snake_case

El Módulo C usa tablas principales en PascalCase:

- `Proveedor`
- `OrdenCompra`
- `DetalleOrdenCompra`
- `Recepcion`
- `DetalleRecepcion`
- `FacturaProveedor`
- `CuentaPorPagar`
- `PagoProveedor`

También crea vistas de compatibilidad en snake_case:

- `proveedores`
- `ordenes_compra`
- `detalle_orden_compra`
- `recepciones`
- `detalle_recepcion`
- `facturas_proveedor`
- `cuentas_por_pagar`
- `pagos_proveedor`

Para escritura, Codex debe preferir procedimientos almacenados.

Para lectura simple, puede usar vistas si ayudan a compatibilidad.

## Productos del Módulo B

En los documentos y scripts aparecen referencias antiguas y actuales relacionadas con el identificador de producto.

### En el script actual del Módulo B

La tabla `productos` define:

```sql
producto_id
```

No asumir automáticamente `product_id`.

### En Módulo C

La referencia lógica al producto del Módulo B se guarda como:

```sql
ref_mod_b_id_producto
```

En:

- `DetalleOrdenCompra`
- `DetalleRecepcion`

## Equivalencias importantes

| Referencia antigua o dudosa | Referencia correcta en Módulo C / scripts actuales |
|---|---|
| `product_id` | revisar script de Módulo B; en el script actual aparece `producto_id` |
| `doc.producto_id` | `doc.ref_mod_b_id_producto` |
| `oc.orden_id` | `oc.id_oc` |
| `doc.orden_id` | `doc.id_oc` |
| `factura_id` en Módulo C | `id_factura_prov` |
| `proveedor_id` en Módulo C | `id_proveedor` |
| `cuenta_id` | `id_cxp` |

## Incompatibilidad detectada en scripts externos

En el script del Módulo A, `detalle_factura` puede referirse a:

```sql
producto_id INT UNSIGNED COMMENT 'FK hacia Módulo B...'
```

y la restricción puede mencionar:

```sql
modulo_b.productos(product_id)
```

Sin embargo, el script del Módulo B define la clave como:

```sql
producto_id
```

Codex debe detectar esta diferencia y no asumir que todos los scripts externos ejecutan sin ajuste.

Para el prototipo del Módulo C, esta incompatibilidad se puede manejar con:

- mock de catálogo de productos;
- vista adaptadora;
- alias en consultas;
- ajuste manual autorizado;
- documentación en README.

## Nombre físico de esquemas

Esquemas esperados:

- `modulo_c`
- `modulo_b`
- `modulo_d`

El Módulo A puede no definir explícitamente `USE modulo_a` en el fragmento disponible. Revisar script real antes de automatizar carga completa.

## Factura proveedor

El Módulo C usa:

```sql
FacturaProveedor.id_factura_prov
FacturaProveedor.numero_factura_proveedor
FacturaProveedor.numero_serie
```

La unicidad de factura es:

```sql
UNIQUE(id_proveedor, numero_serie, numero_factura_proveedor)
```

No tratar `numero_factura_proveedor` como globalmente único.

## Estados importantes

### OrdenCompra.estado

- `borrador`
- `emitida`
- `recibida_parcial`
- `recibida_total`
- `anulada`

No usar `recibida_completa`.

### FacturaProveedor.estado

- `pendiente_retencion`
- `retencion_generada`
- `anulada`

No poner estados financieros como `pagada` en `FacturaProveedor`.

### CuentaPorPagar.estado

- `pendiente`
- `pagada_parcial`
- `pagada`
- `vencida`

Los estados de pago pertenecen aquí, no a la factura.

## Módulo D

La tabla `comprobantes_retencion` usa referencias lógicas hacia Módulo C:

```sql
ref_mod_c_proveedor_id
ref_mod_c_factura_id
```

Estas corresponden a:

```sql
Proveedor.id_proveedor
FacturaProveedor.id_factura_prov
```

## Recomendación para Codex

Antes de escribir consultas SQL de integración, ejecutar una revisión rápida:

1. Buscar nombre real de tabla.
2. Buscar nombre real de columna.
3. Confirmar esquema.
4. Confirmar si existe vista de compatibilidad.
5. Confirmar si existe procedimiento almacenado.
6. Preferir procedimiento/vista antes de acceso directo.

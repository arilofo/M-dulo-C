# 04 — Flujos principales del sistema

Este archivo transforma los casos de uso y procesos SQL en flujos implementables para el prototipo.

## Flujo 1 — Gestión de proveedores

Actor principal: Jefe de Compras.

Objetivo: registrar, actualizar o desactivar proveedores.

Pasos:

1. El usuario abre la pantalla de proveedores.
2. El sistema muestra proveedores activos.
3. El usuario registra un proveedor.
4. El sistema valida:
   - tipo de proveedor;
   - identificación obligatoria;
   - razón social obligatoria;
   - identificación no duplicada;
   - datos obligatorios del subtipo.
5. El sistema registra en `Proveedor`.
6. El sistema registra en `ProveedorPersonaNatural` o `ProveedorPersonaJuridica`.

Procedimientos:

- `sp_registrar_proveedor`
- `sp_actualizar_proveedor`
- `sp_eliminar_proveedor_logico`

## Flujo 2 — Crear orden de compra

Actor principal: Jefe de Compras.

Objetivo: crear una orden de compra con sus detalles.

Pasos:

1. El usuario selecciona proveedor activo.
2. El sistema permite seleccionar productos del Módulo B o ingresar datos de prueba compatibles.
3. El usuario ingresa cantidades y precios pactados.
4. El sistema valida que la orden tenga al menos un ítem.
5. El sistema genera número de orden.
6. El sistema inserta `OrdenCompra` en estado `emitida`.
7. El sistema inserta los registros en `DetalleOrdenCompra`.
8. El sistema calcula y actualiza `total_estimado`.
9. Si la orden proviene de solicitud del Módulo B, se registra evento pendiente en `LogSincronizacion`.

Procedimiento:

- `sp_crear_orden_compra`

## Flujo 3 — Registrar recepción de mercadería

Actor principal: Jefe de Compras.

Objetivo: registrar entrada física de mercadería.

Pasos:

1. El usuario selecciona una orden en estado `emitida` o `recibida_parcial`.
2. El sistema muestra detalles pendientes.
3. El usuario ingresa cantidades recibidas.
4. El sistema valida:
   - recepción con al menos un detalle;
   - detalle pertenece a la orden;
   - cantidad recibida > 0;
   - cantidad recibida no supera cantidad pendiente.
5. El sistema inserta `Recepcion`.
6. El sistema inserta `DetalleRecepcion`.
7. El sistema calcula porcentaje recibido.
8. El sistema actualiza estado de `OrdenCompra`:
   - `recibida_parcial`;
   - `recibida_total`.
9. El sistema encola notificación IF-03 en `LogSincronizacion`.

Procedimiento:

- `sp_registrar_recepcion`

## Flujo 4 — Actualizar inventario / integración con Módulo B

Actor: sistema / integración.

Objetivo: registrar entrada en inventario del Módulo B o simularla.

Pasos:

1. El sistema consulta `vw_recepciones_pendientes_notificar`.
2. Por cada recepción pendiente, identifica producto y cantidad.
3. La integración con Módulo B registra movimiento tipo `ENTRADA` en `movimientos_inventario` o simula la operación.
4. Si Módulo B confirma, el sistema llama `sp_marcar_recepcion_notificada`.
5. Si falla, el sistema registra error mediante `sp_registrar_error_sincronizacion`.

Procedimientos / vistas:

- `vw_recepciones_pendientes_notificar`
- `sp_marcar_recepcion_notificada`
- `sp_registrar_error_sincronizacion`

## Flujo 5 — Ingresar factura de proveedor

Actor principal: Jefe de Compras.

Objetivo: registrar factura y generar cuenta por pagar.

Pasos para factura regular:

1. El usuario selecciona proveedor.
2. El usuario selecciona orden de compra.
3. El usuario selecciona recepción asociada.
4. El sistema valida que la orden pertenezca al proveedor.
5. El sistema valida que la orden esté en estado `recibida_parcial` o `recibida_total`.
6. El usuario ingresa:
   - número de factura;
   - serie;
   - código sustento;
   - base imponible;
   - IVA;
   - tipo de bien o servicio.
7. El sistema valida que el monto no supere el pendiente de facturación de la orden.
8. El sistema inserta `FacturaProveedor` en estado `pendiente_retencion`.
9. El sistema registra auditoría.
10. El sistema llama `sp_generar_cuenta_por_pagar`.

Procedimiento:

- `sp_ingresar_factura_proveedor`

## Flujo 6 — Factura excepcional sin orden de compra

Actor principal: Administrador del sistema.

Condición: el usuario intenta registrar factura sin orden asociada.

Reglas:

1. Si `factura_excepcional = 1`, `id_oc` e `id_recepcion` deben ser `NULL`.
2. Debe existir `motivo_excepcion`.
3. Debe existir `usuario_autorizador`.
4. La validación real de rol Administrador pertenece a la capa de aplicación.
5. La BD guarda usuario autorizador y auditoría.

Procedimiento:

- `sp_ingresar_factura_proveedor`

## Flujo 7 — Enviar factura a Módulo D

Actor: sistema / integración.

Objetivo: enviar factura a impuestos para retención.

Pasos:

1. El sistema consulta `vw_facturas_pendientes_retencion`.
2. La capa de aplicación envía el payload al Módulo D.
3. El Módulo D genera o simula retención.
4. La capa de aplicación recibe:
   - XML de retención;
   - número de autorización.
5. El sistema llama `sp_actualizar_retencion_desde_modd`.
6. La factura cambia a `retencion_generada`.

Procedimientos / vistas:

- `vw_facturas_pendientes_retencion`
- `sp_actualizar_retencion_desde_modd`

## Flujo 8 — Registrar pago a proveedor

Actor principal: Tesorero.

Objetivo: registrar pago parcial o total sobre una cuenta por pagar.

Pasos:

1. El usuario consulta cuentas pendientes.
2. El usuario selecciona cuenta por pagar.
3. El usuario ingresa:
   - monto;
   - forma de pago;
   - referencia.
4. El sistema valida que el monto sea mayor que cero.
5. El sistema bloquea la cuenta con `FOR UPDATE`.
6. El sistema valida que el pago no supere saldo pendiente.
7. El sistema inserta `PagoProveedor`.
8. El sistema actualiza `CuentaPorPagar.saldo_pendiente`.
9. Si saldo queda en cero:
   - estado `pagada`;
   - registra `fecha_cancelacion`.
10. Si queda saldo:
   - estado `pagada_parcial`.
11. Se registra auditoría.

Procedimiento:

- `sp_registrar_pago`

## Flujo 9 — Programar pago

Actor principal: Tesorero.

Objetivo: asignar fecha programada de pago.

Reglas:

- La fecha programada es obligatoria.
- No puede ser anterior a la fecha actual.
- La cuenta debe estar activa.
- Debe tener saldo pendiente.
- No se puede programar una cuenta ya pagada.

Procedimiento:

- `sp_programar_pago`

## Flujo 10 — Reportes

### Pagos próximos a vencer

Procedimiento / vista:

- `sp_alertar_pagos_por_vencer`
- `vw_pagos_por_vencer`

Debe mostrar:

- proveedor;
- identificación;
- factura;
- saldo pendiente;
- fecha vencimiento;
- fecha programada;
- días para vencer.

### Órdenes pendientes

Procedimiento / vista:

- `sp_reporte_ordenes_pendientes_recepcion`
- `vw_ordenes_pendientes_recepcion`

Debe mostrar:

- número de orden;
- proveedor;
- fecha emisión;
- fecha esperada;
- estado;
- porcentaje recibido;
- días desde emisión.

### Obligaciones pendientes

Procedimiento / vista:

- `sp_reporte_obligaciones_pendientes`
- `vw_cuentas_pendientes`

### Estado de cuenta

Procedimiento / vista:

- `sp_estado_cuenta_proveedor`
- `vw_estado_cuenta_proveedor`

### Conciliación

Procedimiento:

- `sp_conciliar_saldos_proveedor`

Debe mostrar diferencia entre:

```txt
monto_original - total_pagado - saldo_pendiente
```

Si la diferencia es distinta de cero, existe inconsistencia.
